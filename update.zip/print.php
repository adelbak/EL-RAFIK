<?php
/*
-----------------------------------------------
            سكربت المدير الرقمي            
-----------------------------------------------
برمجة وتطوير: عادل قصي
البريد الإلكتروني: adelbak2014@gmail.com
الموقع الرسمي: www.cem11.com
الصفحة الرسمية للمبرمج: https://www.facebook.com/adel.qusay.9
-----------------------------------------------
السكربت مجاني، يرجى طلب الإذن عند الرغبة في
التطوير.
-----------------------------------------------
*/

require 'config.php';

if (@$_SERVER['REQUEST_METHOD'] !== 'GET' OR isset($_SESSION['educ_institution_name']) == '') { die('0'); }
$doc = isset( $_GET['doc'] ) ? $_GET['doc'] : '';

$data = NULL;

$rnk_id = '1';

$rt = '1';

// مستخدم أو عدة مستخدمين
if (isset( $_GET['id']) AND $_GET['id'] !=='' AND is_numeric($_GET['id'])){ 

   $data = array('id' => $_GET['id']);
   
}
 
// إداري أو أستاذ أو عامل 
if (isset( $_GET['rnk_id']) AND $_GET['rnk_id'] !=='' AND is_numeric($_GET['rnk_id'])){ 

   $rnk_id = $_GET['rnk_id'];

   $data = array('rank_id' => $rnk_id);
   
}

// دخول أو خروج
if (isset( $_GET['rt']) AND $_GET['rt'] !=='' AND is_numeric($_GET['rt'])){ 

   $rt = $_GET['rt'];
   
}
 
if(isset($_SESSION['educ_institution_name']) != '')
{	
    switch ( $doc ) {
        case 'form':
            $uz = $engine->toPrint('users', $data);		
            require( DIR_MODS . "/pdf/form.php" );
        break;			
        case 'certificate':
            $uz = $engine->toPrint('users', $data);		
            require( DIR_MODS . "/pdf/certificate.php" );
        break;
        break;		
        case 'wrs':
            $uz = $engine->toPrint('users', $data);		
            require( DIR_MODS . "/pdf/work_resume_statement.php" );
        break;	
        case 'nr':
            $uz = $engine->toPrint('users', $data);		
            require( DIR_MODS . "/pdf/nomination_report.php" );
        break;
        case 'ts':
            $uz = $engine->toPrint('users', $data);		
            require( DIR_MODS . "/pdf/total_services.php" );
        break;			
        case 'profitability':
            $uz = $engine->toPrint('users', $data);		
            require( DIR_MODS . "/pdf/profitability.php" );
        break;	
        case 'enexr':
            $uz = $engine->toPrint('users', $data);		
			require( DIR_MODS . "/pdf/entry_exit_report.php" );
        break;	
        default:
            header("Location: index.php");
        }

}
else
{
    echo header("Location: index.php");
}


?>