<?php
/*
-----------------------------------------------
            سكربت المدير الرقمي            
-----------------------------------------------
برمجة وتطوير: عادل قصي
البريد الإلكتروني: adelbak2014@gmail.com
الموقع الرسمي: www.cem11.com
الصفحة الرسمية للمبرمج: https://www.facebook.com/adel.qusay.9
-----------------------------------------------
السكربت مجاني، يرجى طلب الإذن عند الرغبة في
التطوير.
-----------------------------------------------
*/

require 'config.php';

if (@$_SERVER['REQUEST_METHOD'] !== 'GET' OR isset($_SESSION['educ_institution_name']) == '') { die('0'); }

$doc = isset( $_GET['doc'] ) ? $_GET['doc'] : '';

$school_year_act = explode('/', $_SESSION['school_year']);

$s_data = array('school_year' => $school_year_act[1]);
			
$data = NULL;

$rnk_id = '1';

$rt = '1';

// مستخدم أو عدة مستخدمين
if (isset( $_GET['id']) AND $_GET['id'] !=='' AND is_numeric($_GET['id'])){ 

   $data = array('id' => $_GET['id']);
   
}
 
// إداري أو أستاذ أو عامل 
if (isset( $_GET['rnk_id']) AND $_GET['rnk_id'] !=='' AND is_numeric($_GET['rnk_id'])){ 

   $rnk_id = $_GET['rnk_id'];

   $data = array('rank_id' => $rnk_id);
   
}

// دخول أو خروج
if (isset( $_GET['rt']) AND $_GET['rt'] !=='' AND is_numeric($_GET['rt'])){ 

   $rt = $_GET['rt'];
   
}

// تلميذ أو عدة تلاميذ
if (isset( $_GET['sid']) AND $_GET['sid'] !=='' AND is_numeric(trim($_GET['sid']))){ 

    $s_data = array('id' => trim($_GET['sid']));
   
}

// السنة الدراسية 
if (isset( $_GET['s1']) AND $_GET['s1'] !=='' AND is_numeric(trim($_GET['s1']))){ 

	$s_data ['school_year'] = '"'.trim($_GET['s1']).'"';
   
}

// المستوى			
if (isset( $_GET['s2']) AND $_GET['s2'] !==''){ 

   	$s_data ['level'] = '"'.trim($_GET['s2']).'"';
   
}

// الشعبة
if (isset( $_GET['s3']) AND $_GET['s3'] !==''){ 

   	$s_data ['division'] = '"'.trim($_GET['s3']).'"';
   
}

// القسم
if (isset( $_GET['s4']) AND $_GET['s4'] !=='' AND is_numeric(trim($_GET['s4']))){ 

     $s_data ['section'] = '"'.trim($_GET['s4']).'"';
   
}
 
if(isset($_SESSION['educ_institution_name']) != '')
{	
    switch ( $doc ) {
        case 'form':
            $uz = $engine->toPrint('users', $data);		
            require( DIR_MODS . "/pdf/form.php" );
        break;			
        case 'certificate':
            $uz = $engine->toPrint('users', $data);		
            require( DIR_MODS . "/pdf/certificate.php" );
        break;
        break;		
        case 'wrs':
            $uz = $engine->toPrint('users', $data);		
            require( DIR_MODS . "/pdf/work_resume_statement.php" );
        break;	
        case 'nr':
            $uz = $engine->toPrint('users', $data);		
            require( DIR_MODS . "/pdf/nomination_report.php" );
        break;
        case 'ts':
            $uz = $engine->toPrint('users', $data);		
            require( DIR_MODS . "/pdf/total_services.php" );
        break;			
        case 'profitability':
            $uz = $engine->toPrint('users', $data);		
            require( DIR_MODS . "/pdf/profitability.php" );
        break;	
        case 'enexr':
            $uz = $engine->toPrint('users', $data);		
			require( DIR_MODS . "/pdf/entry_exit_report.php" );
        break;
        case 's_certificate':
            $uz = $engine->toPrint('students', $s_data);		
            require( DIR_MODS . "/pdf/student_certificate.php" );
        break;		
        default:
            header("Location: index.php");
        }

}
else
{
    echo header("Location: index.php");
}


?>