/*
Author: TryCatch Classes
URL: http://www.trycatchclasses.com/
*/

$('document').ready(function() {

$("#aeUserForm").submit(function(e){
        var data = $("#aeUserForm").serialize();
        $.ajax({

            type: 'POST',
            url:  'server.php',
            data: data,
            beforeSend: function() {
                $("#aeUserForm-msg").fadeOut();
                $("#aeUserForm-btn").html('<i class="fa fa-spinner fa-spin"></i>');
            },
            success: function(response) {
                if (response == "1") {
                    $("#aeUserForm-msg").fadeIn(1000, function() {
                        $("#aeUserForm-msg").html('<div class="alert alert-success">تمّ حفظ البيانات بنجاح..</div>');

                    });
                    setTimeout(' window.location.href = "index.php"; ', 2000);
                } else {

                    $("#aeUserForm-msg").fadeIn(1000, function() {
                        $("#aeUserForm-msg").html('<div class="alert alert-danger">' + response + ' </div>');
                        $("#aeUserForm-btn").html('حفظ المعلومات');
	  });
                }
            }
        });
							    $('#show').DataTable().ajax.reload().draw(false);


        return false;
    });
});

$('document').ready(function() {

$("#ae-student-form").submit(function(e){
        var data = $("#ae-student-form").serialize();
        $.ajax({

            type: 'POST',
            url:  'server.php',
            data: data,
            beforeSend: function() {
                $("#ae-student-form-msg").fadeOut();
                $("#ae-student-form-btn").html('<i class="fa fa-spinner fa-spin"></i>');
            },
            success: function(response) {
                if (response == "1") {
                    $("#ae-student-form-msg").fadeIn(1000, function() {
                        $("#ae-student-form-msg").html('<div class="alert alert-success">تمّ حفظ البيانات بنجاح..</div>');

                    });
                    setTimeout(' window.location.href = "index.php?page=students"; ', 2000);
                } else {

                    $("#ae-student-form-msg").fadeIn(1000, function() {
                        $("#ae-student-form-msg").html('<div class="alert alert-danger">' + response + ' </div>');
                        $("#ae-student-form-btn").html('حفظ المعلومات');
	  });
                }
            }
        });
					$('#show').DataTable().ajax.reload().draw(false);


        return false;
    });
});


$('document').ready(function() {

$("#login-form").submit(function(e){
        var data = $("#login-form").serialize();
        $.ajax({

            type: 'POST',
            url:  'server.php',
            data: data,
            beforeSend: function() {
                $("#login-msg").fadeOut();
                $("#login-btn").html('<i class="fa fa-spinner fa-spin"></i>');
            },
            success: function(response) {
                if (response == "1") {
                    $("#login-msg").fadeIn(1000, function() {
                        $("#login-msg").html('<div class="alert alert-success">تمّ تسجيل الدخول بنجاح، سيتمّ تحويلك تلقائيا إلى لوحة التحكم..</div>');

                    });
                    setTimeout(' window.location.href = "index.php"; ', 2000);
                } else {

                    $("#login-msg").fadeIn(1000, function() {
                        $("#login-msg").html('<div class="alert alert-danger">' + response + ' </div>');
                        $("#login-btn").html('دخول');

	  });
                }
            }
			    });

        return false;
    });
});


$('document').ready(function() {

$("#settingsForm").submit(function(e){
        var data = $("#settingsForm").serialize();
        $.ajax({

            type: 'POST',
            url:  'server.php',
            data: data,
            beforeSend: function() {
                $("#settingsForm-msg").fadeOut();
                $("#settingsForm-btn").html('<i class="fa fa-spinner fa-spin"></i>');
            },
            success: function(response) {
                if (response == "1") {
                    $("#settingsForm-msg").fadeIn(1000, function() {
                        $("#settingsForm-msg").html('<div class="alert alert-success">تمّ حفظ البيانات بنجاح..</div>');

                    });
                    setTimeout(' window.location.href = "?page=logout"; ', 2000);
                } else {

                    $("#settingsForm-msg").fadeIn(1000, function() {
                        $("#settingsForm-msg").html('<div class="alert alert-danger">' + response + ' </div>');
                        $("#settingsForm-btn").html('حفظ الإعدادات');
	  });
                }
            }
        });

        return false;
    });
});

$('document').ready(function() {

$("#Import-form").submit(function(e){
        var data = $("#Import-form").serialize();
        $.ajax({

            type: 'POST',
            url:  'server.php',
            data: data,
            beforeSend: function() {
                $("#Import-msg").fadeOut();
                $("#Import-btn").html('<i class="fa fa-spinner fa-spin"></i>');
            },
            success: function(response) {
                if (response == "1") {
                    $("#Import-msg").fadeIn(1000, function() {
                        $("#Import-msg").html('<div class="alert alert-success">تمّت عملية استيراد البيانات من موقع الأرضية الرقمية بنجاح.</div>');
						  setTimeout(function(e){
                        $('#ImportModal').modal('hide');
						  }, 3000);
                    });
                } else {

                    $("#Import-msg").fadeIn(1000, function() {
                        $("#Import-msg").html('<div class="alert alert-danger">' + response + ' </div>');
                        $("#Import-btn").html('استيراد');
	  });
                }
            }
			    });
					
			$('#show').DataTable().ajax.reload().draw(false);

        return false;
    });
});

function ExucUpdate(RemoteFile) {
        
		$.ajax({
            type: 'POST',
            url:  'server.php',
            data: 'act=SDDU&rf=' + RemoteFile + '',
            beforeSend: function() {
                $("#modal-update-now-btn").html('<i class="fa fa-spinner fa-spin"></i>');
            },
            success: function(response) {
                if (response == "1") {
     				document.getElementById("modal-update-now-btn").className = "btn btn-success btn-lg btn-block";					
                    $("#modal-update-now-btn").html('هنيئا، تمّ التحديث بنجاح');
                    setTimeout(' window.location.href = "?page=login&a=au"; ', 3000);
                } else {
     				document.getElementById("modal-update-now-btn").className = "btn btn-danger btn-lg btn-block";			
                    $("#modal-update-now-btn").html(response);
	            }
			}
			
			});	
}				
