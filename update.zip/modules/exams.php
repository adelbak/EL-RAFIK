<?php 
/*
-----------------------------------------------
            برنامج الرفيق            
-----------------------------------------------
برمجة وتطوير: عادل قصي
البريد الإلكتروني: adelbak2014@gmail.com
الموقع الرسمي: https://github.com/adelbak/EL-RAFIK
الصفحة الرسمية للمبرمج: https://www.facebook.com/adel.qusay.9
-----------------------------------------------
*/

	include_once DIR_MODS . '/includes/header.inc.php';

?>

	<body>
		<?php 
		if ( $_SESSION['last_up_check'] < (time() - 60*15) ) { 
			$engine->checkUpdate(); 
		}
	?>
			<?php include_once DIR_MODS . '/includes/navbar.inc.php'; ?>
				<!---Section-->
				<section id="sections" class="py-4 bg-faded">
					<div class="container">
						<div class="row">
							<?php $engine->settingsChecker(); ?>
								<div class="col-md-6">
									<select id="selectExam" name="selectExam" class="show-menu-arrow form-control" required>
										<?php $engine->optionsExams(); ?>
									</select>
								</div>
								<div class="col-md-2">
									<button type="submit" class="btn btn-warning btn-block text-white" onclick="deleteExam()" title="حذف الامتحان"> <i class="fa fa-trash "></i> حذف الامتحان </button>
								</div>
								<div class="col-md-2">
									<button type="submit" class="btn btn-danger btn-block text-white" onclick="deleteExams()" title="حذف الامتحانات"> <i class="fa fa-exclamation-triangle "></i> حذف الامتحانات </button>
								</div>
								<div class="col-md-2">
									<button type="submit" class="btn btn-success btn-block text-white" data-toggle="modal" data-target="#exam-modal" title="إعداد امتحان"> <i class="fa fa-plus"></i> إعداد امتحان </button>
								</div>
						</div>
					</div>
					</section>
				<!--POSTS-->
				<section id="exams" class="py-4 mb-4">
					<div id="examSettings" class="container"> </div>
				</section>
				<div class="modal fade" id="exam-modal" tabindex="-1" role="dialog" aria-labelledby="exam-modal" aria-hidden="true">
					<div class="modal-dialog modal-lg" role="document">
						<div class="modal-content e-modal">
							<div class="modal-header">
								<h5 class="modal-title">إعداد الامتحان</h5>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">×</span> </button>
							</div>
							<div class="modal-body p-4" id="result">
								<div id="add-exam-form-msg">
									<!-- الخطأ يظهر هنا ! -->
								</div>
								<form id="add-exam-form">
									<input type="hidden" name="act" class="form-control" id="act" value="addExam" title="">
									<input type="hidden" name="id" class="form-control" id="id" value="" title="">
									<div class="form-group">
										<div class="row">
											<div class="col-md-4">
												<label for="schoolYear">السنة الدراسية:</label>
												<select id="schoolYear" name="schoolYear" class="selectpicker show-menu-arrow form-control" required>
												    <option value="" selected="selected">--الرجاء الاختيار --</option>
												    <?php $engine->getForExamSelectOptions('school_year'); ?>
												</select>
											</div>
											<div class="col-md-8">
												<label for="title">العنوان:</label>
												<input type="text" id="title" name="title" class="form-control" maxlength="250" placeholder="" required> </div>
										</div>
										<div class="row">
											<div class="col-md-4">
												<label for="levels">المستويات:</label>
												<select id="levels" name="levels[]" class="selectpicker show-menu-arrow form-control" multiple required>
													<?php $engine->optionsLevels(); ?>
												</select>
											</div>
											<div class="col-md-8">
												<label for="divisions">الشعب:</label>
												<select id="divisions" name="divisions[]" class="selectpicker show-menu-arrow form-control" multiple required <?php if($_SESSION['educ_institution'] != 'ثانوية'){ echo 'disabled'; }?>>
													<?php $engine->optionsDivisions(); ?>
												</select>
											</div>
										</div>
									</div>
									<div class="form-group">
										<div class="row">
											<div class="col-md-6">
												<label for="center">المركز:</label>
												<input type="text" id="center" name="center" class="form-control" maxlength="250" placeholder="" required> </div>
											<div class="col-md-3">
												<label for="sections">عدد القاعات:</label>
												<input type="number" id="sections" name="sections" class="form-control" min="1" max="100" step="1" placeholder="" number="true" required> </div>
											<div class="col-md-3">
												<label for="sectionN">سعة القاعة:</label>
												<input type="number" id="sectionN" name="sectionN" class="form-control" min="1" max="100" step="1" placeholder="" number="true" required> </div>
										</div>
										<div class="row">
											<div class="col-md-4">
												<label for="surplusO">الفائض:</label>
												<select id="surplusO" name="surplusO" class="selectpicker show-menu-arrow form-control" required>
													<option value="" selected="selected">-- يرجى الاختيار --</option>
													<option value="1">توزيع على القاعات المتاحة فقط</option>
													<option value="2">توزيع على قاعات إضافية</option>
												</select>
											</div>
											<div class="col-md-8 alert-surplusO" style="font-size:13px; display:none">
												<div id="alert-surplusO-text" class="text-danger" style="padding-top: 40px;"> </div>
											</div>
										</div>
									</div>
									<div class="form-group">
										<div class="row">
											<div class="col-md-12">
												<label for="excStudents">استثناء تلاميذ:</label>
												<select id="excStudents" name="excStudents[]" class="selectpicker show-menu-arrow form-control" multiple data-live-search="true">
													<?php $engine->optionsStudents(); ?>
												</select>
											</div>
										</div>
									</div>
									<div class="form-group">
										<div class="row">
											<div class="col-md-6">
												<label for="rankingO">ترتيب التلاميذ:</label>
												<select name="rankingO" class="selectpicker show-menu-arrow form-control" required>
													<option value="" selected="selected">-- يرجى الاختيار --</option>
													<option value="1">الاسم</option>
													<option value="2">اللقب</option>
													<option value="3">رقم التعريف</option>
													<option value="4">الجنس</option>
													<option value="5">الجنس تداوليا</option>
													<option value="6">العمر</option>
													<option value="7">عشوائي</option>
												</select>
											</div>
											<div class="col-md-3">
												<label for="rankingS">اتجاه الترتيب:</label>
												<select name="rankingS" class="selectpicker show-menu-arrow form-control" required>
													<option value="" selected="selected">-- يرجى الاختيار --</option>
													<option value="1">تصاعديا</option>
													<option value="2">تنازليا</option>
												</select>
											</div>
											<div class="col-md-3">
												<label for="studentsStartNum">أرقام التلاميذ تبدأ من:</label>
												<input type="number" id="studentsStartNum" name="studentsStartNum" class="form-control" min="0" max="100000000" step="10" placeholder="" number="true" required> </div>
										</div>
									</div>
							</div>
							<div class="modal-footer">
								<div class="btn-group">
									<button type="submit" class="btn btn-lg btn-success" id="add-exam-form-btn">حــفظ</button>
									<button type="button" class="btn btn-lg btn-danger" data-dismiss="modal">تراجع</button>
								</div>
							</div>
							</form>
						</div>
					</div>
				</div>
				<?php include_once DIR_MODS . '/includes/footer.inc.php'; ?>
					<script type="text/javascript" language="javascript" class="init">
					$(document).ready(function() {
						$('#surplusO').on('change', function() {
							var surplusO = $('#surplusO').val();
							if(surplusO == '1') {
								$('.alert-surplusO').css('display', 'block');
								$("#alert-surplusO-text").html('قد لا يلتزم النظام بالسعة المحدّدة لكل قاعة، لكن يلتزم بعدد القاعات.');
							} else if(surplusO == '2') {
								$('.alert-surplusO').css('display', 'block');
								$("#alert-surplusO-text").html('قد لا يلتزم النظام بعدد القاعات المحدّدة، ربما يضيف قاعات حسب الحاجة، لكن يلتزم بسعة كل قاعة.');
							} else {
								$('.alert-surplusO').css('display', 'none');
							}
						});
						$('#selectExam').on('change', function() {
							var selectExam = $('#selectExam').val();
							$.ajax({
								type: 'POST',
								url: 'server.php',
								data: {
									act: 'getExam',
									id: selectExam,
								},
								beforeSend: function() {
									$("#examSettings").addClass('text-center');
									$("#examSettings").html('<i class="fa fa-spinner fa-spin" style="font-size:200px"></i>'); // add loader
								},
								success: function(response) {
									if(response) {
										$("#examSettings").removeClass('text-center');
										$("#examSettings").html(response);
									};
								}
							});
						});
						$.validator.setDefaults({
							highlight: function(element) {
								$(element).addClass('is-invalid').removeClass('is-valid');
							},
							unhighlight: function(element) {
								$(element).removeClass('is-invalid').addClass('is-valid');
							},
							errorElement: 'div ',
							errorClass: 'invalid-feedback',
							errorPlacement: function(error, element) {
								if(element.parent('.input-group').length) {
									error.insertAfter(element.parent());
								} else if($(element).is('.select')) {
									element.next().after(error);
								} else if(element.hasClass('select2')) {
									//error.insertAfter(element);
									error.insertAfter(element.next());
								} else if(element.hasClass('selectpicker')) {
									error.insertAfter(element.next());
								} else {
									error.insertAfter(element);
								}
							},
							submitHandler: function(form) {
								var data = $("#add-exam-form").serialize();
								$.ajax({
									type: 'POST',
									url: 'server.php',
									data: data,
									beforeSend: function() {
										$("#add-exam-form-msg").fadeOut();
										$("#add-exam-form-btn").html('<i class="fa fa-spinner fa-spin"></i>');
									},
									success: function(response) {
										if(response == "1") {
											$("#add-exam-form-msg").fadeIn(1000, function() {
												$("#add-exam-form-msg").html('<div class="alert alert-success">تمّ حفظ البيانات بنجاح..</div>');
											});
											setTimeout(function(e) {
												$('.modal').modal('hide');
												location.reload();
											}, 3000);

										} else {
											$("#add-exam-form-msg").fadeIn(1000, function() {
												$("#add-exam-form-msg").html('<div class="alert alert-danger">' + response + ' </div>');
												$("#add-exam-form-btn").html('حفظ المعلومات');
											});
										}
									}
								});
								return false;
							}
						});
						// Base Form Class
						$('#add-exam-form').validate();
					});

					function deleteExam() {
						var selectExam = $('#selectExam').val();
						swal({
							title: 'هل أنت متأكد من حذف الإعداد؟',
							text: "لن تتمكن من التراجع عن هذا!",
							type: 'warning',
							showCancelButton: true,
							confirmButtonColor: '#3085d6',
							cancelButtonColor: '#d33',
							cancelButtonText: 'تراجع',
							confirmButtonText: 'نعم، احذف!'
						}).then((result) => {
							if(result.value) {
								$.post("server.php", {
									act: 'deleteExam',
									id: selectExam,
								}, (data, status) => {
									if(data === "1") {
										swal({
											type: 'success',
											title: 'تمت عملية الحذف بنجاح',
											showConfirmButton: false,
											timer: 1500
										})
										location.reload();
									} else {
										swal({
											type: 'error',
											title: 'حدث خطأ ما :(',
											showConfirmButton: false,
											timer: 1500
										})
									}
								});
							}
						})
					}

					function deleteExams() {
						swal({
							title: 'هل أنت متأكد من حذف جميع البيانات',
							text: "لن تتمكن من التراجع عن هذا!",
							type: 'warning',
							showCancelButton: true,
							confirmButtonColor: '#3085d6',
							cancelButtonColor: '#d33',
							cancelButtonText: 'تراجع',
							confirmButtonText: 'نعم، احذف!'
						}).then((result) => {
							if(result.value) {
								$.post("server.php", {
									act: 'deleteExams',
								}, (data, status) => {
									if(data === "1") {
										swal({
											type: 'success',
											title: 'تمّت عملية الحذف بنجاح',
											showConfirmButton: false,
											timer: 1500
										})
										location.reload();
									} else {
										swal({
											type: 'error',
											title: 'حدث خطأ ما :(',
											showConfirmButton: false,
											timer: 1500
										})
									}
								});
							}
						})
					}
					</script>
					<script src="<?php echo HOME_URL . '/assets/js/popper.min.js'; ?>"></script>
					<script src="<?php echo HOME_URL . '/assets/js/bootstrap.min.js'; ?>"></script>
					<script src="<?php echo HOME_URL . '/assets/js/jquery-validation/jquery.validate.min.js'; ?>"></script>
					<script src="<?php echo HOME_URL . '/assets/js/jquery-validation/localization/messages_ar.js'; ?>"></script>
					<script src="<?php echo HOME_URL . '/assets/js/bootstrap-select.min.js'; ?>"></script>
	</body>

	</html>