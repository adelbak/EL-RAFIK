<?php
/*
-----------------------------------------------
            سكربت الرفيق            
-----------------------------------------------
برمجة وتطوير: عادل قصي
البريد الإلكتروني: adelbak2014@gmail.com
الموقع الرسمي: www.cem11.com
الصفحة الرسمية للمبرمج: https://www.facebook.com/adel.qusay.9
-----------------------------------------------
السكربت مجاني، يرجى طلب الإذن عند الرغبة في
التطوير.
-----------------------------------------------
*/

include_once DIR_MODS . '/includes/header.inc.php';
?>

    <body>
	
        <?php 
		    if ( $_SESSION['last_up_check'] < (time() - 60*15) ) { 
    	        $engine->checkUpdate(); 
            }
	    ?>
		
        <?php include_once DIR_MODS . '/includes/navbar.inc.php'; ?>


            <section id="posts" class="py-4 mb-4">
                <div class="container">
                    <div class="card">
                        <div class="card-header">
                        </div>
                        <div class="card-body">
                              <div class="alert alert-vdanger" role="alert">
                                <p>تحليل النتائج في مراحله التجريبية قريبا.</p>
							  </div>
                        </div>
                    </div>
                </div>
            </section>



            <?php include_once DIR_MODS . '/includes/footer.inc.php'; ?>
            <script src="<?php echo HOME_URL . '/assets/js/bootstrap.min.js'; ?>"></script>

    </body>

    </html>