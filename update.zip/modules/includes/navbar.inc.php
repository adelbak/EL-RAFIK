        <nav class="navbar navbar-expand-lg navbar-dark bg-dark p-0">
            <div class="container">
                <a href="index.php" class="navbar-brand mr-3"><i class="fa fa-user-circle"></i> المدير الرقمي</a>
                <div class="collapse navbar-collapse" id="mynavbar">
                    <ul class="navbar-nav">
                        <li class="nav-item px-2">
                            <a href="?page=settings" class="nav-link <?php if($_SERVER['QUERY_STRING'] == 'page=settings') echo 'active'; ?>">إعدادات البرنامج</a>
                        </li>					
                        <li class="nav-item px-2">
                            <a href="?page=users" class="nav-link <?php if(!isset($_SERVER['QUERY_STRING']) or $_SERVER['QUERY_STRING'] == 'page=users') echo 'active'; ?>">تسيير المستخدمين</a>
                        </li>
                        <li class="nav-item px-2">
                            <a href="#" onclick="TUC()" class="nav-link <?php if(!isset($_SERVER['QUERY_STRING']) or $_SERVER['QUERY_STRING'] == 'page=students') echo 'active'; ?>">التلاميذ</a>
                        </li>						
                        <li class="nav-item dropdown mr-3">
                            <a href="#" class="nav-link dropdown-toggle <?php if($_SERVER['QUERY_STRING'] == 'page=cem_notes' or $_SERVER['QUERY_STRING'] == 'page=lycee_notes' or $_SERVER['QUERY_STRING'] == 'page=prem_notes') echo 'active'; ?>" data-toggle="dropdown">رقمنة</a>
                            <div class="dropdown-menu">
                                <a href="?page=cem_notes" class="dropdown-item"><i class="fa fa-upload"></i> متوسط</a>
                                <a href="#" class="dropdown-item" onclick="UC()"><i class="fa fa-upload"></i> ثانوي</a>
                                <a href="#" class="dropdown-item" onclick="UC()"><i class="fa fa-upload"></i> ابتدائي</a>
                            </div>
                        </li>
                        <li class="nav-item px-2 mt-1">
                            <a href="https://amatti.education.gov.dz/" target="_blank" title="زيارة موقع الأرضية الرقمية"><img src="<?php echo HOME_URL . '/assets/img/amatti.png'; ?>" alt="زيارة موقع الأرضية الرقمية"></a>							
                        </li>						
                    </ul>						
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item mr-3">
                            <a href="#" class="nav-link">
                                <i class="fa fa-graduation-cap"></i> <?php if(isset($_SESSION['educ_institution_name']) AND $_SESSION['educ_institution_name'] !==''){ echo $_SESSION['educ_institution_name'];} if(isset($_SESSION['iap']) AND $_SESSION['iap'] !==''){ echo ' ('.$_SESSION['iap'].')'; } ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="?page=logout" class="nav-link"><i class="fa fa-user-times"></i> خروج</a>
                        </li>
                    </ul>
                </div>				
            </div>
        </nav>
