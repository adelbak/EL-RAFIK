        <script>
		        function UC() {
                    swal({
                      type: 'error',
                      confirmButtonText: 'أنا في الانتظار..',					  					  
                      title: 'عذرا...',
                      text: 'هذه الخدمة قيد التطوير',
                      footer: '<a href="https://www.djelfa.info/vb/showthread.php?t=2165486" target="_blank">تابع الموضوع الرسمي هنا</a>'
                    })
				}	
		        function TUC() {
                    swal({
                      type: 'info',
                      confirmButtonText: 'أنا في الانتظار..',					  
                      title: 'قريبا جدا..',
                      text: 'سيتم إطلاق هذا التحديث خلال أيام، ومن خلاله ستتمكن من تحميل الشهادات المدرسية مباشرة من موقع الأرضية لكل التلاميذ دفعة واحدة.',
                      footer: '<a href="https://www.djelfa.info/vb/showthread.php?t=2165486" target="_blank">تابع الموضوع الرسمي هنا</a>'
                    })
				}	
        </script>

        <footer id="main-footer" class="text-center text-white bg-dark">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <p class="lead">النسخة (<?php echo APP_VERSION; ?>) برمجة وتطوير : عادل قصي</p>
                    </div>
                </div>
            </div>
        </footer>