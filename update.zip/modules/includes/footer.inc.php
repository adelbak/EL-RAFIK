        <footer id="main-footer" class="text-center text-white bg-primary">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <p class="lead">برمجة وتطوير : <i class="fa fa-heart"></i> عادل قصي (متوسطة 11 ديسمبر 1960 - الجلفة)</p>
                    </div>
                </div>
            </div>
        </footer>