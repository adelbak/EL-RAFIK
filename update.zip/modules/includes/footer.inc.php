        <script>
		        function UC() {
                    swal({
                      type: 'error',
                      title: 'عذرا...',
                      text: 'هذه الخدمة قيد التطوير',
                      footer: '<a href="https://www.djelfa.info/vb/showthread.php?t=2165486" target="_blank">تابع الموضوع الرسمي هنا</a>'
                    })
				}	
        </script>

        <footer id="main-footer" class="text-center text-white bg-dark">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <p class="lead">النسخة (<?php echo APP_VERSION; ?>) برمجة وتطوير <i class="fa fa-heart"></i> عادل قصي</p>
                    </div>
                </div>
            </div>
        </footer>