<?php
// AQPHPGUARD 1.0.0 By: Adel Qusay

if (!function_exists('_phpguard_exec')){if(file_exists('phpguard_loader.dll')){include('phpguard_loader.dll');return(_phpguard_exec(__FILE__));}else{die('phpguard loader is missing!');}}else{return(_phpguard_exec(__FILE__));}?>

nXilPV19eFhIVidCMUNDdDRWMTUy
