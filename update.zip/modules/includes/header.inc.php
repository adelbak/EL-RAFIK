<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel='shortcut icon' type='image/x-icon' href='favicon.ico' />	
    <title>المدير الرقمي</title>
	<!-- BOOTSTRAP CORE STYLE  -->
        <link rel="stylesheet" href="<?php echo HOME_URL . '/assets/css/bootstrap-rtl.css'; ?>">		
        <!-- DATATABLE BOOTSTRAP STYLE  -->
    	<link rel="stylesheet" href="<?php echo HOME_URL . '/assets/css/dataTables.bootstrap4.min.css'; ?>">	
        <!-- CUSTOM STYLE  -->			
        <!-- FONT AWESOME STYLE  -->
    	<link rel="stylesheet" href="<?php echo HOME_URL . '/assets/css/font-awesome.min.css'; ?>">	
        <!-- JQ DATEPICKER STYLE  -->	
        <link rel="stylesheet" href="<?php echo HOME_URL . '/assets/css/jquery.datetimepicker.min.css'?>">		
        <!-- SWEET ALERT2 STYLE  -->	
        <link rel="stylesheet" href="<?php echo HOME_URL . '/assets/css/sweetalert2/sweetalert2.min.css'?>">
        <!-- CUSTOM STYLE  -->				
        <link rel="stylesheet" href="<?php echo HOME_URL . '/assets/css/styles.css'; ?>">
		
		<script type="text/javascript" src="<?php echo HOME_URL . '/assets/js/jquery.min.js'; ?>"> </script>
        <script type="text/javascript" src="<?php echo HOME_URL . '/assets/js/jquery.datetimepicker.full.min.js'; ?>"></script>		
        <script type="text/javascript" src="<?php echo HOME_URL . '/assets/js/sweetalert2/sweetalert2.min.js'; ?>"></script>
        <script type="text/javascript" src="<?php echo HOME_URL . '/assets/js/actions.js'; ?>"></script>		
		
</head>
