<?php
/*
-----------------------------------------------
            برنامج الرفيق            
-----------------------------------------------
برمجة وتطوير: عادل قصي
البريد الإلكتروني: adelbak2014@gmail.com
الموقع الرسمي: https://github.com/adelbak/EL-RAFIK
الصفحة الرسمية للمبرمج: https://www.facebook.com/adel.qusay.9
-----------------------------------------------
*/

include_once DIR_MODS . '/includes/header.inc.php'; 


    if (isset($_GET['a']) && $_GET['a'] == 'au') {
						
        die( '<div class="alert alert-vdanger" role="alert">
        لقد قمت بالتحديث، أغلق البرنامج وأعد فتحه لتفعيل التحديث</div>');

    }
	
?>

	<body>
		<section id="login" class="vertical-center text-center">
			<div class="container">
				<div class="row">
					<div class="col-md-4 offset-md-4">
						<div class="card">
							<div class="card-header">
								<h5>تسجيل الدخول</h5> </div>
							<div class="card-body">
								<div id="login-msg">
									<!-- الخطأ يظهر هنا ! -->
								</div>
								<div id="login-logo"> <img src="<?php echo HOME_URL . '/assets/img/lLogo.png'; ?>" class="rounded"> </div>
								<form id="login-form">
									<div class="form-group">
										<label for="password"></label>
										<input type="password" name="password" class="form-control" minlength="6" maxlength="100" placeholder="" data-rule-required="true">
										<input type="hidden" name="act" value="login" class="form-control"> </div>
									<div class="form-group">
										<button type="submit" class="btn btn-primary btn-block" id="login-btn">دخول</button>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<script type="text/javascript" language="javascript" class="init">
		$(document).ready(function() {
			$.validator.setDefaults({
				highlight: function(element) {
					$(element).addClass('is-invalid').removeClass('is-valid');
				},
				unhighlight: function(element) {
					$(element).removeClass('is-invalid').addClass('is-valid');
				},
				errorElement: 'div ',
				errorClass: 'invalid-feedback',
				errorPlacement: function(error, element) {
					if(element.parent('.input-group').length) {
						error.insertAfter(element.parent());
					} else if($(element).is('.select')) {
						element.next().after(error);
					} else if(element.hasClass('select2')) {
						//error.insertAfter(element);
						error.insertAfter(element.next());
					} else if(element.hasClass('selectpicker')) {
						error.insertAfter(element.next());
					} else {
						error.insertAfter(element);
					}
				},
				submitHandler: function(form) {
					var data = $("#login-form").serialize();
					$.ajax({
						type: 'POST',
						url: 'server.php',
						data: data,
						beforeSend: function() {
							$("#login-msg").fadeOut();
							$("#login-btn").html('<i class="fa fa-spinner fa-spin"></i>');
						},
						success: function(response) {
							if(response == "1") {
								$("#login-msg").fadeIn(1000, function() {
									$("#login-msg").html('<div class="alert alert-success">تمّ تسجيل الدخول بنجاح ..</div>');
								});
								setTimeout(' window.location.href = "index.php"; ', 2000);
							} else {
								$("#login-msg").fadeIn(1000, function() {
									$("#login-msg").html('<div class="alert alert-danger">' + response + ' </div>');
									$("#login-btn").html('دخول');
								});
							}
						}
					});
					return false;
				}
			});
			$('#login-form').validate();
		});
		</script>
		<script src="<?php echo HOME_URL . '/assets/js/bootstrap.min.js'; ?>"></script>
		<script src="<?php echo HOME_URL . '/assets/js/jquery-validation/jquery.validate.min.js'; ?>"></script>
		<script src="<?php echo HOME_URL . '/assets/js/jquery-validation/localization/messages_ar.js'; ?>"></script>
	</body>

	</html>