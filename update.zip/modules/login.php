<?php
/*
-----------------------------------------------
            سكربت المدير الرقمي            
-----------------------------------------------
برمجة وتطوير: عادل قصي
البريد الإلكتروني: adelbak2014@gmail.com
الموقع الرسمي: www.cem11.com
الصفحة الرسمية للمبرمج: https://www.facebook.com/adel.qusay.9
-----------------------------------------------
السكربت مجاني، يرجى طلب الإذن عند الرغبة في
التطوير.
-----------------------------------------------
*/

include_once 'includes/header.inc.php'; 

    if (isset($_GET['a']) && $_GET['a'] == 'au') {
						
        die( '<div class="alert alert-vdanger" role="alert">
        لقد قمت بالتحديث، أغلق البرنامج وأعد فتحه لتفعيل التحديث</div>');

    }
?>

    <body>
	
        <!--- Header -->

        <header id="main-header" class="bg-dark py-2 text-white">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <h1><i class="fa fa-user-circle"></i> المدير الرقمي</h1>
                    </div>
                </div>
            </div>
        </header>
	<section id="sections" class="py-4 bg-faded">

	</section>        
        <!--Admin Login-->
        <section id="login" class="py-4 mb-4">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 offset-md-3">
                        <div class="card" >
                            <div class="card-header">
                              <h4>تسجيل الدخول</h4>
                            </div>
                            <div class="card-body">
                            <div id="login-msg">
                                <!-- الخطأ يظهر هنا ! -->
                            </div>							
                            <form id="login-form">
                                <div class="form-group">
                                    <label for="password">كلمة السر:</label>
                                    <input type="password" name="password" class="form-control" required>
									<input type="hidden" name="act" value="login" class="form-control">
                                </div>							
                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary btn-block" id="login-btn">دخول</button>	
								</div> 
                            </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
		
<?php include_once 'includes/footer.inc.php'; ?>
	
        
    <script src="<?php echo HOME_URL . '/assets/js/bootstrap.min.js'; ?>"></script> 
    </body>
    
</html>