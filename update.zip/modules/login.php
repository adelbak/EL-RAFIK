<?php
/*
-----------------------------------------------
            سكربت المدير الرقمي            
-----------------------------------------------
برمجة وتطوير: عادل قصي
البريد الإلكتروني: adelbak2014@gmail.com
الموقع الرسمي: www.cem11.com
الصفحة الرسمية للمبرمج: https://www.facebook.com/adel.qusay.9
-----------------------------------------------
السكربت مجاني، يرجى طلب الإذن عند الرغبة في
التطوير.
-----------------------------------------------
*/

include_once DIR_MODS . '/includes/header.inc.php'; 

    if (isset($_GET['a']) && $_GET['a'] == 'au') {
						
        die( '<div class="alert alert-vdanger" role="alert">
        لقد قمت بالتحديث، أغلق البرنامج وأعد فتحه لتفعيل التحديث</div>');

    }
?>

    <body>
	
        <!--- Header -->
	    <?php $engine->checkUpdate();  ?>
	    <?php $engine->connectAPI();  ?>
		
        <section id="login" class="vertical-center text-center">
            <div class="container">
                <div class="row">
                    <div class="col-md-4 offset-md-4">
                        <div class="card" >
                            <div class="card-header">
                              <h4>الرفيــــــــــــــــــق</h4>
                            </div>
                            <div class="card-body">
                            <div id="login-msg">
                                <!-- الخطأ يظهر هنا ! -->
                            </div>	
                            <div id="login-logo">
                                <img src="<?php echo HOME_URL . '/assets/img/llogo.png'; ?>" class="rounded" alt="SDD"> 
							</div>								        
                            <form id="login-form">
                                <div class="form-group">
                                    <label for="password"></label>
                                    <input type="password" name="password" class="form-control" required>
									<input type="hidden" name="act" value="login" class="form-control">
                                </div>							
                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary btn-block" id="login-btn">دخول</button>	
								</div> 
                            </form>
                            </div>
							<div class="card-footer">
							    <div class="alert-license">
                                     أنت تستخدم نسخة أصلية مسجلة باسم: <br>
									 <?php echo $la[1] .'-'. $la[2] .'-'. $la[3].'-'. $la[4]; ?>
								</div> 
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>	
        
    <script src="<?php echo HOME_URL . '/assets/js/bootstrap.min.js'; ?>"></script> 
    </body>
    
</html>