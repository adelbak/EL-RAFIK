<html dir="rtl" xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css" href="<?php echo HOME_URL . '/assets/css/fonts.css'; ?>" media="all">
    <script>
        setTimeout(function() {
            print();
        }, 500);
    </script>
	<title>قائمة التلاميذ</title>
</head>

<body style="font-family:'HacenTunisia', serif;">

<?php
/*
-----------------------------------------------
            برنامج الرفيق            
-----------------------------------------------
برمجة وتطوير: عادل قصي
البريد الإلكتروني: adelbak2014@gmail.com
الموقع الرسمي: https://github.com/adelbak/EL-RAFIK
الصفحة الرسمية للمبرمج: https://www.facebook.com/adel.qusay.9
-----------------------------------------------
*/

// السنة الدراسية 
if (!isset($s_data ['school_year']) OR $s_data ['school_year'] ==''){ 

	$s_data_school_year = '"كل المواسم"';
   
}else{ 

	$s_data_school_year = (@str_replace('"', '', $s_data ['school_year'])+1) .'/'. @str_replace('"', '', $s_data ['school_year']);
   
}
// المستوى			
if (!isset($s_data ['level']) OR $s_data ['level'] ==''){ 

   	$s_data ['level'] = '"كل المستويات"';
   
}

// الشعبة
if (!isset($s_data ['division']) OR $s_data ['division'] ==''){ 

   	$s_data ['division'] = '"جميع الشعب"';
   
}

// القسم
if (!isset($s_data ['section']) OR $s_data ['section'] ==''){ 

     $s_data ['section'] = '"كل الأفواج"';
   
}

//print_r($p_data);

$surname_name_width = (isset( $p_data['pGender']) AND $p_data['pGender'] == 'true' ? '22%' : '25%'); 

$birthPlaceWidth = (isset( $p_data['pAge']) AND $p_data['pAge'] == 'true' ? '12%' : '15%'); 

$sectionWidth = (isset( $p_data['pNotes']) AND $p_data['pNotes'] == 'true' ? '30%' : '35%'); 

				
				
echo '<table dir="rtl" width="100%" align="center">
        <tbody>
            <tr align="center">
                <td width="100%"><span style="font-size: 18px; font-weight: bold;">الجمهورية
				الجزائرية الديمقراطية الشعبية</span>
                    <br> <span style="font-size: 18px; font-weight: bold;">وزارة التربية الوطنية</span></td>

            </tr>

            <tr>
                <td><span style="font-size: 18px; font-weight: bold;">'.$_SESSION['iap'].'</span></td>
            </tr>
            <tr>
                <td><span style="font-size: 18px; font-weight: bold;">'.$_SESSION['educ_institution'] .' '. $_SESSION['educ_institution_name'] .' - '. $_SESSION['state'].'</span></td>
            </tr>
            <tr>';
    if ($st == '1'){ 
			
echo                '<td align="center"><span style="font-size: 28px; font-weight: bold;">قائمة التلاميذ المشطوبين</span></td>';
	}else{ 
			
echo                '<td align="center"><span style="font-size: 28px; font-weight: bold;">قائمة التلاميذ</span></td>';
	}		
echo  '</tr>								
        </tbody>
    </table>
	<table dir="rtl" width="100%" align="center">
        <tbody>
            <tr>
                <td align="right"><span style="font-size: 16px; font-weight: bold;">السنة الدراسية: '.$s_data_school_year.'</span></td>
                <td align="center"><span style="font-size: 16px; font-weight: bold;">المستوى: '.@$s_data ['level'].'</span></td>';
               if ($_SESSION['educ_institution'] == 'ثانوية') {
echo           '<td align="center"><span style="font-size: 16px; font-weight: bold;">الشعبة: '.@$s_data ['division'].'</span></td>';
                }
echo           '<td align="left"><span style="font-size: 16px; font-weight: bold;">الفوج: '.@$s_data ['section'].'</span></td>								
            </tr>				
        </tbody>
    </table>
	<table dir="rtl" style="font-size: 14px; width: 100%;" border="1" cellpadding="1" cellspacing="0"  align="center" nobr="true">	
        <thead>
            <tr>
                <th style="width:5%" align="center">
                    <div> الترتيب </div>
                </th>
                <th style="width:10%" align="center">
                    <div> ر.التسجيل </div>
                </th>
                <th style="width:'.$surname_name_width.'" align="center">
                    <div> اللقب والاسم </div>
                </th>';
               if ($p_data['pGender'] == 'true') {
echo           '<th style="width:3%" align="center">
                    <div> الجنس </div>
                </th>';
                };			
echo           '<th style="width:10%" align="center">
                    <div> تاريخ الميلاد</div>
                </th>
                <th style="width:'.$birthPlaceWidth.'" align="center">
                    <div> مكان الميلاد</div>
                </th>				
                <th style="width:'.$sectionWidth.'" align="center">
                    <div> القسم</div>
                </th>';
               if ($p_data['pAge'] == 'true') {
echo           '<th style="width:3%" align="center">
                    <div> العمر </div>
                </th>';
                };			
               if ($p_data['pNotes'] == 'true') {
echo           '<th style="width:5%" align="center">
                    <div> الملاحظات </div>
                </th>';
                };
echo        '</tr>
	    </thead>
	    <tbody>

';
$n = 0;

$uz = $engine->rankStudents($uz, $sr);

$uz = $engine->reverseStudents($uz, $srs);

foreach ($uz as $ted) {
  $n ++;	
  
        echo    '<tr>
		            <td align="center">'.$n.'</td>
                    <td align="center">'.$ted['num_inscribe'].'</td>
                    <td>'.$ted['surname'].' '.$ted['name'].'</td>';
                if ($p_data['pGender'] == 'true') {
        echo        '<td align="center">'.$ted['gender'].'</td>';
                };					
        echo    '   <td>'.$ted['birth_date'].'</td>
                    <td>'.$ted['birth_place'].'</td>
                    <td>'.$ted['level'].' '.$ted['division'].' '.$ted['section'].'</td>';
                if ($p_data['pAge'] == 'true') {
        echo        '<td align="center">'.$engine->getAge($ted['birth_date']).'</td>';
                };					
                if ($p_data['pNotes'] == 'true') {
        echo        '<td></td>';
                };					
        echo    '</tr>';

}  
echo '</tbody>
</table>';

$documentReleaseDate = ($_SESSION['documents_release_date'] == 'ON' ? date('Y-m-d') : $_SESSION['documents_release_date']); 
echo '<p style="font-size: 22 px; font-weight: bold;" align="left">حرّر في: '.$_SESSION['state'].' بتاريخ: '.$documentReleaseDate.'</p>';

?>
</body>