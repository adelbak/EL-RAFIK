<?php
/*
-----------------------------------------------
            سكربت المدير الرقمي            
-----------------------------------------------
برمجة وتطوير: عادل قصي
البريد الإلكتروني: adelbak2014@gmail.com
الموقع الرسمي: www.cem11.com
الصفحة الرسمية للمبرمج: https://www.facebook.com/adel.qusay.9
-----------------------------------------------
السكربت مجاني، يرجى طلب الإذن عند الرغبة في
التطوير.
-----------------------------------------------
*/

require_once(DIR_CORE .'/pdf/tcpdf/tcpdf.php');

// initiate PDF
// create new PDF document
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
$pdf->SetMargins(PDF_MARGIN_LEFT, 10, PDF_MARGIN_RIGHT);
$pdf->SetAutoPageBreak(true, 10);
$pdf->SetPrintHeader(false);
$pdf->SetPrintFooter(false);

$pdf->AddPage();
$pdf->setRTL(true);

$pdf->SetFont('AmattiFont', '', 16);
$pdf->Write(0, 'الجمهورية الجزائرية الديمقراطية الشعبية', '', 0, 'C', true, 0, false, false, 0);
$pdf->Write(0, 'وزارة التربية الوطنية', '', 0, 'C', true, 0, false, false, 0);

$pdf->SetFont('hacen_tunisia', '', 12);
$pdf->Write(0, $_SESSION['iap'], '', 0, 'C', true, 0, true, false, 0);
$pdf->Write(0, $_SESSION['educ_institution'] .' '. $_SESSION['educ_institution_name'] .' - '. $_SESSION['state'].' -', '', 0, 'C', true, 0, true, false, 0);

$pdf->SetFont('hacen_tunisia', '', 16);
$pdf->SetY(40);
$pdf->Write(0, 'قائمة التلاميذ', '', 0, 'C', true, 0, false, false, 0);

// السنة الدراسية 
if (!isset($s_data ['school_year']) OR $s_data ['school_year'] ==''){ 

	$s_data_school_year = '"كل المواسم"';
   
}else{ 

	$s_data_school_year = (@str_replace('"', '', $s_data ['school_year'])+1) .'/'. @str_replace('"', '', $s_data ['school_year']);
   
}
// المستوى			
if (!isset($s_data ['level']) OR $s_data ['level'] ==''){ 

   	$s_data ['level'] = '"كل المستويات"';
   
}

// الشعبة
if (!isset($s_data ['division']) OR $s_data ['division'] ==''){ 

   	$s_data ['division'] = '"جميع الشعب"';
   
}

// القسم
if (!isset($s_data ['section']) OR $s_data ['section'] ==''){ 

     $s_data ['section'] = '"كل الأفواج"';
   
}

// ترتيب القوائم
if (!isset($st) OR $st ==''){ 

     $st = 'alpha';
   
}

$pdf->SetFont('hacen_tunisia', '', 12);
if ($_SESSION['educ_institution'] != 'ثانوية') {
    $pdf->Write(0, ' السنة الدراسية: '.$s_data_school_year.' المستوى: '.@$s_data ['level'].' الفوج: '.@$s_data ['section'] , '', 0, 'C', true, 0, false, false, 0);
}else {
    $pdf->Write(0, ' السنة الدراسية: '.$s_data_school_year.' المستوى: '.@$s_data ['level'].' الشعبة: '.@$s_data ['division'].' الفوج: '.@$s_data ['section'] , '', 0, 'C', true, 0, false, false, 0);
}

$tr = '';
$n = 0;
$c_td_w = ($_SESSION['educ_institution'] != 'ثانوية' ? '13%' : '28%'); 
$n_td_w = ($_SESSION['educ_institution'] != 'ثانوية' ? '24%' : '12%'); 

if($st == 'genderM') { // ترتيب حسب الجنس
	
    uasort($uz, function ($a, $b) {
        return $a['sex'] < $b['sex'];
    });
	
}elseif($st == 'genderF') { // ترتيب حسب الجنس
    usort($uz, function ($a, $b) {
        return $a['sex'] > $b['sex'];
    });
}elseif($st == 'insO') {// ترتيب حسب رقم التسجيل
    usort($uz, function ($a, $b) {
        return $a['num_inscribe'] > $b['num_inscribe'];
    });
}elseif($st == 'insN') {// ترتيب حسب رقم التسجيل
    usort($uz, function ($a, $b) {
        return $b['num_inscribe'] > $a['num_inscribe'];
    });
	
}elseif($st == 'ageO') {// ترتيب حسب العمر
    usort($uz, function ($a, $b) {
        return $a['birth_date'] > $b['birth_date'];
    });	
}elseif($st == 'ageY') {// ترتيب حسب العمر
    usort($uz, function ($a, $b) {
        return $b['birth_date'] > $a['birth_date'];
    });	
}else{// ترتيب أبجدي
    usort($uz, function ($a, $b) {
        return $a['surname'] > $b['surname'];
    });
}

foreach ($uz as $ted) {
  $n ++;	
  
  $bpfs = (strlen(trim($ted['birth_place'])) > 40 ? 'style="font-size: 6px"' : ''); 

  $tr.= '<tr>
  <td align="center" width="5%">'.$n.'</td>
  <td align="center" width="8%"> '.$ted['num_inscribe'].'</td>  
  <td width="22%"> '.$ted['surname'].' '.$ted['name'].'</td>
  <td width="12%"> '.$ted['birth_date'].'</td>
  <td width="12%" '.$bpfs.'> '.$ted['birth_place'].'</td>
  <td width="'.$c_td_w.'"> '.$ted['level'].' '.$ted['division'].' '.$ted['section'].'</td>
 <td width="'.$n_td_w.'"></td>  
 </tr>';
}  

$tbl = <<<EOD
<table width="100%" border="1" cellpadding="1" cellspacing="0" nobr="true">
 <tr>
  <td align="center" style="background-color:#CCCCCC;" width="5%">الرقم</td>
  <td align="center" style="background-color:#CCCCCC;" width="8%">ر.التسجيل</td>
  <td align="center" style="background-color:#CCCCCC;" width="22%">اللقب والاسم</td>  
  <td align="center" style="background-color:#CCCCCC;" width="12%">تاريخ الميلاد</td>
  <td align="center" style="background-color:#CCCCCC;" width="12%">مكان الميلاد</td>    
  <td align="center" style="background-color:#CCCCCC;" width="$c_td_w">القسم</td>
  <td align="center" style="background-color:#CCCCCC;" width="$n_td_w">الملاحظات</td>    
 </tr>
 $tr
</table>
EOD;

$pdf->SetFont('hacen_tunisia', '', 9);
$pdf->SetY(55);
$pdf->writeHTML($tbl, true, false, false, false, '');

$documentReleaseDate = ($_SESSION['documents_release_date'] == 'ON' ? date('Y-m-d') : $_SESSION['documents_release_date']); 
$pdf->SetFont('hacen_tunisia', '', 12);
$pdf->Write(0, 'حرر بـ: '.$_SESSION['state'].' في: '.$documentReleaseDate, '', 0, 'L', true, 0, false, false, 0);
$pdf->Write(0, 'الختم والإمضاء', '', 0, 'L', true, 0, false, false, 0);

$pdf->Output('profitability_'.date('d-m-y').'.pdf', 'I');