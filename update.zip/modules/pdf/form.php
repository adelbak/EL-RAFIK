<?php
/*
-----------------------------------------------
            سكربت المدير الرقمي            
-----------------------------------------------
برمجة وتطوير: عادل قصي
البريد الإلكتروني: adelbak2014@gmail.com
الموقع الرسمي: www.cem11.com
الصفحة الرسمية للمبرمج: https://www.facebook.com/adel.qusay.9
-----------------------------------------------
السكربت مجاني، يرجى طلب الإذن عند الرغبة في
التطوير.
-----------------------------------------------
*/

use setasign\Fpdi;

require_once(DIR_CORE .'/pdf/tcpdf/tcpdf.php');
require_once(DIR_CORE .'/pdf/fpdi/autoload.php');

class Pdf extends Fpdi\TcpdfFpdi
{
    /**
     * "Remembers" the template id of the imported page
     */
    protected $tplId;

    /**
     * Draw an imported PDF logo on every page
     */
    function Header()
    {
        if (is_null($this->tplId)) {
            $this->setSourceFile(DIR_MODS .'/pdf/templates/form.pdf');
            $this->tplId = $this->importPage(1);
        }
        $size = $this->useImportedPage($this->tplId);
    }

    function Footer()
    {
        // emtpy method body
    }
}


// initiate PDF
$pdf = new Pdf();
$pdf->SetMargins(PDF_MARGIN_LEFT, 40, PDF_MARGIN_RIGHT);
$pdf->SetAutoPageBreak(true, 0);


// define barcode style
$style = array(
    'position' => '',
    'align' => 'C',
    'stretch' => true,
    'fitwidth' => true,
    'border' => false,
    'bgcolor' => false, //array(255,255,255),
    'text' => true
);

foreach ($uz as $u) {

    // add a page
    $pdf->AddPage();
    // Restore RTL direction
    $pdf->setRTL(true);

    $pdf->SetFont('AmattiFont', '', 16);

    $pdf->SetXY(11.5, 37);
    $pdf->Write(5, $_SESSION['iap']);

    $pdf->SetXY(33, 45.5);
    $pdf->Write(5, $_SESSION['educ_institution_name'] .' - '. $_SESSION['state']);

    $pdf->SetXY(47, 55);
    $pdf->Write(5, $_SESSION['school_year']);

    $pdf->SetFont('AmattiFont', '', 14);

    $pdf->SetXY(25, 93.5);
    $pdf->Write(5, $u['surname']);

    $pdf->SetXY(120, 93.5);
    $pdf->Write(5, $u['name']);

    $pdf->SetXY(48, 102);
    $pdf->Write(5, $u['latin_surname']);

    $pdf->SetXY(143, 102);
    $pdf->Write(5, $u['latin_name']);

    $pdf->SetXY(40, 109);
    $pdf->Write(5, $u['birth_date']);

    $pdf->SetXY(137, 109);
    $pdf->Write(5, $u['birth_place']);

    $pdf->SetXY(45, 116);
    $pdf->Write(5, $u['family_status']);

    $pdf->SetXY(153, 116.5);
    $pdf->Write(5, $u['married_women_orig_surname']);

    $pdf->SetXY(37, 125);
    $pdf->Write(5, $u['children_number']);

    $pdf->SetXY(93, 125);
    $pdf->Write(5, $u['greater_than_10_years']);

    $pdf->SetXY(136, 125); 
    $pdf->Write(5, $u['learning']);

    $pdf->SetXY(183, 125); 
    $pdf->Write(5, $u['insurers']);

    $pdf->SetXY(32, 132);
    $pdf->Write(5, $u['nationality']);

    $pdf->SetXY(127, 132);
    $pdf->Write(5, $u['father_name']);

    $pdf->SetXY(55, 139.5);
    $pdf->Write(5, $u['father_latin_name']);

    $pdf->SetXY(127, 139.5);
    $pdf->Write(5, $u['mother_surname']);

    $pdf->SetXY(32, 147);
    $pdf->Write(5, $u['mother_name']);

    $pdf->SetXY(149, 147);
    $pdf->Write(5, $u['mother_latin_surname']);

    $pdf->SetXY(55, 155);
    $pdf->Write(5, $u['mother_latin_name']);

    $pdf->SetXY(132, 155);
    $pdf->Write(5, $u['blood_type']);

    $pdf->SetXY(177, 155);
    $pdf->Write(5, $u['optical_power']);

    $pdf->SetXY(28, 162);
    $pdf->Write(5, $u['address']);

    $pdf->SetXY(176, 162);
    $pdf->Write(5, $u['postal_code']);

    $pdf->SetXY(55, 170);
    $pdf->Write(5, $u['func_id']);

    $pdf->SetXY(180, 170);
    $pdf->Write(5, $u['sector_bilateral']);

    $pdf->SetXY(42, 179);
    $pdf->Write(5, $u['current_rank']);

    $pdf->SetXY(149, 179);
    $pdf->Write(5, $u['current_rank_date']);

    $pdf->SetXY(40, 187);
    $pdf->Write(5, $u['specialization']);

    $pdf->SetXY(132, 187);
    $pdf->Write(5, $u['teaching_material']);

    $pdf->SetXY(44, 194);
    $pdf->Write(5, $u['employment_date']);

    $pdf->SetXY(143, 193.5);
    $pdf->Write(5, $u['administrative_status']);

    $pdf->SetXY(30, 202);
    $pdf->Write(5, $u['class']);

    $pdf->SetXY(146, 202);
    $pdf->Write(5, $u['class_effective_date']);

    $pdf->SetXY(78, 209);
    $pdf->Write(5, $u['c_school_employment_date']);

    $pdf->SetXY(46, 217);
    $pdf->Write(5, $u['educational_point']);

    $pdf->SetXY(150, 217);
    $pdf->Write(5, $u['educational_point_date']);

    $pdf->SetXY(60, 224);
    $pdf->Write(5, $u['last_inspection_visit_date']); 

    $pdf->SetXY(47, 231);
    $pdf->Write(5, $u['qualifications']); 

    $pdf->SetXY(70, 239);
    $pdf->Write(5, $u['postal_account_number']); 

    $pdf->SetXY(165, 239);
    $pdf->Write(5, $u['pan_key']); 

    $pdf->SetXY(70, 247.5);
    $pdf->Write(5, $u['social_security_number']); 

    $pdf->SetXY(165, 248);
    $pdf->Write(5, $u['mtutalism_number']);

    $pdf->SetXY(35, 256);
    $pdf->Write(5, $u['phone_number']); 

    $pdf->SetXY(132, 256);
    $pdf->Write(5, $u['email']); 

    $documentReleaseDate = ($_SESSION['documents_release_date'] == 'ON' ? date('Y-m-d') : $_SESSION['documents_release_date']); 
    $pdf->SetFont('AmattiFont', '', 12);
    $pdf->SetXY(50, 270); 
    $pdf->Write(5,  ' حرر بـ: '.$_SESSION['state'].' بتاريخ: '.$documentReleaseDate); 

	if(isset($_SESSION['barcode']) and $_SESSION['barcode'] == "ON")
    {	
        $pdf->SetFont('AmattiFont', '', 8);
        $pdf->SetXY(13, 265.5);
        $pdf->Write(5, 'الرمز الوظيفي للموظف');
        $pdf->write1DBarcode($u['func_id'], 'C128', 198, 270, 30, 10, 0.3, $style, 'N');
	}	
} 

$pdf->Output('form_'.date('d-m-y').'.pdf', 'I');

