<?php
/*
-----------------------------------------------
            سكربت المدير الرقمي            
-----------------------------------------------
برمجة وتطوير: عادل قصي
البريد الإلكتروني: adelbak2014@gmail.com
الموقع الرسمي: www.cem11.com
الصفحة الرسمية للمبرمج: https://www.facebook.com/adel.qusay.9
-----------------------------------------------
السكربت مجاني، يرجى طلب الإذن عند الرغبة في
التطوير.
-----------------------------------------------
*/

use setasign\Fpdi;

require_once(DIR_CORE .'/pdf/tcpdf/tcpdf.php');
require_once(DIR_CORE .'/pdf/fpdi/autoload.php');

class Pdf extends Fpdi\TcpdfFpdi
{
    /**
     * "Remembers" the template id of the imported page
     */
    protected $tplId;

    /**
     * Draw an imported PDF logo on every page
     */
    function Header()
    {
        if (is_null($this->tplId)) {
            $this->setSourceFile(DIR_MODS .'/pdf/templates/student_certificate.pdf');
            $this->tplId = $this->importPage(1);
        }
        $size = $this->useImportedPage($this->tplId);
    }

    function Footer()
    {
        // emtpy method body
    }
}

// initiate PDF
$pdf = new Pdf();
$pdf->SetMargins(PDF_MARGIN_LEFT, 0, PDF_MARGIN_RIGHT);
$pdf->SetAutoPageBreak(true, 0);


// define barcode style
$style = array(
    'position' => '',
    'align' => 'C',
    'stretch' => true,
    'fitwidth' => true,
    'border' => false,
    'bgcolor' => false, //array(255,255,255),
    'text' => true
);
// set style for barcode
$style2 = array(
    'border' => 2,
    'vpadding' => 'auto',
    'hpadding' => 'auto',
    'fgcolor' => array(0,0,0),
    'bgcolor' => false, //array(255,255,255)
    'module_width' => 1, // width of a single module in points
    'module_height' => 1 // height of a single module in points
);


foreach ($uz as $u) {

    // add a page
    $pdf->AddPage();

    // Restore RTL direction
    $pdf->setRTL(true);

    //$pdf->SetTextColor(255, 0, 0);
	if(isset($_SESSION['barcode']) and $_SESSION['barcode'] == "ON")
    {	
        $pdf->SetFont('helvetica', '', 12, '', 8);
        $pdf->write1DBarcode($u['id_num'], 'C128', 42.5, 31.5, 30, 10, 0.3, $style, 'N');
        $pdf->SetFont('AmattiFont', '', 8);
        $pdf->SetXY(170, 26.5);
        $pdf->Write(5, 'رقم التعريف المدرسي');				
	}	
    // CODE 128 AUTO

    // QRCODE,H : QR-CODE Best error correction

    $pdf->SetFont('AmattiFont', '', 16);

    $pdf->SetXY(10, 49.5);
    $pdf->Write(5, $_SESSION['iap']);
	
    $pdf->SetXY(128, 49.5);
    $pdf->Write(5, 'السنة الدراسية : '.$_SESSION['school_year']);
	
    $pdf->SetXY(10, 59.5);
    $pdf->Write(5, $_SESSION['educ_institution'] .' '. $_SESSION['educ_institution_name'] .' -'. $_SESSION['state'].'-');

    $pdf->SetXY(55, 69.5);
    $pdf->Write(5, date('Y'));
	
    $uss = (trim($u['sex']) == "ذكر" ? 'التلميذ' : 'التلميذة'); 	
    	

    $educ_institution = ($_SESSION['educ_institution'] == "المدرسة الابتدائية" ? 'مدرسة الابتدائية' : $_SESSION['educ_institution']); 	
   
	$pdf->SetXY(22.2, 100);
    $pdf->Write(5, 'يشـهــــــــــد السيــــــــــد(ة) مديـــــــــــــــر (ة) ال'.$educ_institution.'  أن '.$uss.':');

    $pdf->SetXY(21, 115);
    $pdf->Write(5, 'اللقـــب :        '.$u['surname'].'                  الإســـم   :        '.$u['name']);

	$birth_date_explode = explode('-', $u['birth_date']);
    $birth_date = ($u['d_birth_date'] == 'نعم' ? 'عام '.$birth_date_explode[0] : $u['birth_date']); 
	
    $pdf->SetXY(21, 130);
    $pdf->Write(5, 'تاريخ و مكان الازدياد:         '.$birth_date.'   بـــ: '.$u['birth_place']);

	$school_year_explode = explode('/', $_SESSION['school_year']);
	
    $title = ($u['school_year'] == $school_year_explode[1] ? '1' : '0'); 	
	
    if ($title == '1' and trim($u['sex']) == "ذكر"){
        $title = 'يتابع دراسته ';		
    }elseif($title == '1' and trim($u['sex']) == "أنثى"){
        $title = 'تتابع دراستها ';				
    }else{
	    $title = 'تابع (ت) دراسته (ها) ';		
	}
	
    $pdf->SetFont('AmattiFont', '', 20);	
    $pdf->SetY(145.5);
    $pdf->Write(5, $title, '', 0, 'C', true, 0, false, false, 0);

    $pdf->SetFont('AmattiFont', '', 16);	
    $pdf->SetXY(74, 163);
    $pdf->Write(5, ($u['school_year']+1).' / '.$u['school_year']);

    if ($_SESSION['educ_institution'] == 'ثانوية'){
        $level = 'ثانوي  '.$u['division'];
    }elseif($_SESSION['educ_institution'] == 'متوسطة'){
        $level = 'متوسط';		
    }else{
        $level = 'ابتدائي';				
    }
	
    $pdf->SetXY(73.3, 178);
    $pdf->Write(5, $u['level'].'  '.$level.'    '.$u['section']);
	
    if ($u['school_year'] == '2015'){
        $exd = '2016-06-30';
    }elseif($u['school_year'] == '2016'){
        $exd = '2017-06-30';
    }elseif($u['school_year'] == '2017'){
        $exd = '2018-06-30';
    }elseif($u['school_year'] == '2018'){
        $exd = '2019-06-30';
    }else{
        $exd = '';				
    }
	
    $snow = ($u['school_year'] == $school_year_explode[1] ? '                    إلـــى يومنــــا هــــذا' : ' تاريخ الخروج: '.$exd); 		
    $pdf->SetXY(72, 193);
    $pdf->Write(5, $u['num_inscribe'].$snow);
	
    $pdf->SetFont('AmattiFont', '', 14);		
    $documentReleaseDate = ($_SESSION['documents_release_date'] == 'ON' ? date('Y-m-d') : $_SESSION['documents_release_date']); 
    $pdf->SetY(208);
    $pdf->Write(5, 'حرر بـ'.$_SESSION['state'].' في : '.$documentReleaseDate, '', 0, 'L', true, 0, false, false, 0);

    $pdf->SetXY(19.5, 223.5);
    $pdf->Write(5, 'الكتابـــــة السابقـة للإسم و اللقب');
	
    $pdf->SetXY(127.3, 223.5);
    $pdf->Write(5, 'مدير(ة)  ال'.$educ_institution);	
	
    $pdf->SetXY(23, 238.5);
    $pdf->Write(5, $u['latin_name'].' '.$u['latin_surname']);
	
	$QRdocumentReleaseDate = str_replace('-', '.', $documentReleaseDate );
    $pdf->write2DBarcode($u['name'].' '.$u['surname'].'   تاريخ ومكان الميلاد: '.$birth_date.'   بـ: '.$u['birth_place'].'   ال'.$educ_institution.'  '.$_SESSION['educ_institution_name'].'   الفوج التربوي: '.$u['level'].'  '.$level.'    '.$u['section'].'   صدرت بـ: '.$_SESSION['state'].$QRdocumentReleaseDate.'  '.$u['id_num'], 'QRCODE,M', 200, 250, 25, 25, $style2, 'N');
}

$pdf->Output('student_certificate_'.date('d-m-y').'.pdf', 'I');

