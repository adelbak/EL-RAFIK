<html dir="rtl" xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css" href="<?php echo HOME_URL . '/assets/css/fonts.css'; ?>" media="all">
    <script>
        setTimeout(function() {
            print();
        }, 500);
    </script>
	<title>بطاقات التعريف المدرسية</title>
</head>

<body style="font-family:'HacenTunisia', serif;">

<?php
/*
-----------------------------------------------
            برنامج الرفيق            
-----------------------------------------------
برمجة وتطوير: عادل قصي
البريد الإلكتروني: adelbak2014@gmail.com
الموقع الرسمي: https://github.com/adelbak/EL-RAFIK
الصفحة الرسمية للمبرمج: https://www.facebook.com/adel.qusay.9
-----------------------------------------------
*/

// السنة الدراسية 
if (!isset($s_data ['school_year']) OR $s_data ['school_year'] ==''){ 

	$s_data_school_year = '"كل المواسم"';
   
}else{ 

	$s_data_school_year = (@str_replace('"', '', $s_data ['school_year'])+1) .'/'. @str_replace('"', '', $s_data ['school_year']);
   
}
// المستوى			
if (!isset($s_data ['level']) OR $s_data ['level'] ==''){ 

   	$s_data ['level'] = '"كل المستويات"';
   
}

// الشعبة
if (!isset($s_data ['division']) OR $s_data ['division'] ==''){ 

   	$s_data ['division'] = '"جميع الشعب"';
   
}

// القسم
if (!isset($s_data ['section']) OR $s_data ['section'] ==''){ 

     $s_data ['section'] = '"كل الأفواج"';
   
}


$n = 0;
$pb = 0;

$uz = $engine->rankStudents($uz, $sr);

$uz = $engine->reverseStudents($uz, $srs);

foreach ($uz as $ted) {
  $n ++;	
  $pb++;
  
echo'	
	<table dir="rtl" width="65%" cellpadding="1" cellspacing="0" align="center" nobr="false" style="background-repeat: no-repeat;  background-position: center center;margin-top: 10px; border:2px solid;">					
		<tbody>
            <tr>
                <td align="center"><span style="font-size: 22px; font-weight: bold;">بطاقة التعريف المدرسية</span></td>
			    <td align="center" width="15%" rowspan="3"><span style="padding:27px 20px 27px 20px; border:1px solid;">الصورة</span></td>								
				
            </tr>
            <tr>
			    <td align="center"><span style="font-size: 14px; font-weight: bold;">School Identification Card</span></td>
				
            </tr>			
            <tr>
                <td align="right"><span style="font-weight: bold;">اللقب والاسم:</span> '.$ted['surname'].' '.$ted['name'].' </td>
				
            </tr>	
            <tr>
                <td align="right" colspan="2"><span style="font-weight: bold;">تاريخ ومكان الميلاد:</span> '.$ted['birth_date'].' بـ: '.$ted['birth_place'].' </td>			
            </tr>
            <tr>
                <td align="right"><span style="font-weight: bold;">رقم القيد:</span> '.$ted['num_inscribe'].'</td>	
                <td align="center"><span style="font-size: 12px; font-weight: bold;">مدير (ة) المؤسسة:</span></td>					
            </tr>			
            <tr>
                <td align="right" colspan="2"><span style="font-weight: bold;">القسم:</span> '.$ted['level'].' '.$ted['division'].' '.$ted['section'].'</td>						
            </tr>
            <tr height="50">
                <td align="right"><span style="font-size: 12px;">متمدرس (ة) بمؤسسة: <span style="font-weight: bold;">'.$_SESSION['educ_institution'].' '.$_SESSION['educ_institution_name'].'</span> للسنة الدراسية: <span style="font-weight: bold;">'.$_SESSION['school_year'].'</span></span></td>
                <td align="right"><span style="font-family: CCode39; font-size: 14px; ">'.$ted['id_num'].'</span></td>							
				
            </tr>							
        </tbody>
    </table>
';

	if ($pb == 4){
	    echo '<div style="page-break-after:always"></div>';	
		$pb = 0;	

    }
}  



?>
</body>