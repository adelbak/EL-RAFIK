<?php
/*
-----------------------------------------------
            برنامج الرفيق            
-----------------------------------------------
برمجة وتطوير: عادل قصي
البريد الإلكتروني: adelbak2014@gmail.com
الموقع الرسمي: https://github.com/adelbak/EL-RAFIK
الصفحة الرسمية للمبرمج: https://www.facebook.com/adel.qusay.9
-----------------------------------------------
*/

use setasign\Fpdi;

require_once(DIR_CORE .'/pdf/tcpdf/tcpdf.php');
require_once(DIR_CORE .'/pdf/fpdi/autoload.php');

class Pdf extends Fpdi\TcpdfFpdi
{
    /**
     * "Remembers" the template id of the imported page
     */
    protected $tplId;

    /**
     * Draw an imported PDF logo on every page
     */
    function Header()
    {
        if (is_null($this->tplId)) {
            $this->setSourceFile(DIR_MODS .'/pdf/templates/certificate.pdf');
            $this->tplId = $this->importPage(1);
        }
        $size = $this->useImportedPage($this->tplId);
    }

    function Footer()
    {
        // emtpy method body
    }
}


// initiate PDF
$pdf = new Pdf();
$pdf->SetMargins(PDF_MARGIN_LEFT, 0, PDF_MARGIN_RIGHT);
$pdf->SetAutoPageBreak(true, 0);


// define barcode style
$style = array(
    'position' => '',
    'align' => 'C',
    'stretch' => true,
    'fitwidth' => true,
    'border' => false,
    'bgcolor' => false, //array(255,255,255),
    'text' => true
	);
// set style for barcode
$style2 = array(
    'border' => 2,
    'vpadding' => 'auto',
    'hpadding' => 'auto',
    'fgcolor' => array(0,0,0),
    'bgcolor' => false, //array(255,255,255)
    'module_width' => 1, // width of a single module in points
    'module_height' => 1 // height of a single module in points
);


foreach ($uz as $u) {

    // add a page
    $pdf->AddPage();

    // Restore RTL direction
    $pdf->setRTL(true);

    // $pdf->SetTextColor(255, 0, 0);
	if(isset($_SESSION['barcode']) and $_SESSION['barcode'] == "ON")
    {
	    if(isset($u['func_id']) and $u['func_id'] != "")
        {
            $pdf->SetFont('helvetica', '', 12, '', 8);
            $pdf->write1DBarcode($u['func_id'], 'C128', 42.5, 31.5, 30, 10, 0.3, $style, 'N');
            $pdf->SetFont('AmattiFont', '', 8);
            $pdf->SetXY(169.3, 26.5);
            $pdf->Write(5, 'الرمز الوظيفي للموظف');		
		}
	}	
    // CODE 128 AUTO

    // QRCODE,H : QR-CODE Best error correction

    $pdf->write2DBarcode(' صاحب الشهادة '.$u['surname'].' '.$u['name'].'  تاريخ تسليم الشهادة  ', 'QRCODE,M', 200, 250, 25, 25, $style2, 'N');

    $pdf->SetFont('AmattiFont', '', 16);

    $pdf->SetXY(10, 31.5);
    $pdf->Write(5, $_SESSION['iap']);

    $pdf->SetXY(10, 49.5);
    $pdf->Write(5, $_SESSION['educ_institution'] .' '. $_SESSION['educ_institution_name'] .' -'. $_SESSION['state'].'-');

    $pdf->SetXY(55, 59.5);
    $pdf->Write(5, date('Y'));

    $pdf->SetY(97.5);
    $pdf->Write(5, '(ت) يشهد السيد(ة) مدير '.$_SESSION['educ_institution'].' '.$_SESSION['educ_institution_name'] .' -'. $_SESSION['state'] .'- بأن', '', 0, 'C', true, 0, false, false, 0);

	$surname = ($u['married_women_orig_surname'] != '' ? $u['married_women_orig_surname'] : $u['surname']); 

    $pdf->SetXY(40, 111.9);
    $pdf->Write(5, $surname.' '.$u['name']);

    $pdf->SetXY(43, 126);
    $pdf->Write(5, $u['birth_date'].' بـ : '.$u['birth_place']);

    $pdf->SetXY(25.3, 140);
    $pdf->Write(5, $u['current_rank'].' الصفة : '.$u['administrative_status']);

    $pdf->SetXY(29.7, 154);
    $pdf->Write(5, $u['current_rank']);

    $pdf->SetXY(39, 168);
    $pdf->Write(5, $_SESSION['educ_institution_name'] .' -'. $_SESSION['state'].'-');

    $pdf->SetXY(93, 182);
    $pdf->Write(5, $u['employment_date']);

    $documentReleaseDate = ($_SESSION['documents_release_date'] == 'ON' ? date('Y-m-d') : $_SESSION['documents_release_date']); 
    $pdf->SetY(217.5);
    $pdf->Write(5, 'حرر بـ : '.$_SESSION['state'].' في : '.str_replace("-", "/",$documentReleaseDate), '', 0, 'L', true, 0, false, false, 0);
	
}

$pdf->Output('certificate_'.date('d-m-y').'.pdf', 'I');

