<?php
/*
-----------------------------------------------
            برنامج الرفيق            
-----------------------------------------------
برمجة وتطوير: عادل قصي
البريد الإلكتروني: adelbak2014@gmail.com
الموقع الرسمي: https://github.com/adelbak/EL-RAFIK
الصفحة الرسمية للمبرمج: https://www.facebook.com/adel.qusay.9
-----------------------------------------------
*/

use setasign\Fpdi;

require_once(DIR_CORE .'/pdf/tcpdf/tcpdf.php');
require_once(DIR_CORE .'/pdf/fpdi/autoload.php');

class Pdf extends Fpdi\TcpdfFpdi
{
    /**
     * "Remembers" the template id of the imported page
     */
    protected $tplId;

    /**
     * Draw an imported PDF logo on every page
     */
    function Header()
    {
        if (is_null($this->tplId)) {
            $this->setSourceFile(DIR_MODS .'/pdf/templates/work_resume_statement.pdf');
            $this->tplId = $this->importPage(1);
        }
        $size = $this->useImportedPage($this->tplId);
    }

    function Footer()
    {
        // emtpy method body
    }
}


// initiate PDF
$pdf = new Pdf();
$pdf->SetMargins(PDF_MARGIN_LEFT, 40, PDF_MARGIN_RIGHT);
$pdf->SetAutoPageBreak(true, 0);


// define barcode style
$style = array(
    'position' => '',
    'align' => 'C',
    'stretch' => true,
    'fitwidth' => true,
    'border' => false,
    'bgcolor' => false, //array(255,255,255),
    'text' => true
);


foreach ($uz as $u) {

    // add a page
    $pdf->AddPage();

    // Restore RTL direction
    $pdf->setRTL(true);


    $pdf->SetFont('AmattiFont', '', 16);
    $pdf->SetXY(11.5, 37);
    $pdf->Write(5, $_SESSION['iap']);

    $pdf->SetXY(33, 45.5);
    $pdf->Write(5, $_SESSION['educ_institution'].' '.$_SESSION['educ_institution_name'] .' - '. $_SESSION['state']);

    $pdf->SetFont('AmattiFont', '', 16);

    $pdf->SetXY(30, 103.5);
    $pdf->Write(5, $u['surname']);

    $pdf->SetXY(125, 103.5);
    $pdf->Write(5, $u['name']);

    $pdf->SetXY(65, 117);
    $pdf->Write(5, $u['married_women_orig_surname']);

    $pdf->SetXY(43, 130);
    $pdf->Write(5, $u['birth_date']);

    $pdf->SetXY(140, 130);
    $pdf->Write(5, $u['birth_place']);

    $pdf->SetXY(60, 144);
    $pdf->Write(5, $u['postal_account_number']); 

    $pdf->SetXY(170, 144);
    $pdf->Write(5, $u['pan_key']); 

    $pdf->SetXY(48, 156);
    $pdf->Write(5, $u['family_status']); 

    $pdf->SetXY(43, 169);
    $pdf->Write(5, $u['children_number']);

    $pdf->SetXY(101, 169);
    $pdf->Write(5, $u['greater_than_10_years']);

    $pdf->SetXY(142, 169); 
    $pdf->Write(5, $u['learning']);

    $pdf->SetXY(189, 169); 
    $pdf->Write(5, $u['insurers']);

    $pdf->SetXY(55, 182);
    $pdf->Write(5, $u['address']);

    $pdf->SetXY(32, 195);
    $pdf->Write(5, $u['current_rank']);

    $pdf->SetXY(146, 195);
    $pdf->Write(5, $u['administrative_status']);

    $pdf->SetXY(45, 208);
    $pdf->Write(5, $u['teaching_material']);

    $pdf->SetXY(153, 208);
    $pdf->Write(5, $u['specialization']);

    $resume_work_date = explode('-', $_SESSION['teachers_entry_date']);
	
    $pdf->SetXY(45, 235);
    $pdf->Write(5, $resume_work_date[2]);

    $pdf->SetXY(80, 235);
    $pdf->Write(5, $resume_work_date[1]);

    $pdf->SetXY(120, 235); 
    $pdf->Write(5, $resume_work_date[0]);

    $documentReleaseDate = ($_SESSION['documents_release_date'] == 'ON' ? date('Y-m-d') : $_SESSION['documents_release_date']); 
    $pdf->SetXY(60, 245); 
    $pdf->Write(5,  ' حرر بـ: '.$_SESSION['state'].' بتاريخ: '.$documentReleaseDate, '', 0, 'L', true, 0, false, false, 0); 


	if(isset($_SESSION['barcode']) and $_SESSION['barcode'] == "ON")
    {	
        $pdf->SetFont('AmattiFont', '', 8);
        $pdf->SetXY(13, 265.5);
        $pdf->Write(5, 'الرمز الوظيفي للموظف');
        $pdf->write1DBarcode($u['func_id'], 'C128', 198, 270, 30, 10, 0.3, $style, 'N');
	}	

} 

$pdf->Output('wrs_'.date('d-m-y').'.pdf', 'I');
