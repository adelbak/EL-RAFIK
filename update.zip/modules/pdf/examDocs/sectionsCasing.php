<?php
/*
-----------------------------------------------
            برنامج الرفيق            
-----------------------------------------------
برمجة وتطوير: عادل قصي
البريد الإلكتروني: adelbak2014@gmail.com
الموقع الرسمي: https://github.com/adelbak/EL-RAFIK
الصفحة الرسمية للمبرمج: https://www.facebook.com/adel.qusay.9
-----------------------------------------------
*/

use setasign\Fpdi;

require_once(DIR_CORE .'/pdf/tcpdf/tcpdf.php');
require_once(DIR_CORE .'/pdf/fpdi/autoload.php');

class Pdf extends Fpdi\TcpdfFpdi
{
    /**
     * "Remembers" the template id of the imported page
     */
    protected $tplId;

    /**
     * Draw an imported PDF logo on every page
     */
    function Header()
    {
        if (is_null($this->tplId)) {
            $this->setSourceFile(DIR_MODS .'/pdf/templates/sectionsCasing.pdf');
            $this->tplId = $this->importPage(1);
        }
        $size = $this->useImportedPage($this->tplId);
    }

    function Footer()
    {
        // emtpy method body
    }
}


// initiate PDF
$pdf = new Pdf();
$pdf->SetMargins(PDF_MARGIN_LEFT, 0, PDF_MARGIN_RIGHT);
$pdf->SetAutoPageBreak(true, 0);

$secN = 0;
$insN = $examSettingstudentsStartNum;

foreach ($filteredStudents as $filteredStudent) {

foreach ($filteredStudent as $finStudents_1) {
    $level = $finStudents_1[0]['level'];
    $sectionStudentsN = count($finStudents_1);
	
	$tr = '';
	$n = 0;	
	$secN++;

    $pdf->AddPage();
    $pdf->setRTL(true);
	
    $pdf->SetFont('hacen_tunisia', '', 16);
	$pdf->SetY(25);		
    $pdf->Write(0, 'الجمهورية الجزائرية الديمقراطية الشعبية', '', 0, 'C', true, 0, false, false, 0);
    $pdf->Write(0, 'وزارة التربية الوطنية', '', 0, 'C', true, 0, false, false, 0);

    $pdf->SetFont('hacen_tunisia', '', 12);
	$pdf->SetXY(30,40);	
    $pdf->Write(0, $_SESSION['iap'], '', 0, 'C', true, 0, true, false, 0);
	$pdf->SetX(30);	
    $pdf->Write(0, $_SESSION['educ_institution'] .' '. $_SESSION['educ_institution_name'] .' - '. $_SESSION['state'].' -', '', 0, 'C', true, 0, true, false, 0);

	
    $pdf->SetFont('hacen_tunisia', '', 24);
	$pdf->SetY(70);
    $pdf->Write(0, $examSettingTitle, '', 0, 'C', true, 0, false, false, 0);
    $pdf->Write(0, 'مركز الامتحان: '.$examSettingCenter, '', 0, 'C', true, 0, false, false, 0);
  
    $pdf->SetFont('hacen_tunisia', '', 120);
	$pdf->SetY(120);
    $pdf->Write(0, 'القاعة: '.$secN, '', 0, 'C', true, 0, false, false, 0);
        $to = (($insN+$sectionStudentsN)-1);
		


$footerTbl = <<<EOD
<table width="100%" border="0" cellpadding="1" cellspacing="0" nobr="true">
    <tr>
  		<td align="center">عدد التلاميذ: $sectionStudentsN       من: $insN إلى: $to</td>	
 	</tr>

</table>
EOD;
    $pdf->SetFont('hacen_tunisia', '', 28);
    $pdf->SetY(230);
    $pdf->writeHTML($footerTbl, true, false, false, false, '');
	$insN = ($insN+$sectionStudentsN);

}  
}


$pdf->Output('sectionsCasing_'.date('d-m-y').'.pdf', 'I');