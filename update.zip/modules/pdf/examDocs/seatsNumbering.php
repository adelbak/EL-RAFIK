<html dir="rtl" xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css" href="<?php echo HOME_URL . '/assets/css/fonts.css'; ?>" media="all">
    <script>
        setTimeout(function() {
            print();
        }, 500);
    </script>
    <title>ترقيم المقاعد</title>
</head>

<body style="font-family:'HacenTunisia', serif;">

<?php
/*
-----------------------------------------------
            برنامج الرفيق            
-----------------------------------------------
برمجة وتطوير: عادل قصي
البريد الإلكتروني: adelbak2014@gmail.com
الموقع الرسمي: https://github.com/adelbak/EL-RAFIK
الصفحة الرسمية للمبرمج: https://www.facebook.com/adel.qusay.9
-----------------------------------------------
*/

$secN = 0;  // رقم القاعة
$insN = $examSettingstudentsStartNum; // رقم بداية أرقام التسجيل
$pb = 0; // عدد البطاقات في كل صفحة

foreach ($filteredStudents as $filteredStudents_1) {

if (is_array($filteredStudents_1) and count($filteredStudents_1) > 0){
	$align = 'left';

foreach ($filteredStudents_1 as $filteredStudents_2) {

    $filteredStudents_2 = $engine->rankStudents($filteredStudents_2, $examSettingRankingO);

    $filteredStudents_2 = $engine->reverseStudents($filteredStudents_2, $examSettingRankingS);

    $level = $filteredStudents_2[0]['level']; // استخراج المستوى
    $division = $filteredStudents_2[0]['division']; // استخراج الشعبة
 
	$secN++;

	foreach ($filteredStudents_2 as $student) {
	
    $pb++;

echo'	
	<table dir="rtl" width="48%" border="1" cellpadding="1" cellspacing="0" align="'.$align.'" nobr="false" style="margin-top: 10px;">					
		<tbody>
            <tr>
                <td align="center">'.$student['surname'].' '.$student['name'].' ['.$student['birth_date'].']</td>
            </tr>
            <tr>
                <td align="center"><span style="font-size: 48px; font-weight: bold;">'.$insN.' </span></td>
            </tr>
            <tr>
                <td align="center">المركز: '.$examSettingCenter.' [القاعة: '.$secN.']</td>
            </tr>							
        </tbody>
    </table>
';
	$insN++; // زيادة رقم التسجيل
	if ($align == 'left'){$align = 'right';} else{$align = 'left';} ;
    
	
	if ($pb == 14){
		$pb = 0;	
	    echo '<div style="page-break-after:always"></div>';	
    }

	
}

}  
}
}
