<html dir="rtl" xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css" href="<?php echo HOME_URL . '/assets/css/fonts.css'; ?>" media="all">
     <script>
        setTimeout(function() {
            print();
        }, 500);
    </script>
	<title>قائمة التلاميذ</title>
</head>

<body style="font-family:'HacenTunisia', serif;">

<?php
/*
-----------------------------------------------
            برنامج الرفيق            
-----------------------------------------------
برمجة وتطوير: عادل قصي
البريد الإلكتروني: adelbak2014@gmail.com
الموقع الرسمي: https://github.com/adelbak/EL-RAFIK
الصفحة الرسمية للمبرمج: https://www.facebook.com/adel.qusay.9
-----------------------------------------------
*/

echo '<table dir="rtl" width="100%" align="center">
        <tbody>
            <tr align="center">
                <td width="100%"><span style="font-size: 18px; font-weight: bold;">الجمهورية
				الجزائرية الديمقراطية الشعبية</span>
                    <br> <span style="font-size: 18px; font-weight: bold;">وزارة التربية الوطنية</span></td>

            </tr>

            <tr>
                <td><span style="font-size: 18px; font-weight: bold;">'.$_SESSION['iap'].'</span></td>
            </tr>
            <tr>
                <td><span style="font-size: 18px; font-weight: bold;">'.$_SESSION['educ_institution'] .' '. $_SESSION['educ_institution_name'] .' - '. $_SESSION['state'].'</span></td>
            </tr>
            <tr>
                <td align="center"><span style="font-size: 28px; font-weight: bold;">قائمة التلاميذ</span></td>
            </tr>
            <tr>
                <td align="center"><span style="font-size: 18px; font-weight: bold;">'.$examSettingTitle.'</span></td>
            </tr>	
            <tr>
                <td align="center"><span style="font-size: 18px; font-weight: bold;">مركز الامتحان: '.$examSettingCenter.'</span></td>
            </tr>								
        </tbody>
    </table>
    <table dir="rtl" width="100%" align="center">
        <tbody>
            <tr>
                <td align="right"><span style="font-size: 16px; font-weight: bold;">السنة الدراسية: '.$examSettingSchoolYear.'</span></td>
                <td align="center"><span style="font-size: 16px; font-weight: bold;">المستويات: '.$implodeExamSettingLevels.'</span></td>
                <td align="center"><span style="font-size: 16px; font-weight: bold;">عدد التلاميذ: '.$finStudentsN.'</span></td>	
                <td align="left"><span style="font-size: 16px; font-weight: bold;">عدد القاعات: '.$finSectionsN.'</span></td>								
            </tr>				
        </tbody>
    </table>
    <table dir="rtl" style="font-size: 14px; width: 100%;" border="1" cellpadding="1" cellspacing="0"  align="center" nobr="true">	
        <thead>
            <tr>
                <th style="width:5%" align="center">
                    <div> الترتيب </div>
                </th>
                <th style="width:10%" align="center">
                    <div> ر.التسجيل </div>
                </th>
                <th style="width:25%" align="center">
                    <div> اللقب والاسم </div>
                </th>
                <th style="width:15%" align="center">
                    <div> تاريخ الميلاد</div>
                </th>
                <th style="width:35%" align="center">
                    <div> القسم</div>
                </th>
                <th style="width:5%" align="center">
                    <div> القاعة</div>
                </th>				
                <th style="width:5%" align="center">
                    <div> الملاحظات</div>
                </th>
            </tr>
	    </thead>
	    <tbody>

';

$n = 0;	// رقم الترتيب
$secN = 0;  // رقم القاعة
$insN = $examSettingstudentsStartNum; // رقم بداية أرقام التسجيل

foreach ($filteredStudents as $filteredStudents_1) {

if (is_array($filteredStudents_1) and count($filteredStudents_1) > 0){

foreach ($filteredStudents_1 as $filteredStudents_2) {

$filteredStudents_2 = $engine->rankStudents($filteredStudents_2, $examSettingRankingO);

$filteredStudents_2 = $engine->reverseStudents($filteredStudents_2, $examSettingRankingS);

$level = $filteredStudents_2[0]['level']; // استخراج المستوى
$division = $filteredStudents_2[0]['division']; // استخراج الشعبة

$sectionStudentsN = count($filteredStudents_2);
	$secN++; // زيادة رقم القاعة


	foreach ($filteredStudents_2 as $student) {
  		$n ++;	// زيادة الترتيب

        echo    '<tr>
		            <td align="center">'.$n.'</td>
                    <td align="center">'.$insN.'</td>
                    <td>'.$student['surname'].' '.$student['name'].'</td>
                    <td>'.$student['birth_date'].'</td>
                    <td>'.$student['level'].' '.$student['division'].' '.$student['section'].'</td>
                    <td align="center">'.$secN.'</td>					
                    <td></td>
                </tr>';

		$insN++; // زيادة رقم التسجيل

     } 

}
}

}
echo '</tbody>
</table>';

$documentReleaseDate = ($_SESSION['documents_release_date'] == 'ON' ? date('Y-m-d') : $_SESSION['documents_release_date']); 
echo '<p style="font-size: 22 px; font-weight: bold;" align="left">حرّر في: '.$_SESSION['state'].' بتاريخ: '.$documentReleaseDate.'</p>';
echo '<p style="font-size: 22 px; font-weight: bold;" align="left">رئيس (ة) المركز:</p>';

?>
</body>