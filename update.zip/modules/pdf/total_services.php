<?php
/*
-----------------------------------------------
            سكربت المدير الرقمي            
-----------------------------------------------
برمجة وتطوير: عادل قصي
البريد الإلكتروني: adelbak2014@gmail.com
الموقع الرسمي: www.cem11.com
الصفحة الرسمية للمبرمج: https://www.facebook.com/adel.qusay.9
-----------------------------------------------
السكربت مجاني، يرجى طلب الإذن عند الرغبة في
التطوير.
-----------------------------------------------
*/


require_once(DIR_CORE .'/pdf/tcpdf/tcpdf.php');

// initiate PDF
// create new PDF document
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
$pdf->SetMargins(PDF_MARGIN_LEFT, 10, PDF_MARGIN_RIGHT);
$pdf->SetAutoPageBreak(true, 0);
$pdf->SetPrintHeader(false);
$pdf->SetPrintFooter(false);


// define barcode style
$style = array(
    'position' => '',
    'align' => 'C',
    'stretch' => true,
    'fitwidth' => true,
    'border' => false,
    'bgcolor' => false, //array(255,255,255),
    'text' => true
);


foreach ($uz as $u) {

$pdf->AddPage();
$pdf->setRTL(true);

$pdf->SetFont('AmattiFont', '', 18);
$pdf->Write(0, 'الجمهورية الجزائرية الديمقراطية الشعبية', '', 0, 'C', true, 0, false, false, 0);
$pdf->Write(0, 'وزارة التربية الوطنية', '', 0, 'C', true, 0, false, false, 0);

$pdf->SetFont('hacen_tunisia', '', 12);
$pdf->Write(0, $_SESSION['iap'], '', 0, 'C', true, 0, true, false, 0);
$pdf->Write(0, 'مصلحة المستخدمين', '', 0, 'C', true, 0, true, false, 0);
$pdf->Write(0, 'رقم:', '', 0, 'C', true, 0, true, false, 0);

$pdf->SetFont('hacen_tunisia', '', 20);
$pdf->SetXY(80, 45);
$pdf->SetFillColor(191); // Grey
$pdf->Cell(50, 10, 'مجمل الخدمات', 0, 1, 'C', 1, '', 0, false, 'T', 'M'); ;
$pdf->Ln(4);

$tbl_1 = <<<EOD
<table width="100%" border="0" cellpadding="0" cellspacing="0" nobr="true">
 <tr>
  <td width="16%">اللقب والاسم:</td>
  <td width="18%">$u[surname] $u[name]</td>
  <td width="16%">تاريخ الازدياد:</td>
  <td width="16%">$u[birth_date]</td>
  <td width="16%">بـ:</td>
  <td width="18%">$u[birth_place]</td>  
 </tr>
 <tr>
  <td width="16%">الرتبة:</td>
  <td width="52%">$u[current_rank]</td>
  <td width="16%">الوضعية الإدارية:</td>
  <td width="16%">$u[administrative_status]</td>  
 </tr>
 <tr>
  <td width="16%">الوظيفة:</td>
  <td width="84%">$u[current_rank]</td>
 </tr> 
 <tr>
  <td width="16%">مكان العمل:</td>
  <td width="84%">$_SESSION[educ_institution_name] -$_SESSION[state]-</td>
 </tr>
 <tr>
  <td width="16%">تاريخ الترسيم:</td>
  <td width="18%">$u[fixing_date]</td>
  <td width="16%">الدرجة الحالية</td>
  <td width="16%">$u[class]</td>
  <td width="16%">منذ:</td>
  <td width="18%">$u[class_effective_date]</td>  
 </tr>
 <tr>
  <td width="12.5%">النقطة الإدارية:</td>
  <td width="12.5%">$u[educational_point]</td>
  <td width="12.5%">بتاريخ:</td>
  <td width="12.5%">$u[educational_point_date]</td>
  <td width="12.5%">النقطة التربوية:</td>
  <td width="12.5%">$u[administrative_point]</td>  
  <td width="12.5%">بتاريخ:</td>
  <td width="12.5%">$u[administrative_point_date]</td>    
 </tr> 
 <tr>
  <td width="100%">الشهادات العلمية:</td>
 </tr> 
</table>
EOD;

$pdf->SetFont('hacen_tunisia', '', 11);
$pdf->writeHTML($tbl_1, true, false, false, false, '');


$q_ts = json_decode($u['q_ts'], true);
				

$tr_1 = '';

for ($i = 1; $i <= 10; $i++) {
	
if( $q_ts['q_qualification_'.$i] || $q_ts['q_qualification_date_'.$i] || $q_ts['q_specialization_'.$i] ) {
  $tr_1.= '<tr>
  <td width="40%"> '.$q_ts['q_qualification_'.$i].'</td>
  <td width="20%"> '.$q_ts['q_qualification_date_'.$i].'</td>
  <td width="40%"> '.$q_ts['q_specialization_'.$i].'</td>  
 </tr>';
} 

}  

$tbl_2 = <<<EOD
<table width="100%" border="1" cellpadding="1" cellspacing="0" nobr="true">
 <tr>
  <th align="center" style="background-color:#CCCCCC;" width="40%">المؤهل</th>
  <th align="center" style="background-color:#CCCCCC;" width="20%">تاريخ الشهادة</th>
  <th align="center" style="background-color:#CCCCCC;" width="40%">التخصص</th>  
 </tr>
 $tr_1
</table>
EOD;

$pdf->writeHTML($tbl_2, true, false, false, false, '');

$t_years = 00;
$t_months = 00;
$t_days = 00;

$tr_2 = '';

for ($i = 1; $i <= 10; $i++) {
	
if( $q_ts['ts_state_'.$i] || $q_ts['ts_rank_'.$i] || $q_ts['ts_institution_'.$i] ) {
	
$diff = abs(strtotime($q_ts['ts_entry_date_'.$i]) - strtotime($q_ts['ts_exit_date_'.$i]));

$years = floor($diff / (365*60*60*24));
$months = floor(($diff - $years * 365*60*60*24) / (30*60*60*24));
$days = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24));

	
  $tr_2.= '<tr>
  <td width="12%"> '.$q_ts['ts_state_'.$i].'</td>
  <td width="23%"> '.$q_ts['ts_rank_'.$i].'</td>
  <td width="8%"> '.$q_ts['ts_administrative_status_'.$i].'</td>  
  <td width="22%"> '.$q_ts['ts_institution_'.$i].'</td>  
  
  <td width="11.5%"> '.$q_ts['ts_entry_date_'.$i].'</td>  
  <td width="11.5%"> '.$q_ts['ts_exit_date_'.$i].'</td> 
  
  <td width="4%"> '.$years.'</td>  
  <td width="4%"> '.$months.'</td>  
  <td width="4%"> '.$days.'</td>  
  
 </tr>';
 $t_years = $t_years + $years;
 $t_months = $t_months + $months;
 $t_days = $t_days + $days;
 
} else {
  $tr_2.= '<tr>
  <td width="12%"></td>
  <td width="23%"></td>
  <td width="8%"></td>  
  <td width="22%"></td>  
  
  <td width="11.5%"></td>  
  <td width="11.5%"></td> 
  
  <td width="4%"></td>  
  <td width="4%"></td>  
  <td width="4%"></td>  
  
 </tr>';
}

}  
  $tr_2.= '<tr>
  <td align="center" width="88%" style="background-color:#CCCCCC;">المجمــــوع</td>
  <td align="center" width="4%" style="background-color:#CCCCCC;"> '.$t_years.'</td>  
  <td align="center" width="4%" style="background-color:#CCCCCC;"> '.$t_months.'</td>  
  <td align="center" width="4%" style="background-color:#CCCCCC;"> '.$t_days.'</td>  
 </tr>';

 
$tbl_3 = <<<EOD
<table width="100%" border="1" cellpadding="1" cellspacing="0" nobr="true">
 <thead>
 <tr>
  <th align="center" width="12%" style="background-color:#CCCCCC;" rowspan="2">الولاية</th>
  <th align="center" width="23%" style="background-color:#CCCCCC;" rowspan="2">الرتبة</th>
  <th align="center" width="8%" style="background-color:#CCCCCC;" rowspan="2">الصفة</th>
  <th align="center" width="22%" style="background-color:#CCCCCC;" rowspan="2">المؤسسة</th>
  <th align="center" width="23%" style="background-color:#CCCCCC;" colspan="2">تاريخ مباشرة العمل ونهايته</th>
  <th align="center" width="12%" style="background-color:#CCCCCC;" colspan="3">مدة العمل</th>  
 </tr>
    <tr>
      <th align="center" style="background-color:#CCCCCC;" width="11.5%">من</th>
      <th align="center" style="background-color:#CCCCCC;" width="11.5%">إلى</th>
      <th align="center" style="background-color:#CCCCCC;" width="4%">سنة</th>
      <th align="center" style="background-color:#CCCCCC;" width="4%">شهر</th>
      <th align="center" style="background-color:#CCCCCC;" width="4%">يوم</th>
    </tr>	
 </thead>	
<tbody> 
 $tr_2
</tbody>
</table>
EOD;

$pdf->writeHTML($tbl_3, true, false, false, false, '');

$pdf->SetFont('hacen_tunisia', '', 12);
$pdf->Write(0, 'المعني (ة) مستمر في عمله (ها) إلى يومنا هذا', '', 0, 'C', true, 0, false, false, 0);

$documentReleaseDate = ($_SESSION['documents_release_date'] == 'ON' ? date('Y-m-d') : $_SESSION['documents_release_date']); 
$pdf->Write(0, 'حرر بـ: '.$_SESSION['state'].' في: '.$documentReleaseDate, '', 0, 'L', true, 0, false, false, 0);


	if(isset($_SESSION['barcode']) and $_SESSION['barcode'] == "ON")
    {	
        $pdf->SetFont('helvetica', '', 12, '', 8);
        $pdf->write1DBarcode($u['func_id'], 'C128', 42.5, 25.5, 30, 10, 0.3, $style, 'N');
        $pdf->SetFont('AmattiFont', '', 8);
        $pdf->SetXY(169.3, 20.5);
        $pdf->Write(5, 'الرمز الوظيفي للموظف');		
	}	 
}

$pdf->Output('certificate_'.date('d-m-y').'.pdf', 'I');

