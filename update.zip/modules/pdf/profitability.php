<?php
/*
-----------------------------------------------
            برنامج الرفيق            
-----------------------------------------------
برمجة وتطوير: عادل قصي
البريد الإلكتروني: adelbak2014@gmail.com
الموقع الرسمي: https://github.com/adelbak/EL-RAFIK
الصفحة الرسمية للمبرمج: https://www.facebook.com/adel.qusay.9
-----------------------------------------------
*/

require_once(DIR_CORE .'/pdf/tcpdf/tcpdf.php');

// initiate PDF
// create new PDF document
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
$pdf->SetMargins(PDF_MARGIN_LEFT, 10, PDF_MARGIN_RIGHT);
$pdf->SetAutoPageBreak(true, 0);
$pdf->SetPrintHeader(false);
$pdf->SetPrintFooter(false);

$pdf->AddPage();
$pdf->setRTL(true);

$pdf->SetFont('AmattiFont', '', 18);
$pdf->Write(0, 'الجمهورية الجزائرية الديمقراطية الشعبية', '', 0, 'C', true, 0, false, false, 0);
$pdf->Write(0, 'وزارة التربية الوطنية', '', 0, 'C', true, 0, false, false, 0);

$pdf->SetFont('hacen_tunisia', '', 12);
$pdf->Write(0, $_SESSION['iap'], '', 0, 'C', true, 0, true, false, 0);
$pdf->Write(0, $_SESSION['educ_institution'] .' '. $_SESSION['educ_institution_name'] .' - '. $_SESSION['state'].' -', '', 0, 'C', true, 0, true, false, 0);

$pdf->SetFont('hacen_tunisia', '', 16);
$pdf->SetY(40);
$pdf->Write(0, ' منحة المردودية و تحسين الأداء التسييري للثلاثي: '.$_SESSION['profitability_triplex'].' لسنة: '.$_SESSION['profitability_year'], '', 0, 'C', true, 0, false, false, 0);

$tr = '';

foreach ($uz as $ted) {
  $tr.= '<tr>
  <td align="center" width="15%">'.$ted['postal_account_number'].' '.$ted['pan_key'].'</td>
  <td width="20%"> '.$ted['surname'].' '.$ted['name'].'</td>
  <td width="30%"> '.$ted['current_rank'].'</td>
  <td align="center" width="6%">'.$ted['type'].'</td>
  <td align="center" width="6%">'.$ted['class'].'</td>
  <td align="center" width="6%">'.$ted['profitability_note'].'</td>  
  <td align="center" width="6%">'.$ted['profitability_aps'].'</td>  
  <td width="11%"> '.$ted['profitability_notes'].'</td>  
 </tr>';

}  

$tbl = <<<EOD
<table width="100%" border="1" cellpadding="1" cellspacing="0" nobr="true">
 <tr>
  <td align="center" style="background-color:#CCCCCC;" width="15%">الحساب البريدي</td>
  <td align="center" style="background-color:#CCCCCC;" width="20%">اللقب والاسم</td>
  <td align="center" style="background-color:#CCCCCC;" width="30%">الرتبة</td>
  <td align="center" style="background-color:#CCCCCC;" width="6%">الصنف</td>
  <td align="center" style="background-color:#CCCCCC;" width="6%">الدرجة</td>
  <td align="center" style="background-color:#CCCCCC;" width="6%">العلامة</td>
  <td align="center" style="background-color:#CCCCCC;" width="6%">عدد أيام الغياب</td>  
  <td align="center" style="background-color:#CCCCCC;" width="11%">الملاحظات</td>    
 </tr>
 $tr
</table>
EOD;

$pdf->SetFont('hacen_tunisia', '', 10);
$pdf->SetY(55);
$pdf->writeHTML($tbl, true, false, false, false, '');

$documentReleaseDate = ($_SESSION['documents_release_date'] == 'ON' ? date('Y-m-d') : $_SESSION['documents_release_date']); 
$pdf->SetFont('hacen_tunisia', '', 12);
$pdf->Write(0, 'حرر بـ: '.$_SESSION['state'].' في: '.$documentReleaseDate, '', 0, 'L', true, 0, false, false, 0);
$pdf->Write(0, 'الختم والإمضاء', '', 0, 'L', true, 0, false, false, 0);

$pdf->Output('profitability_'.date('d-m-y').'.pdf', 'I');