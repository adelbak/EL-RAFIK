<?php
/*
-----------------------------------------------
            سكربت المدير الرقمي            
-----------------------------------------------
برمجة وتطوير: عادل قصي
البريد الإلكتروني: adelbak2014@gmail.com
الموقع الرسمي: www.cem11.com
الصفحة الرسمية للمبرمج: https://www.facebook.com/adel.qusay.9
-----------------------------------------------
السكربت مجاني، يرجى طلب الإذن عند الرغبة في
التطوير.
-----------------------------------------------
*/

require_once(DIR_CORE .'/pdf/tcpdf/tcpdf.php');

// initiate PDF
// create new PDF document
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
$pdf->SetMargins(PDF_MARGIN_LEFT, 10, PDF_MARGIN_RIGHT);
$pdf->SetAutoPageBreak(true, 0);
$pdf->SetPrintHeader(false);
$pdf->SetPrintFooter(false);

$pdf->AddPage();
$pdf->setRTL(true);

$pdf->SetFont('AmattiFont', '', 18);
$pdf->Write(0, 'الجمهورية الجزائرية الديمقراطية الشعبية', '', 0, 'C', true, 0, false, false, 0);
$pdf->Write(0, 'وزارة التربية الوطنية', '', 0, 'C', true, 0, false, false, 0);


$pdf->SetFont('AmattiFont', '', 12);
$pdf->Write(0, $_SESSION['iap'], '', 0, 'C', true, 0, true, false, 0);
$pdf->Write(0, $_SESSION['educ_institution_name'] .' - '. $_SESSION['state'].' -', '', 0, 'C', true, 0, true, false, 0);

    switch ( $rt ) {
        case '1':
            $report_type = 'الدخول';
        break;			
        case '2':
            $report_type = 'الخروج';
        break;
        default:
            $report_type = 'الدخول';
        }

    switch ( $rnk_id ) {
        case '1':
            $ranks = 'أسلاك التدريس';
            $e_date = ($rt == '1' ? $_SESSION['teachers_entry_date'] : $_SESSION['teachers_exit_date']); 		
        break;			
        case '2':
            $ranks = 'الموظفين الإداريين';
            $e_date = ($rt == '1' ? $_SESSION['administrators_entry_date'] : $_SESSION['administrators_exit_date']); 			
        break;
        break;		
        case '3':
            $ranks = 'العمال';	
            $e_date = ($rt == '1' ? $_SESSION['administrators_entry_date'] : $_SESSION['administrators_exit_date']); 						
        break;
        default:
            $ranks = 'أسلاك التدريس';	
            $e_date = ($rt == '1' ? $_SESSION['teachers_entry_date'] : $_SESSION['teachers_exit_date']); 					
        }
		
$pdf->SetFont('AmattiFont', '', 14);
$pdf->SetY(40);
$pdf->Write(0, 'محضر '.$report_type.' الجماعي الخاص ب'.$ranks.' للموسم الدراسي: '.$_SESSION['school_year'], '', 0, 'C', true, 0, false, false, 0);


$pdf->SetFont('AmattiFont', '', 12);
$pdf->SetY(50);
$pdf->Write(0, 'أنا الممضي أسفله السيد(ة) مدير(ة): '.$_SESSION['educ_institution_name'] .' - '. $_SESSION['state'].' -', '', 0, 'C', true, 0, true, false, 0);
$pdf->Write(0, 'أشهد أن السيدات والسادة الآتية أسماؤهم قد أمضوا محضر ' .$report_type.' يوم: '.$e_date, '', 0, 'C', true, 0, true, false, 0);

$tr = '';
$num = 0;
foreach ($uz as $ted) {
  $num ++;	
  $tr.= '<tr>
  <td width="5%"> '.$num.'</td>
  <td width="25%"> '.$ted['surname'].' '.$ted['name'].'</td>
  <td width="30%"> '.$ted['current_rank'].'</td>
  <td width="15%"></td>  
  <td width="25%"> '.$ted['entry_notes'].'</td>  
 </tr>';

}  


$tbl = <<<EOD
<table width="100%" border="1" cellpadding="1" cellspacing="0" nobr="true">
 <tr>
  <td align="center" style="background-color:#CCCCCC;" width="5%">الرقم</td>
  <td align="center" style="background-color:#CCCCCC;" width="25%">اللقب والاسم</td>
  <td align="center" style="background-color:#CCCCCC;" width="30%">الرتبة</td>
  <td align="center" style="background-color:#CCCCCC;" width="15%">الإمضاء</td>
  <td align="center" style="background-color:#CCCCCC;" width="25%">الملاحظات</td>    
 </tr>
 $tr
</table>
EOD;

$pdf->SetFont('AmattiFont', '', 9);
$pdf->SetY(65);
$pdf->writeHTML($tbl, true, false, false, false, '');

$documentReleaseDate = ($_SESSION['documents_release_date'] == 'ON' ? date('Y-m-d') : $_SESSION['documents_release_date']); 
$pdf->SetFont('AmattiFont', '', 12);
$pdf->Write(0, 'حرر بـ: '.$_SESSION['state'].' في: '.$documentReleaseDate, '', 0, 'L', true, 0, false, false, 0);
$pdf->Write(0, 'الختم والإمضاء', '', 0, 'L', true, 0, false, false, 0);

$pdf->Output('enexr_'.date('d-m-y').'.pdf', 'I');

