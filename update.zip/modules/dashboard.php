<?php 
/*
-----------------------------------------------
            برنامج الرفيق            
-----------------------------------------------
برمجة وتطوير: عادل قصي
البريد الإلكتروني: adelbak2014@gmail.com
الموقع الرسمي: https://github.com/adelbak/EL-RAFIK
الصفحة الرسمية للمبرمج: https://www.facebook.com/adel.qusay.9
-----------------------------------------------
*/

include_once DIR_MODS . '/includes/header.inc.php';

?>

	<body>
		<?php 
		    if ( $_SESSION['last_up_check'] < (time() - 60*15) ) { 
    	        $engine->checkUpdate(); 
            }
	    ?>
			<?php include_once DIR_MODS . '/includes/navbar.inc.php'; ?>
				<!--- Header -->
				<header id="main-header" class="py-2 mb-2">
					<div class="container">
						<div class="row"> </div>
					</div>
				</header>
				<!--POSTS-->
				<section id="posts" class="py-5 mb-5">
					<div class="container">
						<div class="row">
							<?php $engine->settingsChecker(); ?>
								<div class="col-md-4 mx-auto">
									<div class="card bg-warning mb-3 text-center text-white">
										<div class="card-body">
											<h3>تسيير المستخدمين</h3>
											<h1 class="display-4"><i class="fa fa-user"></i><span class="counter"><?php echo $engine->countAllUsers(); ?></span></h1> <a href="?page=users" class="btn btn-outline-light btn-sm"><i class="fa fa-sign-in"></i> دخول</a> </div>
									</div>
								</div>
								<div class="col-md-4 mx-auto">
									<div class="card bg-success mb-3 text-center text-white">
										<div class="card-body">
											<h3>إدارة التلاميذ</h3>
											<h1 class="display-4"><i class="fa fa-users"></i><span class="counter"><?php echo $engine->countAllStudents(); ?></span></h1> <a href="?page=students" class="btn btn-outline-light btn-sm"><i class="fa fa-sign-in"></i> دخول</a> </div>
									</div>
								</div>
								<div class="col-md-4 mx-auto">
									<div class="card bg-info mb-3 text-center text-white">
										<div class="card-body">
											<h3>تسيير الامتحانات</h3>
											<h1 class="display-4"><i class="fa fa-graduation-cap"></i><span class="counter"><?php echo $engine->countExams(); ?></span></h1> <a href="?page=exams" class="btn btn-outline-light btn-sm"><i class="fa fa-sign-in"></i> دخول</a> </div>
									</div>
								</div>
								<div class="col-md-4 mx-auto">
									<div class="card bg-primary mb-3 text-center text-white">
										<div class="card-body">
											<h3>الإعدادات</h3>
											<h1 class="display-4"><i class="fa fa-cogs"></i></h1> <a href="?page=settings" class="btn btn-outline-light btn-sm"><i class="fa fa-sign-in"></i> دخول</a> </div>
									</div>
								</div>
								<div class="col-md-4 mx-auto">
									<div class="card bg-danger mb-3 text-center text-white">
										<div class="card-body">
											<h3 id="cu">تحديث البرنامج</h3>
											<h1 class="display-4"><i class="fa fa-arrow-up"></i></h1>
											<button id="update-btn" class="btn btn-outline-light btn-sm" onclick="checkUpdateNow()"><i class="fa fa-eye"></i> معاينة</button>
										</div>
									</div>
								</div>
								<div class="col-md-4 mx-auto">
									<div class="card bg-secondary mb-3 text-center text-white">
										<div class="card-body">
											<h3>تواصل معنا</h3>
											<h1 class="display-4"><i class="fa fa-envelope"></i></h1>
											<button class="btn btn-outline-light btn-sm" data-toggle="modal" data-target="#contactModal"><i class="fa fa-sign-in"></i> دخول</button>
										</div>
									</div>
								</div>
						</div>
					</div>
				</section>
				<?php include_once DIR_MODS . '/includes/footer.inc.php'; ?>
					<!---Modal Post -->
					<div class="modal fade" id="contactModal" tabindex="-1" role="dialog" aria-labelledby="contactModal" aria-hidden="true">
						<div class="modal-dialog" role="document">
							<div class="modal-content">
								<div class="modal-header">
									<h5 class="modal-title">نرحب باقتراحاتكم وآرائكم</h5>
									<button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
								</div>
								<div class="modal-body">
									<div id="contact-msg">
										<!-- الخطأ يظهر هنا ! -->
									</div>
									<form id="contact-form">
										<div class="form-group">
											<input type="text" name="source" class="form-control" id="source" value="<?php echo $_SESSION['educ_institution'].' '.$_SESSION['educ_institution_name']; ?>" required> </div>
										<div class="form-group">
											<textarea name="message" class="form-control" id="message" placeholder="الرسالة" required></textarea>
										</div>
										<div class="form-group">
											<button type="submit" class="btn btn-primary btn-block" id="send-btn">إرسال</button>
										</div>
								</div>
								<div class="modal-footer"> </div>
								</form>
							</div>
						</div>
					</div>
					<script>
					$('document').ready(function() {
						$("#contact-form").submit(function(e) {
							var source = $('#source').val();
							var message = $('#message').val();
							var api = <?php echo json_encode(API_URL); ?>;
							$.ajax({
								type: 'POST',
								url: 'server.php',
								data: 'op=contact&source=' + source + '&message=' + message,
								beforeSend: function() {
									$("#send-btn").html('<i class="fa fa-spinner fa-spin"></i>');
								},
								success: function(response) {
									if(response == "1") {
										$("#contact-msg").html('<div class="alert alert-success">رسالتك وصلت، شكرا لك..</div>');
										setTimeout(function(e) {
											$('#contactModal').modal('hide');
											location.reload();
										}, 3000);
									} else {
										$("#contact-msg").html('<div class="alert alert-danger">' + response + '</div>');
										setTimeout(function(e) {
											$('#contactModal').modal('hide');
											location.reload();
										}, 3000);
									};
								}
							});
							return false;
						});
						$('.counter').counterUp({
							delay: 10,
							time: 1000
						});
					});

					function checkUpdateNow() {
						$.ajax({
							type: 'POST',
							url: 'server.php',
							data: 'act=cupdate',
							beforeSend: function() {
								$("#update-btn").html('<i class="fa fa-spinner fa-spin"></i>');
							},
							success: function(response) {
								if(response) {
									$("#cu").html(response);
									$("#update-btn").html('معاينة');
								};
							}
						});
					}
					</script>
					<script src="<?php echo HOME_URL . '/assets/js/jquery.dataTables.min.js'; ?>"></script>
					<script src="<?php echo HOME_URL . '/assets/js/dataTables.bootstrap4.min.js '; ?>"></script>
					<script src="<?php echo HOME_URL . '/assets/js/bootstrap.min.js'; ?>"></script>
					<script src="<?php echo HOME_URL . '/assets/js/jquery.waypoints.min.js'; ?>"></script>
					<script src="<?php echo HOME_URL . '/assets/js/jquery.counterup.js'; ?>"></script>
	</body>

	</html>