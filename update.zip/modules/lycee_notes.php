<?php
/*
-----------------------------------------------
            سكربت المدير الرقمي            
-----------------------------------------------
برمجة وتطوير: عادل قصي
البريد الإلكتروني: adelbak2014@gmail.com
الموقع الرسمي: www.cem11.com
الصفحة الرسمية للمبرمج: https://www.facebook.com/adel.qusay.9
-----------------------------------------------
السكربت مجاني، يرجى طلب الإذن عند الرغبة في
التطوير.
-----------------------------------------------
*/

include_once 'includes/header.inc.php';
?>

    <body>
	
        <?php 
		    if ( $_SESSION['last_up_check'] < (time() - 60*15) ) { 
    	        $engine->checkUpdate(); 
            }
	    ?>
		
        <?php include_once 'includes/navbar.inc.php'; ?>


            <section id="posts" class="py-4 mb-4">
                <div class="container">
                    <div class="card">
                        <div class="card-header">
                        </div>
                        <div class="card-body">
                              <div class="alert alert-vdanger" role="alert">
                                <p>عزيزي مستخدم برنامج "المدير الرقمي "، إن خدمة توليد القوائم وإرسالها دفعة واحدة إلى موقع الرقمنة قيد التطوير، وهي في <span style="text-decoration: underline;"><strong>مراحلها الأخيرة وقيد التجريب</strong></span>، والتحديث القادم سيكون مواكبا لعملية حجز النقاط حينما تنطلق على موقع الأرضية الرقمية وسيدعم <span style="text-decoration: underline;"><strong>كل الأطوار</strong></span> ، التحديث القادم سيحمل الكثير من المفاجآت خاصة فيما يتعلق بخدمة الرقمنة (وعملية حجز نقاط كل المؤسسة ستكون خلال دقائق فقط) وطبعا التحديث سيكون مرفقا بفيديو لشرح العملية وإن كانت بسيطة وسهلة، قريبا جدا إن شاء الله، دمتم أوفياء لبرنامجنا.</p>
							  </div>
                        </div>
                    </div>
                </div>
            </section>



            <?php include_once 'includes/footer.inc.php'; ?>
            <script src="<?php echo HOME_URL . '/assets/js/bootstrap.min.js'; ?>"></script>

    </body>

    </html>