<?php 
/*
-----------------------------------------------
            سكربت المدير الرقمي            
-----------------------------------------------
برمجة وتطوير: عادل قصي
البريد الإلكتروني: adelbak2014@gmail.com
الموقع الرسمي: www.cem11.com
الصفحة الرسمية للمبرمج: https://www.facebook.com/adel.qusay.9
-----------------------------------------------
السكربت مجاني، يرجى طلب الإذن عند الرغبة في
التطوير.
-----------------------------------------------
*/

include_once 'includes/header.inc.php';

?>

    <body>

        <?php 
		    if ( $_SESSION['last_up_check'] < (time() - 60*15) ) { 
    	        $engine->checkUpdate(); 
            }
	    ?>

            <?php include_once 'includes/navbar.inc.php'; ?>

                <!---Section-->
                <section id="sections" class="py-4 bg-faded">
                    <div class="container">
                        <div class="row">
                            <?php $engine->settingsChecker(); ?>
                                <div class="col-md-6">
                                    <button type="submit" class="btn btn-danger btn-block text-white" data-toggle="modal" data-target="#ImportModal" title="استيراد التلاميذ من موقع الأرضية الرقمية">
                                        <i class="fa fa-database"></i> استيراد التلاميذ
                                    </button>
                                </div>
                            <div class="col-md-6">
                                <button type="submit" class="btn btn-warning btn-block text-white" onclick="cleanDatabase()" title="حذف بيانات التلاميذ">
                                    <i class="fa fa-exclamation-triangle "></i> حذف بيانات التلاميذ
                                </button>
                            </div>
                        </div>
                        <div class="row mt-4">
                             <div class="col-md-2">
                                <select id="select1" class="form-control">
                                    <option value="" selected="selected">--الرجاء الاختيار --</option>
									<?php $engine->getForSelectOptions('school_year'); ?>
                              </select>
                            </div>
                             <div class="col-md-3">
                                <select id="select2" class="form-control">
                                    <option value="" selected="selected">-- كل المستويات --</option>
									<?php $engine->getForSelectOptions('level'); ?>
                                </select>
                            </div>
                             <div class="col-md-3">
                                <select id="select3" class="form-control" <?php if($_SESSION['educ_institution'] != 'ثانوية'){ echo 'disabled';}?>>
                                    <option value="" selected="selected">-- جميع الشعب --</option>
									<?php $engine->getForSelectOptions('division'); ?>

                                </select>
                            </div>
                             <div class="col-md-2">
                                <select id="select4" class="form-control">
                                    <option value="" selected="selected">-- كل الأفواج --</option>
									<?php $engine->getForSelectOptions('section'); ?>
                                </select>
                            </div>
                             <div class="col-md-2 justify-content-center align-self-center">
                                    <button type="submit" class="btn btn-success btn-block text-white" onclick="studentPrintModal()" title="طباعة الشهادات المدرسية">
                                        <i class="fa fa-print"></i> شهادات مدرسية
                                    </button>
                            </div>							
                        </div>						
                    </div>
                </section>
			
                <section id="posts" class="py-4 mb-4">
                    <div class="container">
                        <div class="row">
                            <div class="col">
                                <table id="show" class="table table-striped table-bordered" cellspacing="0" width="100%">
                                    <thead class="thead thead-light">
                                        <tr>
                                            <th>رقم التعريف</th>
                                            <th>السنة الدراسية</th>											
                                            <th>اللقب</th>
                                            <th>الاسم</th>
                                            <th>الجنس</th>
                                            <th>تاريخ الميلاد</th>
                                            <th>المستوى</th>
                                            <th>الشعبة</th>
                                            <th>الفوج</th>
                                            <th>رقم التسجيل</th>
                                            <th>آخر تحديث</th>
                                            <th>العمليات</th>
                                        </tr>
                                    </thead>
                                </table>
                            </div>
                        </div>
                    </div>
                </section>

                <div class="modal fade" id="student-modal" tabindex="-1" role="dialog" aria-labelledby="student-modal" aria-hidden="true">
                    <div class="modal-dialog modal-lg" role="document">
                        <div class="modal-content s-modal">
                            <div class="modal-header">
                                <h5 class="modal-title">معلومات التلميذ <span class="note"> <i class="fa fa-bell"></i> ملحوظة: يجب ملء كل الخانات</span></h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">×</span>
                                </button>
                            </div>
                            <div class="modal-body p-4" id="result">
                                <div id="ae-student-form-msg">
                                    <!-- الخطأ يظهر هنا ! -->
                                </div>
                                <form id="ae-student-form">

                                    <div class="tabbable">
                                        <ul class="nav nav-tabs" role="tablist">
                                            <li class="nav-item"><a class="nav-link active" href="#tab1" data-toggle="tab">الحالة المدنية</a></li>
                                            <li class="nav-item"><a class="nav-link" href="#tab2" data-toggle="tab">الحالة الدراسية</a></li>
                                        </ul>

                                        <div class="tab-content">
                                            <input type="hidden" name="id" class="form-control" id="id" value="" title="">
                                            <input type="hidden" name="act" class="form-control" id="act" value="sEdit" title="">

                                            <div class="tab-pane active" id="tab1">
                                                    <div class="form-group">
                                                        <div class="row">
                                                            <div class="col-md-3">
                                                                <label for="surname">اللقب:</label>
                                                                <input type="text" id="surname" name="surname" class="form-control" required>
                                                            </div>
                                                            <div class="col-md-3">
                                                                <label for="name">الاسم:</label>
                                                                <input type="text" id="name" name="name" class="form-control" required>
                                                            </div>
                                                            <div class="col-md-3">
                                                                <label for="latin_surname">اللقب باللاتينية:</label>
                                                                <input type="text" id="latin_surname" name="latin_surname" class="form-control" required>
                                                            </div>	
                                                            <div class="col-md-3">
                                                                <label for="latin_name">الاسم باللاتينية:</label>
                                                                <input type="text" id="latin_name" name="latin_name" class="form-control" required>
                                                            </div>															
                                                       </div>
                                                    </div>  
                                                    <div class="form-group">
                                                        <div class="row">
                                                            <div class="col-md-3">
                                                                <label for="sex">الجنس:</label>
                                                                <input type="text" id="sex" name="sex" class="form-control" required>
                                                            </div>
                                                            <div class="col-md-3">
                                                                <label for="birth_date">تاريخ الميلاد:</label>
                                                                <input type="text" name="birth_date" id="datetimepicker1" value="تاريخ الطباعة" class="form-control" required>
                                                            </div>
                                                            <div class="col-md-3">
                                                                <label for="d_birth_date">حكم؟:</label>
                                                                    <select name="d_birth_date" class="form-control" required>
                                                                        <option value="" selected="selected">-- يرجى الاختيار --</option>
                                                                        <option value="نعم">نعم</option>
                                                                        <option value="لا">لا</option>
                                                                    </select>
															</div>																
                                                            <div class="col-md-3">
                                                                <label for="birth_place">مكان الميلاد:</label>
                                                                <input type="text" id="birth_place" name="birth_place" class="form-control" required>
                                                            </div>															
                                                       </div>
                                                    </div>  	
                                            </div>
                                            <div class="tab-pane" id="tab2">
                                                   <div class="form-group">
                                                        <div class="row">
                                                            <div class="col-md-3">
                                                                <label for="school_year">السنة الدراسية:</label>
                                                                <input type="text" id="school_year" name="school_year" class="form-control" disabled>
                                                                <input type="hidden" id="school_year" name="school_year" class="form-control">																
                                                            </div>														
                                                            <div class="col-md-6">
                                                                <label for="id_num">رقم التعريف:</label>
                                                                <input type="text" id="id_num" name="id_num" class="form-control" required>
                                                            </div>
                                                            <div class="col-md-3">
                                                                <label for="num_inscribe">رقم التسجيل:</label>
                                                                <input type="text" id="num_inscribe" name="num_inscribe" class="form-control" required>
                                                            </div>														
                                                       </div>
                                                    </div>  
                                                    <div class="form-group">
                                                        <div class="row">
                                                            <div class="col-md-3">
                                                                <label for="level">المستوى:</label>
                                                                <select name="level" class="form-control">
                                                                    <option value="" selected="selected">-- كل المستويات --</option>
                                                                    <?php $engine->getForSelectOptions('level'); ?>
                                                                </select> 
															</div>	
                                                            <div class="col-md-6">
                                                                <label for="division">الشعبة:</label>
                                                                <select name="division" class="form-control">
                                                                    <option value="" selected="selected">-- جميع الشعب --</option>
                                                                    <?php $engine->getForSelectOptions('division'); ?>
                                                                </select>
															</div>
                                                            <div class="col-md-3">
                                                                <label for="section">الفوج:</label>
                                                                <select name="section" class="form-control">
                                                                    <option value="" selected="selected">-- كل الأفواج --</option>
                                                                    <?php $engine->getForSelectOptions('section'); ?>
                                                                </select> 
															</div>																
                                                       </div>
                                                    </div>  	
                                            </div>
                                        </div>
                                    </div>

                            </div>

                            <div class="modal-footer">
                                <div class="btn-group">
                                    <button type="submit" class="btn btn-lg btn-success" id="ae-student-form-btn">حــفظ</button>
                                    <button type="button" class="btn btn-lg btn-primary" onclick="studentImportInfo()">استيراد البيانات الناقصة</button>									
                                    <button type="button" class="btn btn-lg btn-danger" data-dismiss="modal">تراجع</button>
                                </div>
								
                            </div>
							</form>

                        </div>
                    </div>
                </div>
		

                <div class="modal fade" id="ImportModal" tabindex="-1" role="dialog" aria-labelledby="ImportModal" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="ImportModal">استيراد التلاميذ من موقع الأرضية الرقمية</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <div id="Import-msg">
                                    <!-- الخطأ يظهر هنا ! -->
                                </div>
                                <form id="Import-form">
                                    <input type="hidden" name="act" class="form-control" id="act" value="sImport" title="">
                                    <div class="form-group">
                                        <input type="hidden" name="iap" class="form-control" id="iap" value="<?php echo $engine->get_iap($_SESSION['iap'], 'KV'); ?>">
                                    </div>									
                                    <div class="form-group">
                                        <input type="hidden" name="user_name" class="form-control" id="user_name" value="<?php echo $_SESSION['amatti_username']; ?>">
                                    </div>
                                    <div class="form-group">
                                        <input type="hidden" name="password" class="form-control" id="password" value="<?php echo $_SESSION['amatti_password']; ?>">
                                    </div>
                                    <div class="form-group">
                                        <select name="import_school_year" class="form-control">
                                            <option value="" selected="selected">--الرجاء الاختيار ----</option>
                                            <option value="2015">2015 - 2016</option>
                                            <option value="2016">2016 - 2017</option>
                                            <option value="2017">2017 - 2018</option>
                                            <option value="2018">2018 - 2019</option>
                                        </select>
									</div>									
                                    <div class="form-group">
									    <button type="submit" class="btn btn-primary btn-block" id="Import-btn">استيراد</button>
                                    </div>									
                            </div>
                            <div class="modal-footer">
                            </div>
                            </form>
                        </div>
                    </div>
                </div>
                <?php include_once 'includes/footer.inc.php'; ?>

                    <script type="text/javascript" language="javascript" class="init">
                        $(document).ready(function() {
		
	                            $('#show').DataTable({
							 
                                "responsive": true,
                                "pageLength": 5,
                                "bLengthChange": false,
                                "info": false,
                                "order": [
                                    [3, 'asc']
                                ],							
                                ajax: {
                                    url: "server.php",
                                    data: function(data) {
                                        data.act= 'showS';	
                                         data.s1= $('#select1').val();
                                         data.s2= $('#select2').val();
                                         data.s3= $('#select3').val();
                                         data.s4= $('#select4').val();	
                                    },
                                    dataType: "json",
                                    method: "POST"
                                }
                            });
		
         
                    }); 
                        
						$ ( '#select1,#select2,#select3,#select4' ).on('change',function() {
                            $('#show').DataTable().ajax.reload();
                        });

 
	 
                        function sendToServer(act, id) {

                            swal({
                                title: 'هل أنت متأكد من حذف التلميذ؟',
                                text: "لن تتمكن من التراجع عن هذا!",
                                type: 'warning',
                                showCancelButton: true,
                                confirmButtonColor: '#3085d6',
                                cancelButtonColor: '#d33',
                                cancelButtonText: 'تراجع',
                                confirmButtonText: 'نعم، احذف!'
                            }).then((result) => {
                                if (result.value) {
                                    $.post("server.php", {
                                        act: act,
                                        id: id,
                                    }, (data, status) => {
                                        if (data === "1") {
                                            swal({
                                                type: 'success',
                                                title: 'تمت عملية الحذف بنجاح',
                                                showConfirmButton: false,
                                                timer: 1500
                                            })
                                        } else {
                                            swal({
                                                type: 'error',
                                                title: 'حدث خطأ ما :(',
                                                showConfirmButton: false,
                                                timer: 1500
                                            })
                                        }
                                        $('#show').DataTable().ajax.reload().draw(false);
                                    });
                                }
                            })

                        }

                        function cleanDatabase() {

                            swal({
                                title: 'هل أنت متأكد من مسح جميع البيانات',
                                text: "لن تتمكن من التراجع عن هذا!",
                                type: 'warning',
                                showCancelButton: true,
                                confirmButtonColor: '#3085d6',
                                cancelButtonColor: '#d33',
                                cancelButtonText: 'تراجع',
                                confirmButtonText: 'نعم، امسح!'
                            }).then((result) => {
                                if (result.value) {
                                    $.post("server.php", {
                                        act: 'sCleanDB',
                                    }, (data, status) => {
                                        if (data === "1") {
                                            swal({
                                                type: 'success',
                                                title: 'تمّت عملية المسح بنجاح',
                                                showConfirmButton: false,
                                                timer: 1500
                                            })
                                        } else {
                                            swal({
                                                type: 'error',
                                                title: 'حدث خطأ ما :(',
                                                showConfirmButton: false,
                                                timer: 1500
                                            })
                                        }
										$('#show').DataTable().ajax.reload().draw(false);

                                    });
                                }
                            })

                        }

                        function studentModal(id = 0) {

                            $.ajax({

                                type: 'POST',
                                url: 'server.php',
                                data: 'act=sToEdit&id=' + id + '',
                                success: function(response) {
                                    if (response) {

                                        var re = JSON.parse(response);

                                        for (var key in re) {
                                            $("#ae-student-form [name=" + key + "").val(re[key]);
                                        }

                                    };

                                }

                            });

                        }
						
                        function studentImportInfo() {
                            var data = $('#ae-student-form').serializeArray();
                            data.push({name: 'op', value: 'importInfo'});
                            $.ajax({

                                type: 'POST',
                                url: 'server.php',
                                data: data,
                                success: function(response) {
                                    if (response) {

                                        var re = JSON.parse(response);

										document.getElementById('latin_name').value = re.NomLtElv;
										document.getElementById('latin_surname').value = re.PrenomLtElv;
										document.getElementById('birth_place').value = re.LieuNaiArElv;


                                    };

                                }

                            });

                        }						

                        function studentPrintModal() {
							 	var select1 = $('#select1').val();
                                var select2 = $('#select2').val();
                                var select3 = $('#select3').val();
                                var select4 = $('#select4').val();	
                                var win = window.open("print.php?doc=s_certificate&s1=" + select1 + "&s2=" + select2 + "&s3=" + select3 + "&s4=" + select4, '_blank');
                                win.focus();  
					   }

                        $('#student-modal').on('hidden.bs.modal', function() {
                            $('#ae-student-form')[0].reset();

                        });

                        jQuery('#datetimepicker1').datetimepicker({
                            timepicker: false,
                            format: 'Y-m-d'
                        });
											
						
                    </script>

                    <script src="<?php echo HOME_URL . '/assets/js/jquery.dataTables.min.js'; ?>"></script>
                    <script src="<?php echo HOME_URL . '/assets/js/dataTables.bootstrap4.min.js '; ?>"></script>
                    <script src="<?php echo HOME_URL . '/assets/js/bootstrap.min.js'; ?>"></script>

    </body>

    </html>