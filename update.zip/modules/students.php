<?php 
/*
-----------------------------------------------
            برنامج الرفيق            
-----------------------------------------------
برمجة وتطوير: عادل قصي
البريد الإلكتروني: adelbak2014@gmail.com
الموقع الرسمي: https://github.com/adelbak/EL-RAFIK
الصفحة الرسمية للمبرمج: https://www.facebook.com/adel.qusay.9
-----------------------------------------------
*/

include_once DIR_MODS . '/includes/header.inc.php';

?>

	<body>
		<?php 
		    if ( $_SESSION['last_up_check'] < (time() - 60*15) ) { 
    	        $engine->checkUpdate(); 
            }
	    ?>
			<?php include_once DIR_MODS . '/includes/navbar.inc.php'; ?>
				<!---Section-->
				<section id="sections" class="py-4 bg-faded">
					<div class="container">
						<div class="row">
							<?php $engine->settingsChecker(); ?>
								<div class="col-md-2">
									<button type="submit" class="btn btn-primary btn-block text-white" data-toggle="modal" data-target="#student-modal" title="إضافة تلميذ إلى قاعدة البيانات"> <i class="fa fa-plus"></i> إضافة تلميذ </button>
								</div>
								<div class="col-md-2">
									<button type="submit" class="btn btn-danger btn-block text-white" data-toggle="modal" data-target="#ImportModal" title="استيراد التلاميذ من موقع الأرضية الرقمية"> <i class="fa fa-database"></i> استيراد التلاميذ </button>
								</div>
								<div class="col-md-2">
									<button type="submit" id="iasb" class="btn btn-danger btn-block text-white" data-toggle="modal" data-target="#mImportModal" title="استيراد التلاميذ المشطوبين"> <i class="fa fa-user-times"></i> استيراد المشطوبين </button>
								</div>
								<div class="col-md-2">
									<button type="submit" class="btn btn-warning btn-block text-white" onclick="deleteStudents()" title="حذف بيانات التلاميذ"> <i class="fa fa-exclamation-triangle "></i> حذف بيانات التلاميذ </button>
								</div>
								<div class="col-md-4">
									<div class="alert alert-vdark" role="alert"> عدد التلاميذ: <span id="tots"></span> الذكور: <span id="ms"></span> الإناث: <span id="fs"></span> المشطوبون: <span id="rs"></span> </div>
								</div>
						</div>
						<div class="row mt-4">
							<div class="col-md-2">
								<select id="select1" class="form-control">
									<option value="" selected="selected">--الرجاء الاختيار --</option>
									<?php $engine->getForSelectOptions('school_year'); ?>
								</select>
							</div>
							<div class="col-md-3">
								<select id="select2" class="form-control">
									<option value="" selected="selected">-- كل المستويات --</option>
									<?php $engine->getForSelectOptions('level'); ?>
								</select>
							</div>
							<div class="col-md-2">
								<select id="select3" class="form-control" <?php if($_SESSION[ 'educ_institution'] !='ثانوية' ){ echo 'disabled';}?>>
									<option value="" selected="selected">-- جميع الشعب --</option>
									<?php $engine->getForSelectOptions('division'); ?>
								</select>
							</div>
							<div class="col-md-2">
								<select id="select4" class="form-control">
									<option value="" selected="selected">-- كل الأفواج --</option>
									<?php $engine->getForSelectOptions('section'); ?>
								</select>
							</div>
							<div class="col-md-3 justify-content-center align-self-center">
								<div class="btn-group">
									<button type="submit" class="btn btn-lg btn-success" onclick="studentPrint()" title="طباعة الشهادات المدرسية"><i class="fa fa-file-pdf-o"></i> ش.مدرسية</button>
									<button type="submit" class="btn btn-lg btn-primary" data-toggle="modal" data-target="#printModal" title="طباقة القوائم والوثائق"><i class="fa fa-print"></i> طباعة</button>
									<button type="submit" class="btn btn-lg btn-danger" onclick="studentsFilterTrash()" title="حذف البيانات المحددة"><i class="fa fa-trash"></i> حذف</button>
								</div>
							</div>
							</div>
					</div>
				</section>
				<section id="posts" class="py-4 mb-4">
					<div class="container">
						<div class="row">
							<div class="col">
								<table id="show" class="table table-striped table-bordered" cellspacing="0" width="100%">
									<thead class="thead thead-light">
										<tr>
											<th>رقم التعريف</th>
											<th>السنة الدراسية</th>
											<th>اللقب</th>
											<th>الاسم</th>
											<th>تاريخ الميلاد</th>
											<th>المستوى</th>
											<th>الشعبة</th>
											<th>الفوج</th>
											<th>رقم التسجيل</th>
											<th>آخر تحديث</th>
											<th>العمليات</th>
										</tr>
									</thead>
								</table>
							</div>
						</div>
					</div>
				</section>
				<div class="modal fade" id="student-modal" tabindex="-1" role="dialog" aria-labelledby="student-modal" aria-hidden="true">
					<div class="modal-dialog modal-lg" role="document">
						<div class="modal-content s-modal">
							<div class="modal-header">
								<h5 class="modal-title">معلومات التلميذ</h5>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">×</span> </button>
							</div>
							<div class="modal-body p-4" id="result">
								<div id="ae-student-form-msg">
									<!-- الخطأ يظهر هنا ! -->
								</div>
								<form id="ae-student-form">
									<input type="hidden" name="id" class="form-control" id="id" value="" title="">
									<input type="hidden" name="act" class="form-control" id="act" value="sAdd" title="">
									<div class="row">
										<div class="col-md-2">
											<h6 class="text-muted">الحالة المدنية</h6> </div>
										<div class="col-md-10">
											<hr class="mb-4"> </div>
									</div>
									<div class="form-group">
										<div class="row">
											<div class="col-md-3">
												<label for="surname">اللقب:</label>
												<input type="text" id="surname" name="surname" class="form-control" maxlength="250" placeholder="" required> </div>
											<div class="col-md-3">
												<label for="name">الاسم:</label>
												<input type="text" id="name" name="name" class="form-control" maxlength="250" placeholder="" required> </div>
											<div class="col-md-3">
												<label for="latin_surname">اللقب باللاتينية:</label>
												<input type="text" id="latin_surname" name="latin_surname" class="form-control" maxlength="250" placeholder="" required> </div>
											<div class="col-md-3">
												<label for="latin_name">الاسم باللاتينية:</label>
												<input type="text" id="latin_name" name="latin_name" class="form-control" maxlength="250" placeholder="" required> </div>
										</div>
									</div>
									<div class="form-group">
										<div class="row">
											<div class="col-md-3">
												<label for="gender">الجنس:</label>
												<select id="gender" name="gender" class="form-control" required>
													<option value="" selected="selected">-- يرجى الاختيار --</option>
													<option value="ذكر">ذكر</option>
													<option value="أنثى">أنثى</option>
												</select>
											</div>
											<div class="col-md-3">
												<label for="birth_date">تاريخ الميلاد:</label>
												<input type="text" name="birth_date" id="birth_date" class="form-control datepicker" dateISO="true" placeholder="" required> </div>
											<div class="col-md-3">
												<label for="d_birth_date">حكم؟:</label>
												<select name="d_birth_date" class="form-control" required>
													<option value="" selected="selected">-- يرجى الاختيار --</option>
													<option value="نعم">نعم</option>
													<option value="لا">لا</option>
												</select>
											</div>
											<div class="col-md-3">
												<label for="birth_place">مكان الميلاد:</label>
												<input type="text" id="birth_place" name="birth_place" class="form-control" maxlength="250" placeholder="" required> </div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-2">
											<h6 class="text-muted">الحالة الدراسية</h6> </div>
										<div class="col-md-10">
											<hr class="mb-4"> </div>
									</div>
									<div class="form-group">
										<div class="row">
											<div class="col-md-3">
												<label for="school_year">السنة الدراسية:</label>
												<select id="school_year" name="school_year" class="form-control">
													<option value="" selected="selected">--الرجاء الاختيار ----</option>
													<option value="2015">2015 - 2016</option>
													<option value="2016">2016 - 2017</option>
													<option value="2017">2017 - 2018</option>
													<option value="2018">2018 - 2019</option>
													<option value="2019">2019 - 2020</option>
												</select>
											</div>	
											<div class="col-md-6">
												<label for="id_num">رقم التعريف:</label>
												<input type="number" id="id_num" name="id_num" class="form-control" maxlength="16" placeholder="" required> </div>
											<div class="col-md-3">
												<label for="num_inscribe">رقم التسجيل:</label>
												<input type="number" id="num_inscribe" name="num_inscribe" class="form-control" maxlength="10" placeholder="" required> </div>
										</div>
									</div>
									<div class="form-group">
										<div class="row">
											<div class="col-md-3">
												<label for="level">المستوى:</label>
												<select name="level" class="form-control" required>
													<option value="" selected="selected">-- كل المستويات --</option>
													<?php $engine->getForSelectOptions('level'); ?>
												</select>
											</div>
											<div class="col-md-6">
												<input type="hidden" name="division" class="form-control" id="division" value="" title="" required>
												<label for="division">الشعبة:</label>
												<select name="division" class="form-control" <?php if($_SESSION[ 'educ_institution'] !='ثانوية' ){ echo 'disabled';}?> required>
													<option value="" selected="selected">-- جميع الشعب --</option>
													<?php $engine->getForSelectOptions('division'); ?>
												</select>
											</div>
											<div class="col-md-3">
												<label for="section">الفوج:</label>
												<select name="section" class="form-control" required>
													<option value="" selected="selected">-- كل الأفواج --</option>
													<?php $engine->getForSelectOptions('section'); ?>
												</select>
											</div>
										</div>
									</div>
							</div>
							<div class="modal-footer">
								<div class="btn-group">
									<button type="submit" class="btn btn-lg btn-success" id="ae-student-form-btn">حــفظ</button>
									<button type="button" class="btn btn-lg btn-danger" data-dismiss="modal">تراجع</button>
								</div>
							</div>
							</form>
						</div>
					</div>
				</div>
				<div class="modal fade bd-example-modal-lg" id="printModal" tabindex="-1" role="dialog" aria-labelledby="printModal" aria-hidden="true">
					<div class="modal-dialog modal-lg">
						<div class="modal-content">
							<div class="modal-header">
								<h5 class="modal-title" id="printModalTitle">طباعة الوثائق</h5>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
							</div>
							<div class="modal-body">
								<div class="container-fluid">
									<div class="row">
										<div class="col-md-4"> <button class="btn btn-primary btn-block" data-toggle="modal" data-target="#PDFListsModal" title="قوائم التلاميذ"> <i class="fa fa-file-pdf-o"></i> قوائم </button></div>
										<div class="col-md-4"> <button type="button" class="btn btn-primary btn-block" onclick="studentsCardsPrint()" title="بطاقات التعريف المدرسية"><i class="fa fa-file-pdf-o"></i> بطاقات التعريف</button></div>										
										<div class="col-md-4"> <button type="button" class="btn btn-primary btn-block" onclick="studentsSeatsCardsPrint()" title="بطاقات المقاعد"><i class="fa fa-file-pdf-o"></i> بطاقات المقاعد</button></div>
									</div>
								</div>
							</div>
							<div class="modal-footer"> </div>
						</div>
					</div>
				</div>				
				<div class="modal fade" id="PDFListsModal" tabindex="-1" role="dialog" aria-labelledby="PDFListsModal" aria-hidden="true">
					<div class="modal-dialog" role="document">
						<div class="modal-content">
							<div class="modal-header">
								<h5 class="modal-title" id="PDFListsModal">طباعة قوائم التلاميذ</h5>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
							</div>
							<div class="modal-body">
								<form id="PDFLists-form">
									<div class="form-group">
										<div class="row">
											<div class="col-md-12">
												<label for="listType">نوع القائمة:</label>
												<select id="listType" name="listType" class="form-control" onchange="listTypeOptions()" required>
													<option value="pdf" selected="selected">ملف PDF</option>
													<option value="excel">ملف إكسل</option>
												</select>
											</div>
										</div>
									</div>								
									<div class="form-group">
										<div class="row">
											<div class="col-md-4">
												<label for="st">التلاميذ:</label>
												<select id="st" name="st" class="form-control" required>
													<option value="0" selected="selected">المتمدرسون</option>
													<option value="1">المشطوبون</option>
												</select>
											</div>
											<div class="col-md-4">
												<label for="sr">الترتيب:</label>
												<select id="sr" name="sr" class="form-control">
													<option value="1" selected="selected">الاسم</option>
													<option value="2">اللقب</option>
													<option value="3">رقم التعريف</option>
													<option value="4">الجنس</option>
													<option value="5">الجنس تداوليا</option>
													<option value="6">العمر</option>
													<option value="7">عشوائي</option>
												</select>
											</div>
											<div class="col-md-4">
												<label for="srs">الاتجاه:</label>
												<select id="srs" name="srs" class="form-control" required>
													<option value="1" selected="selected">تصاعديا</option>
													<option value="2">تنازليا</option>
												</select>
											</div>
										</div>
									</div>
									<div class="form-group">
										<div class="row">
											<div class="col-md-4">
											    <div class="custom-control custom-checkbox">
											        <input name="pAge" type="checkbox" class="custom-control-input" id="pAge">
											        <label class="custom-control-label" for="pAge">خانة العمر</label>
											    </div>
											</div>												
											<div class="col-md-4">
											    <div class="custom-control custom-checkbox">
											        <input name="pGender" type="checkbox" class="custom-control-input" id="pGender">
											        <label class="custom-control-label" for="pGender">خانة الجنس</label>
											    </div>
											</div>	
											<div class="col-md-4">
											    <div class="custom-control custom-checkbox">
											        <input name="pNotes" type="checkbox" class="custom-control-input" id="pNotes">
											        <label class="custom-control-label" for="pNotes">خانة الملاحظات</label>
											    </div>
											</div>												
										</div>
									</div>
									<div class="form-group">
										<button type="button" id="Import-btn" class="btn btn-primary btn-block" onclick="studentsListsPrintModal()">طباعة/تحميل القوائم</button>
									</div>
							</div>
							<div class="modal-footer"> </div>
							</form>
						</div>
					</div>
				</div>
				</div>
				<div class="modal fade" id="ImportModal" tabindex="-1" role="dialog" aria-labelledby="ImportModal" aria-hidden="true">
					<div class="modal-dialog" role="document">
						<div class="modal-content">
							<div class="modal-header">
								<h5 class="modal-title" id="ImportModal">استيراد التلاميذ من قائمة إكسل</h5> <span class="note"> <i class="fa fa-bell"></i> العملية تستغرق ثواني، يرجى الصبر.</span>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
							</div>
							<div class="modal-body">
								<div id="amattiImportStudentsForm">
									<form id="Import-form">
										<input type="hidden" name="act" class="form-control" id="act" value="sImport" title="">
										<div class="form-group">
											<label class="btn btn-success btn-block"> <i class="fa fa-upload"></i> <span id="lInputFile">ملف قائمة التلاميذ إكسل</span>
												<input type="file" id="inputFile01" name="list" hidden> </label>
											<div class="progress progress-bar-striped active">
												<div class="progress-bar" style="width:0%"></div>
											</div>
										</div>
										<div class="form-group">
											<select name="import_school_year" class="form-control">
												<option value="" selected="selected">--الرجاء الاختيار ----</option>
												<option value="2015">2015 - 2016</option>
												<option value="2016">2016 - 2017</option>
												<option value="2017">2017 - 2018</option>
												<option value="2018">2018 - 2019</option>
												<option value="2019">2019 - 2020</option>
											</select>
										</div>
										<div class="form-group">
											<button type="submit" value="submit" class="btn btn-danger btn-block btn-import"> <i class="fa fa-step-backward"></i> استيراد </button>
										</div>
										<div class="modal-footer"> </div>
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="modal fade" id="mImportModal" tabindex="-1" role="dialog" aria-labelledby="mImportModal" aria-hidden="true">
					<div class="modal-dialog" role="document">
						<div class="modal-content">
							<div class="modal-header">
								<h5 class="modal-title" id="mImportModal">استيراد التلاميذ المشطوبين من قائمة إكسل</h5>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
							</div>
							<div class="modal-body">
								<div id="amattiImportMStudentsForm">
									<form id="mImport-form">
										<input type="hidden" name="act" class="form-control" id="act" value="mImport" title="">
										<div class="form-group">
											<label class="btn btn-success btn-block"> <i class="fa fa-upload"></i> <span id="mInputFile">ملف قائمة التلاميذ المشطوبين إكسل</span>
												<input type="file" id="inputFile02" name="mList" hidden> </label>
											<div class="progress progress-bar-striped active">
												<div class="progress-bar" style="width:0%"></div>
											</div>
										</div>
										<div class="form-group">
											<select name="import_school_year" class="form-control">
												<option value="" selected="selected">--الرجاء الاختيار ----</option>
												<option value="2015">2015 - 2016</option>
												<option value="2016">2016 - 2017</option>
												<option value="2017">2017 - 2018</option>
												<option value="2018">2018 - 2019</option>
												<option value="2019">2019 - 2020</option>
												<option value="2020">2020 - 2021</option>
											</select>
										</div>
										<div class="form-group">
											<button type="submit" value="submit" class="btn btn-danger btn-block btn-import"> <i class="fa fa-step-backward"></i> استيراد </button>
										</div>
										<div class="modal-footer"> </div>
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
				<?php include_once DIR_MODS . '/includes/footer.inc.php'; ?>
					<script type="text/javascript" language="javascript" class="init">
					$('#inputFile01').on('change', function() {
						var fileName = event.target.files[0].name;
						$('#lInputFile').html(fileName);
					});
					$('#inputFile02').on('change', function() {
						var fileName = event.target.files[0].name;
						$('#mInputFile').html(fileName);
					});
					$(document).ready(function() {
						$('#show').DataTable({
							"responsive": true,
							"pageLength": 5,
							"bLengthChange": false,
							"info": false,
							"order": [
								[3, 'asc']
							],
							ajax: {
								url: "server.php",
								data: function(data) {
									data.act = 'showS';
									data.s1 = $('#select1').val();
									data.s2 = $('#select2').val();
									data.s3 = $('#select3').val();
									data.s4 = $('#select4').val();
								},
								dataType: "json",
								method: "POST"
							}
						});
						studentsCounter();
						$('#select1,#select2,#select3,#select4').on('change', function() {
							$('#show').DataTable().ajax.reload();
							studentsCounter();
						});
						$.validator.setDefaults({
							highlight: function(element) {
								$(element).addClass('is-invalid').removeClass('is-valid');
							},
							unhighlight: function(element) {
								$(element).removeClass('is-invalid').addClass('is-valid');
							},
							errorElement: 'div ',
							errorClass: 'invalid-feedback',
							errorPlacement: function(error, element) {
								if(element.parent('.input-group').length) {
									error.insertAfter(element.parent());
								} else if($(element).is('.select')) {
									element.next().after(error);
								} else if(element.hasClass('select2')) {
									//error.insertAfter(element);
									error.insertAfter(element.next());
								} else if(element.hasClass('selectpicker')) {
									error.insertAfter(element.next());
								} else {
									error.insertAfter(element);
								}
							},
							submitHandler: function(form) {
								var data = $("#ae-student-form").serialize();
								$.ajax({
									type: 'POST',
									url: 'server.php',
									data: data,
									beforeSend: function() {
										$("#ae-student-form-msg").fadeOut();
										$("#ae-student-form-btn").html('<i class="fa fa-spinner fa-spin"></i>');
									},
									success: function(response) {
										if(response == "1") {
											$("#ae-student-form-msg").fadeIn(1000, function() {
												$("#ae-student-form-msg").html('<div class="alert alert-success">تمّ حفظ البيانات بنجاح..</div>');
											});
											setTimeout(' window.location.href = "index.php?page=students"; ', 2000);
										} else {
											$("#ae-student-form-msg").fadeIn(1000, function() {
												$("#ae-student-form-msg").html('<div class="alert alert-danger">' + response + ' </div>');
												$("#ae-student-form-btn").html('حفظ المعلومات');
											});
										}
									}
								});
								$('#show').DataTable().ajax.reload().draw(false);
								return false;
							}
						});
						$('#ae-student-form').validate();
						$('.datepicker').datepicker({
							todayHighlight: true,
							todayBtn: "linked",
							language: "ar",
							autoclose: true,
							clearBtn: true,
							calendarWeeks: true,
							format: 'yyyy-mm-dd'
						});
					});

					function sendToServer(act, id) {
						swal({
							title: 'هل أنت متأكد من حذف التلميذ؟',
							text: "لن تتمكن من التراجع عن هذا!",
							type: 'warning',
							showCancelButton: true,
							confirmButtonColor: '#3085d6',
							cancelButtonColor: '#d33',
							cancelButtonText: 'تراجع',
							confirmButtonText: 'نعم، احذف!'
						}).then((result) => {
							if(result.value) {
								$.post("server.php", {
									act: act,
									id: id,
								}, (data, status) => {
									if(data === "1") {
										swal({
											type: 'success',
											title: 'تمت عملية الحذف بنجاح',
											showConfirmButton: false,
											timer: 1500
										})
									} else {
										swal({
											type: 'error',
											title: 'حدث خطأ ما :(',
											showConfirmButton: false,
											timer: 1500
										})
									}
									$('#show').DataTable().ajax.reload().draw(false);
								});
							}
						})
					}

					function deleteStudents() {
						swal({
							title: 'هل أنت متأكد من حذف جميع البيانات',
							text: "لن تتمكن من التراجع عن هذا!",
							type: 'warning',
							showCancelButton: true,
							confirmButtonColor: '#3085d6',
							cancelButtonColor: '#d33',
							cancelButtonText: 'تراجع',
							confirmButtonText: 'نعم، احذف!'
						}).then((result) => {
							if(result.value) {
								$.post("server.php", {
									act: 'deleteStudents',
								}, (data, status) => {
									if(data === "1") {
										swal({
											type: 'success',
											title: 'تمّت عملية الحذف بنجاح',
											showConfirmButton: false,
											timer: 1500
										})
									} else {
										swal({
											type: 'error',
											title: 'حدث خطأ ما :(',
											showConfirmButton: false,
											timer: 1500
										})
									}
									$('#show').DataTable().ajax.reload().draw(false);
								});
							}
						})
					}

					function studentsFilterTrash() {
						var select1 = $('#select1').val();
						var select2 = $('#select2').val();
						var select3 = $('#select3').val();
						var select4 = $('#select4').val();
						swal({
							title: 'هل أنت متأكد من حذف بيانات تلاميذ: ' + select1 + ' - ' + select2 + ' - ' + select3 + ' - ' + select4,
							text: "لن تتمكن من التراجع عن هذا!",
							type: 'warning',
							showCancelButton: true,
							confirmButtonColor: '#3085d6',
							cancelButtonColor: '#d33',
							cancelButtonText: 'تراجع',
							confirmButtonText: 'نعم، احذف!'
						}).then((result) => {
							if(result.value) {
								$.post("server.php", {
									op: 'massDeleteStudents',
									s1: select1,
									s2: select2,
									s3: select3,
									s4: select4,
								}, (data, status) => {
									if(data === "1") {
										swal({
											type: 'success',
											title: 'تمّت عملية الحذف بنجاح',
											showConfirmButton: false,
											timer: 1500
										})
									} else {
										swal({
											type: 'error',
											title: 'حدث خطأ ما :(',
											showConfirmButton: false,
											timer: 1500
										})
									}
									setTimeout(' window.location.href = "?page=students"; ', 2000);
								});
							}
						})
					}

					function studentModal(id = 0) {
						$.ajax({
							type: 'POST',
							url: 'server.php',
							data: 'act=sToEdit&id=' + id + '',
							success: function(response) {
								if(response) {
									var re = JSON.parse(response);
									for(var key in re) {
										$("#ae-student-form [name=" + key + "").val(re[key]);
									}
								};
							}
						});
						document.getElementById("act").setAttribute("value", "sEdit");
					}

					function studentPrint() {
						var select1 = $('#select1').val();
						var select2 = $('#select2').val();
						var select3 = $('#select3').val();
						var select4 = $('#select4').val();
						var win = window.open("print.php?doc=s_certificate&s1=" + select1 + "&s2=" + select2 + "&s3=" + select3 + "&s4=" + select4, '_blank');
						win.focus();
					}
					
					function studentsCardsPrint() {
						var select1 = $('#select1').val();
						var select2 = $('#select2').val();
						var select3 = $('#select3').val();
						var select4 = $('#select4').val();
						var win = window.open("print.php?doc=s_cards&s1=" + select1 + "&s2=" + select2 + "&s3=" + select3 + "&s4=" + select4, '_blank');
						win.focus();
					}

					function studentsSeatsCardsPrint() {
						var select1 = $('#select1').val();
						var select2 = $('#select2').val();
						var select3 = $('#select3').val();
						var select4 = $('#select4').val();
						var win = window.open("print.php?doc=s_s_cards&s1=" + select1 + "&s2=" + select2 + "&s3=" + select3 + "&s4=" + select4, '_blank');
						win.focus();
					}
					
					function studentsListsPrintModal() {
						var listType = $('#listType').val();					
						var select1 = $('#select1').val();
						var select2 = $('#select2').val();
						var select3 = $('#select3').val();
						var select4 = $('#select4').val();
						var st = $('#st').val();
						var sr = $('#sr').val();
						var srs = $('#srs').val();
						var st = $('#st').val();
						var pGender = document.querySelector('input[name="pGender"]').checked;
						var pAge = document.querySelector('input[name="pAge"]').checked;
						var pNotes = document.querySelector('input[name="pNotes"]').checked;
						var win = window.open("print.php?doc=s_lists&listType=" + listType + "&st=" + st + "&sr=" + sr + "&srs=" + srs + "&s1=" + select1 + "&s2=" + select2 + "&s3=" + select3 + "&s4=" + select4 + "&pGender=" + pGender+"&pAge=" + pAge+"&pNotes=" + pNotes, '_blank');
						win.focus();
					}

					function studentsCounter() {
						var select1 = $('#select1').val();
						var select2 = $('#select2').val();
						var select3 = $('#select3').val();
						var select4 = $('#select4').val();
						$.ajax({
							type: 'POST',
							url: 'server.php',
							data: {
								op: 'sc',
								s1: select1,
								s2: select2,
								s3: select3,
								s4: select4,
							},
							success: function(response) {
								if(response) {
									var re = JSON.parse(response);
									$("#tots").html(re.tots);
									$("#ms").html(re.ms);
									$("#fs").html(re.fs);
									$("#rs").html(re.rs);
								};
							}
						});
					}
					
					function listTypeOptions() {
						if(document.getElementById("listType").value == "pdf") {
							document.getElementById('pGender').disabled = false;
							document.getElementById('pAge').disabled = false;
							document.getElementById('pNotes').disabled = false;							
							} else {
							document.getElementById('pGender').disabled = true;
							document.getElementById('pAge').disabled = true;
							document.getElementById('pNotes').disabled = true;	
						}
					}
					
					$('#student-modal').on('hidden.bs.modal', function() {
						$('#ae-student-form')[0].reset();
						document.getElementById("act").setAttribute("value", "sAdd");
					});
					</script>
					<script src="<?php echo HOME_URL . '/assets/js/jquery.dataTables.min.js'; ?>"></script>
					<script src="<?php echo HOME_URL . '/assets/js/dataTables.bootstrap4.min.js '; ?>"></script>
					<script src="<?php echo HOME_URL . '/assets/js/popper.min.js'; ?>"></script>
					<script src="<?php echo HOME_URL . '/assets/js/bootstrap.min.js'; ?>"></script>
					<script src="<?php echo HOME_URL . '/assets/js/datepicker/bootstrap-datepicker.min.js'; ?>"></script>
					<script src="<?php echo HOME_URL . '/assets/js/datepicker/bootstrap-datepicker.ar.min.js'; ?>"></script>
					<script src="<?php echo HOME_URL . '/assets/js/jquery-validation/jquery.validate.min.js'; ?>"></script>
					<script src="<?php echo HOME_URL . '/assets/js/jquery-validation/localization/messages_ar.js'; ?>"></script>
	</body>

</html>