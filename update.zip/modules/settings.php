<?php
/*
-----------------------------------------------
            سكربت المدير الرقمي            
-----------------------------------------------
برمجة وتطوير: عادل قصي
البريد الإلكتروني: adelbak2014@gmail.com
الموقع الرسمي: www.cem11.com
الصفحة الرسمية للمبرمج: https://www.facebook.com/adel.qusay.9
-----------------------------------------------
السكربت مجاني، يرجى طلب الإذن عند الرغبة في
التطوير.
-----------------------------------------------
*/

include_once 'includes/header.inc.php';
?>

    <body>

        <?php include_once 'includes/navbar.inc.php'; ?>

            <!--Settings-->
            <section id="settings" class="py-4 mb-4">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6 offset-md-3">
                            <div class="card">
                                <div class="card-header">
                                    <h4>الإعدادات <span class="note"> <i class="fa fa-bell"></i> ملاحظة: يجب ملئ كل الخانات</span></h4>
                                </div>
                                <div class="card-body">
                                    <div id="settingsForm-msg">
                                        <!-- msg will be shown here ! -->
                                    </div>
                                    <form id="settingsForm">
                                        <div class="form-group">
                                            <input type="hidden" name="act" value="settings" class="form-control">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <label for="new_password">كلمة السر الجديدة:</label>
                                                    <input type="password" name="new_password" class="form-control">
                                                </div>
                                                <div class="col-md-6">
                                                    <label for="re_new_password">إعادة كلمة السر:</label>
                                                    <input type="password" name="re_new_password" class="form-control">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="iap">مديرية التربية:</label>
                                            <select name="iap" class="form-control" required>
                                                <option value="" selected="selected">-- يرجى الاختيار --</option>
                                                <option value="مديرية التربية لولاية أدرار">مديرية التربية لولاية أدرار</option>
                                                <option value="مديرية التربية لولاية الشلف">مديرية التربية لولاية الشلف</option>
                                                <option value="مديرية التربية لولاية الأغواط">مديرية التربية لولاية الأغواط</option>
                                                <option value="مديرية التربية لولاية أم البواقي">مديرية التربية لولاية أم البواقي</option>
                                                <option value="مديرية التربية لولاية باتنة">مديرية التربية لولاية باتنة</option>
                                                <option value="مديرية التربية لولاية بجاية">مديرية التربية لولاية بجاية</option>
                                                <option value="مديرية التربية لولاية بسكرة">مديرية التربية لولاية بسكرة</option>
                                                <option value="مديرية التربية لولاية بشار">مديرية التربية لولاية بشار</option>
                                                <option value="مديرية التربية لولاية البليدة">مديرية التربية لولاية البليدة</option>
                                                <option value="مديرية التربية لولاية البويرة">مديرية التربية لولاية البويرة</option>
                                                <option value="مديرية التربية لولاية تمنراست">مديرية التربية لولاية تمنراست</option>
                                                <option value="مديرية التربية لولاية تبسة">مديرية التربية لولاية تبسة</option>
                                                <option value="مديرية التربية لولاية تلمسان">مديرية التربية لولاية تلمسان</option>
                                                <option value="مديرية التربية لولاية تيارت">مديرية التربية لولاية تيارت</option>
                                                <option value="مديرية التربية لولاية تيزي وزو">مديرية التربية لولاية تيزي وزو</option>
                                                <option value="مديرية التربية للجزائر غرب">مديرية التربية للجزائر غرب</option>
                                                <option value="مديرية التربية للجزائر وسط">مديرية التربية للجزائر وسط</option>
                                                <option value="مديرية التربية للجزائر شرق">مديرية التربية للجزائر شرق</option>
                                                <option value="وزارة التربية الوطنية">وزارة التربية الوطنية</option>
                                                <option value="مديرية التربية لولاية الجلفة">مديرية التربية لولاية الجلفة</option>
                                                <option value="مديرية التربية لولاية جيجل">مديرية التربية لولاية جيجل</option>
                                                <option value="مديرية التربية لولاية سطيف">مديرية التربية لولاية سطيف</option>
                                                <option value="مديرية التربية لولاية سعيدة">مديرية التربية لولاية سعيدة</option>
                                                <option value="مديرية التربية لولاية سكيكدة">مديرية التربية لولاية سكيكدة</option>
                                                <option value="مديرية التربية لولاية سيدي بلعباس">مديرية التربية لولاية سيدي بلعباس</option>
                                                <option value="مديرية التربية لولاية عنابة">مديرية التربية لولاية عنابة</option>
                                                <option value="مديرية التربية لولاية قالمة">مديرية التربية لولاية قالمة</option>
                                                <option value="مديرية التربية لولاية قسنطينة">مديرية التربية لولاية قسنطينة</option>
                                                <option value="مديرية التربية لولاية المدية">مديرية التربية لولاية المدية</option>
                                                <option value="مديرية التربية لولاية مستغانم">مديرية التربية لولاية مستغانم</option>
                                                <option value="مديرية التربية لولاية المسيلة">مديرية التربية لولاية المسيلة</option>
                                                <option value="مديرية التربية لولاية معسكر">مديرية التربية لولاية معسكر</option>
                                                <option value="مديرية التربية لولاية ورقلة">مديرية التربية لولاية ورقلة</option>
                                                <option value="مديرية التربية لولاية وهران">مديرية التربية لولاية وهران</option>
                                                <option value="مديرية التربية لولاية البيض">مديرية التربية لولاية البيض</option>
                                                <option value="مديرية التربية لولاية إليزي">مديرية التربية لولاية إليزي</option>
                                                <option value="مديرية التربية لولاية برج بوعريريج">مديرية التربية لولاية برج بوعريريج</option>
                                                <option value="مديرية التربية لولاية بومرداس">مديرية التربية لولاية بومرداس</option>
                                                <option value="مديرية التربية لولاية الطارف">مديرية التربية لولاية الطارف</option>
                                                <option value="مديرية التربية لولاية تندوف">مديرية التربية لولاية تندوف</option>
                                                <option value="مديرية التربية لولاية تيسمسيلت">مديرية التربية لولاية تيسمسيلت</option>
                                                <option value="مديرية التربية لولاية الوادي">مديرية التربية لولاية الوادي</option>
                                                <option value="مديرية التربية لولاية خنشلة">مديرية التربية لولاية خنشلة</option>
                                                <option value="مديرية التربية لولاية سوق أهراس">مديرية التربية لولاية سوق أهراس</option>
                                                <option value="مديرية التربية لولاية تيبازة">مديرية التربية لولاية تيبازة</option>
                                                <option value="مديرية التربية لولاية ميلة">مديرية التربية لولاية ميلة</option>
                                                <option value="مديرية التربية لولاية عين الدفلى">مديرية التربية لولاية عين الدفلى</option>
                                                <option value="مديرية التربية لولاية النعامة">مديرية التربية لولاية النعامة</option>
                                                <option value="مديرية التربية لولاية عين تيموشنت">مديرية التربية لولاية عين تيموشنت</option>
                                                <option value="مديرية التربية لولاية غرداية">مديرية التربية لولاية غرداية</option>
                                                <option value="مديرية التربية لولاية غليزان">مديرية التربية لولاية غليزان</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <input type="hidden" name="act" value="settings" class="form-control">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <label for="amatti_username">اسم المستخدم (الأرضية الرقمية):</label>
                                                    <input type="text" name="amatti_username" class="form-control">
                                                </div>
                                                <div class="col-md-6">
                                                    <label for="amatti_password">كلمة المرور (الأرضية الرقمية):</label>
                                                    <input type="password" name="amatti_password" class="form-control">
                                                </div>
                                            </div>
                                        </div>										
                                        <div class="form-group">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <label for="educ_institution">المؤسسة:</label>
                                                    <select name="educ_institution" class="form-control" required>
                                                        <option value="" selected="selected">-- يرجى الاختيار --</option>
                                                        <option value="ابتدائية">ابتدائية</option>
                                                        <option value="متوسطة">متوسطة</option>														
                                                        <option value="ثانوية">ثانوية</option>
                                                    </select>
												</div>											
                                                <div class="col-md-6">
                                                    <label for="state">البلدية:</label>
                                                    <input type="text" name="state" class="form-control" required>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="row">										
                                                <div class="col-md-12">
                                                    <label for="educ_institution_name">اسم المؤسسة (لا تكتب: ابتدائية/متوسطة/ثانوية):</label>
                                                    <input type="text" name="educ_institution_name" class="form-control" required>
                                                </div>
                                            </div>
                                        </div>										
                                        <div class="form-group">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <label for="school_year">الموسم الدراسي:</label>
                                                    <select name="school_year" class="form-control" required>
                                                        <option value="" selected="selected">-- يرجى الاختيار --</option>
                                                        <option value="2018/2017">2018/2017</option>
                                                        <option value="2019/2018">2019/2018</option>
                                                        <option value="2020/2019">2020/2019</option>
                                                        <option value="2021/2020">2021/2020</option>
                                                        <option value="2022/2021">2022/2021</option>
                                                        <option value="2023/2022">2023/2022</option>
                                                        <option value="2024/2023">2024/2023</option>
                                                        <option value="2025/2024">2025/2024</option>
                                                    </select>
                                                </div>
                                                <div class="col-md-8">
                                                    <label for="documents_release_date">تاريخ تحرير الوثائق <a href="#" class="btn btn-warning btn-sm text-white" data-toggle="tooltip" onclick="drd()" title="إذا أردت أن يكون تاريخ تحرير الوثيقة هو نفسه تاريخ الطبع، اضغط هنا"><i class="fa fa-plus"></i></a> :</label>
                                                    <input type="text" name="documents_release_date" id="datetimepicker1" value="تاريخ الطباعة" class="form-control" required>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <label for="teachers_entry_date">تاريخ دخول الأساتذة:</label>
                                                    <input type="text" name="teachers_entry_date" id="datetimepicker2" placeholder="yyyy-mm-dd" class="form-control" required>
                                                </div>
                                                <div class="col-md-6">
                                                    <label for="teachers_exit_date">تاريخ خروج الأساتذة:</label>
                                                    <input type="text" name="teachers_exit_date" id="datetimepicker3" placeholder="yyyy-mm-dd" class="form-control" required>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <label for="administrators_entry_date">تاريخ دخول الإداريين:</label>
                                                    <input type="text" name="administrators_entry_date" id="datetimepicker4" placeholder="yyyy-mm-dd" class="form-control" required>
                                                </div>
                                                <div class="col-md-6">
                                                    <label for="administrators_exit_date">تاريخ خروج الإداريين:</label>
                                                    <input type="text" name="administrators_exit_date" id="datetimepicker5" placeholder="yyyy-mm-dd" class="form-control" required>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <label for="profitability_triplex">الثلاثي (المردودية):</label>
                                                    <select name="profitability_triplex" class="form-control" required>
                                                        <option value="" selected="selected">-- يرجى الاختيار --</option>
                                                        <option value="الأول">الأول</option>
                                                        <option value="الثاني">الثاني</option>
                                                        <option value="الثالث">الثالث</option>
                                                        <option value="الرابع">الرابع</option>
                                                    </select>
                                                </div>
                                                <div class="col-md-6">
                                                    <label for="profitability_year">السنة (المردودية):</label>
                                                    <select name="profitability_year" class="form-control" required>
                                                        <option value="" selected="selected">-- يرجى الاختيار --</option>
                                                        <option value="2018">2018</option>
                                                        <option value="2019">2019</option>
                                                        <option value="2020">2020</option>
                                                        <option value="2021">2021</option>
                                                        <option value="2022">2022</option>
                                                        <option value="2023">2023</option>
                                                        <option value="2024">2024</option>
                                                        <option value="2025">2025</option>
                                                        <option value="2026">2026</option>
                                                        <option value="2027">2027</option>
                                                        <option value="2028">2028</option>
                                                        <option value="2029">2029</option>
                                                        <option value="2030">2030</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <label for="barcode">طباعة Barcode  (عطلها إذا لم يتوفر المستخدم على الرقم الوظيفي):</label>
                                                    <select name="barcode" class="form-control" required>
                                                        <option value="" selected="selected">-- يرجى الاختيار --</option>
                                                        <option value="ON">تشغيل</option>
                                                        <option value="OFF">تعطيل</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>										
                                        <div class="form-group">
                                            <button type="submit" class="btn btn-primary btn-block" id="settingsForm-btn">حفظ الإعدادات</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <?php include_once 'includes/footer.inc.php'; ?>
                <script type="text/javascript" language="javascript" class="init">
                    $('document').ready(function() {

                        $.ajax({

                            type: 'POST',
                            url: 'server.php',
                            data: 'act=stoedit',
                            success: function(response) {
                                if (response) {

                                    var re = JSON.parse(response);

                                    for (var key in re) {
                                        $("#settingsForm [name=" + key + "").val(re[key]);
                                    }

                                };

                            }

                        });
                    });

                    $(function() {
                        $('[data-toggle="tooltip"]').tooltip()
                    })

                    jQuery('#datetimepicker1').datetimepicker({
                        timepicker: false,
                        format: 'Y-m-d'
                    });
                    jQuery('#datetimepicker2').datetimepicker({
                        timepicker: false,
                        format: 'Y-m-d'
                    });
                    jQuery('#datetimepicker3').datetimepicker({
                        timepicker: false,
                        format: 'Y-m-d'
                    });
                    jQuery('#datetimepicker4').datetimepicker({
                        timepicker: false,
                        format: 'Y-m-d'
                    });
                    jQuery('#datetimepicker5').datetimepicker({
                        timepicker: false,
                        format: 'Y-m-d'
                    });

                    function drd() {
                        document.getElementById("datetimepicker1").value = "تاريخ الطباعة";
                        swal({
                            position: 'top-end',
                            type: 'success',
                            title: 'تمّ ذلك',
                            showConfirmButton: false,
                            timer: 1500
                        });
                    }
                </script>

                <script src="<?php echo HOME_URL . '/assets/js/popper.min.js'; ?>"></script>
                <script src="<?php echo HOME_URL . '/assets/js/bootstrap.min.js'; ?>"></script>

    </body>

    </html>