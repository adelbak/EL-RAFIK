<?php
/*
-----------------------------------------------
            سكربت المدير الرقمي            
-----------------------------------------------
برمجة وتطوير: عادل قصي
البريد الإلكتروني: adelbak2014@gmail.com
الموقع الرسمي: www.cem11.com
الصفحة الرسمية للمبرمج: https://www.facebook.com/adel.qusay.9
-----------------------------------------------
السكربت مجاني، يرجى طلب الإذن عند الرغبة في
التطوير.
-----------------------------------------------
*/

include_once 'includes/header.inc.php';
?>

    <body>
	
        <?php 
		    if ( $_SESSION['last_up_check'] < (time() - 60*15) ) { 
    	        $engine->checkUpdate(); 
            }
	    ?>
		
        <?php include_once 'includes/navbar.inc.php'; ?>

            <!---Section-->
            <section id="sections" class="py-4 bg-faded">
                <div class="container">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="alert alert-tdanger" role="alert">
                               <a> خاص بالمتوسط </a>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <a href="" class="btn btn-success btn-block text-white" data-toggle="modal" data-target="#listsGenModal">
                                <i class="fa fa-list"></i> توليد القوائم
                            </a>
                        </div>
                        <div class="col-md-3 mr-auto">
                            <a href="<?php echo HOME_URL.'/excel/cem.xls' ?>" class="btn btn-warning btn-block text-white">
                                <i class="fa fa-download"></i> تحميل القائمة المعتمدة (فارغة)
                            </a>
                        </div>
                        <div class="col-md-3">
                            <button type="submit" name="send_notes" value="submit" class="btn btn-danger btn-block upload-all">
                                <i class="fa fa-step-backward"></i> إرسال النقاط
                            </button>
                        </div>
                    </div>
                </div>
            </section>
            <!--POSTS-->
            <section id="posts" class="py-4 mb-4">
                <div class="container">
                    <div class="card">
                        <div class="card-header">
                            <div class="alert alert-warning" role="alert">
                                <?php echo "مرحـــبـــــا بـــك، اختر ملف النقاط ثم اضغط على إرسال النقاط، يمكنك إرسال أكثر من ملف دفعة واحدة."; ?>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="input-group control-group after-add-more"></div>
                            <!-- Copy Fields -->
                            <?php echo $engine->sendListsForms(15); ?>
                        </div>
                    </div>
                </div>
            </section>

            <div class="modal fade bd-example-modal-lg" id="listsGenModal" tabindex="-1" role="dialog" aria-labelledby="listsGenModal" aria-hidden="true">
                <div class="modal-dialog modal-xl">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLongTitle">توليد قوائم خاصة بكل المواد</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="container-fluid">
                                <div class="card">
                                    <div class="card-header">
                                        <div class="alert alert-danger" role="alert">
                                            <?php echo 'مرحبا عزيزي المستخدم، توجّه إلى موقع الأرضية الرقمية ثم انتقل إلى قسم "تسيير التمدرس" اختر "ملفات التلاميذ"، ثم <b> قم بتحديد "السنة الدراسية"</b> و حمّل قائمة التلاميذ بصيغة Excel كما هو موضح في الصورة ادناه،بعد تحميل ملف  "eleve.xls" قم باختياره ثم اضغط على "توليد القوائم" سيعمل نظامنا على توليد قوائم لتلاميذ مؤسستك حسب المواد، قم بتحميلها واستخدامها في حجز النقاط وإرسالها إلى موقع الأرضية الرقمية عبر خدمتنا.'; ?>
                                                <button class="btn btn-outline-success btn-sm" type="button" data-toggle="collapse" data-target="#collapseImage" aria-expanded="false" aria-controls="collapseImage">
                                                    صورة توضيحية
                                                </button>
                                        </div>
                                        <div class="collapse" id="collapseImage">
                                            <div class="col-md-10 offset-md-1">
                                                <img src="<?php echo HOME_URL . '/assets/img/help.png'; ?>" class="img-fluid border border-success" alt="Responsive image">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="card-body">

                                        <div class="input-group control-group after-add-more">

                                        </div>

                                        <!-- Copy Fields -->

                                        <form id="eleve" action="#">
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <label class="btn btn-primary btn-block">
                                                        <i class="fa fa-upload"></i> الملف
                                                        <input class="custom-file-input" type="file" name="eleve" hidden>
                                                        <span class="custom-file-control"></span>
                                                    </label>
                                                    <label>
                                                        <input type="hidden" id="educ_ins_name" name="educ_ins_name" value="<?php echo $_SESSION['educ_institution_name']; ?>">
                                                    </label>
                                                </div>
                                                <div class="col-md-3">
                                                    <select name="annee_school" class="form-control" required>
                                                        <option value="" selected="selected">اختر الفترة</option>
                                                        <option value="الفصل الأول">الفصل الأول <?php echo str_replace('/', '-', $_SESSION['school_year']); ?></option>
                                                        <option value="الفصل الثاني">الفصل الثاني <?php echo str_replace('/', '-', $_SESSION['school_year']); ?></option>
                                                        <option value="الفصل الثالث">الفصل الثالث <?php echo str_replace('/', '-', $_SESSION['school_year']); ?></option>
                                                    </select>
                                                </div>
                                                <div class="col-md-3">
                                                    <button type="submit" value="submit" class="btn btn-danger btn-block"><i class="fa fa-fire"></i> توليد القوائم</button>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="progress progress-bar-striped active">
                                                        <div class="progress-bar" style="width:0%"></div>
                                                    </div>
                                                </div>
                                            </div>

                                        </form>

                                    </div>

                                </div>
                            </div>

                        </div>
                        <div class="modal-footer">
                        </div>
                    </div>
                </div>
            </div>

            <script>
                $('.custom-file-input').on('change', function() {
                    let fileName = $(this).val().split('\\').pop();
                    $(this).next('.custom-file-control').addClass("selected").html(fileName);
                });
				
                $('#listsGenModal').on('hidden.bs.modal', function() {
                    setTimeout(' window.location.href = "index.php?page=cem_notes"; ', 0);
                });				
            </script>

            <script>
                $('.upload-all').click(function() {
                    //submit all form
                    $('form#sform').submit();
                });

                $(document).on('submit', 'form#sform', function(e) {
                    e.preventDefault();

                    $form = $(this);

                    uploadFile($form);

                });

                function uploadFile($form) {
                    $form.find('.progress-bar').removeClass('progress-bar-success')
                        .removeClass('progress-bar-danger');

                    var formdata = new FormData($form[0]); //formelement
                    var request = new XMLHttpRequest();

                    //progress event...
                    request.upload.addEventListener('progress', function(e) {
                        var percent = Math.round(e.loaded / e.total * 100);
                        $form.find('.progress-bar').addClass('progress-bar-striped').width(percent + '%').html(percent + '%');
                        if (percent == 100) {
                            $form.find('.progress-bar').addClass('progress-bar-striped').width(percent + '%').html('<i class="fa fa-spinner fa-spin"></i>');
                        }
                    });

                    request.open('post', 'server.php');
                    request.send(formdata);

                    //progress completed load event
                    request.addEventListener('load', function(e) {
                        if (request.responseText == "1") {
                            $form.find('.progress-bar').removeClass('progress-bar-striped').addClass('progress-bar bg-success').html('<span><i class="fa fa-check"></i> تمّت العملية بنجاح</span>');
                            $form.find('.progress-bar').removeClass('progress-bar bg-danger').addClass('progress-bar bg-success').html('<span><i class="fa fa-check"></i> تمّت العملية بنجاح</span>');

                        } else {
                            $form.find('.progress-bar').removeClass('progress-bar-striped').addClass('progress-bar bg-danger').html('<span><i class="fa fa-times"></i> ' + request.responseText + '</span>');
                        }
                    });

                }
            </script>

            <script>
                $("#submit").on('click', function() {
                    //Do whatever   you want here //... 
                    $("form#eleve").submit();
                });

                $(document).on('submit', 'form#eleve', function(e) {
                    e.preventDefault();

                    $form = $(this);

                    uploadFile2($form);

                });

                function uploadFile2($form) {
                    $form.find('.progress-bar').removeClass('progress-bar-success')
                        .removeClass('progress-bar-danger');

                    var formdata = new FormData($form[0]); //formelement
                    var request = new XMLHttpRequest();

                    //progress event...
                    request.upload.addEventListener('progress', function(e) {
                        var percent = Math.round(e.loaded / e.total * 100);
                        $form.find('.progress-bar').addClass('progress-bar-striped').width(percent + '%').html(percent + '%');
                        if (percent == 100) {
                            $form.find('.progress-bar').addClass('progress-bar-striped').width(percent + '%').html('<i class="fa fa-spinner fa-spin"></i>');
                        }
                    });

                    request.open('post', 'server.php');
                    request.send(formdata);

                    //progress completed load event
                    request.addEventListener('load', function(e) {
                        if (request.responseText.match("downloads")) {
                            $form.find('.progress-bar').removeClass('progress-bar-striped').addClass('progress-bar bg-success').html('<a href="' + request.responseText + '" class="download"> <i class="fa fa-download"></i> تحميل</a>');
                            $form.find('.progress-bar').removeClass('progress-bar bg-danger').addClass('progress-bar bg-success').html('<a href="' + request.responseText + '" class="download"> <i class="fa fa-download"></i> تحميل</a>');

                        } else {
                            $form.find('.progress-bar').removeClass('progress-bar-striped').addClass('progress-bar bg-danger').html('<span><i class="fa fa-times"></i> ' + request.responseText + '</span>');
                        }
                    });

                }
            </script>
            <?php include_once 'includes/footer.inc.php'; ?>
                <script src="<?php echo HOME_URL . '/assets/js/bootstrap.min.js'; ?>"></script>

    </body>

    </html>