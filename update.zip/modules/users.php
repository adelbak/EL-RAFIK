<?php 
/*
-----------------------------------------------
            سكربت المدير الرقمي            
-----------------------------------------------
برمجة وتطوير: عادل قصي
البريد الإلكتروني: adelbak2014@gmail.com
الموقع الرسمي: www.cem11.com
الصفحة الرسمية للمبرمج: https://www.facebook.com/adel.qusay.9
-----------------------------------------------
السكربت مجاني، يرجى طلب الإذن عند الرغبة في
التطوير.
-----------------------------------------------
*/

include_once 'includes/header.inc.php';

?>

    <body>

        <?php 
		    if ( $_SESSION['last_up_check'] < (time() - 60*15) ) { 
    	        $engine->checkUpdate(); 
            }
	    ?>

            <?php include_once 'includes/navbar.inc.php'; ?>

                <!---Section-->
                <section id="sections" class="py-4 bg-faded">
                    <div class="container">
                        <div class="row">
                            <?php $engine->settingsChecker(); ?>
                                <div class="col-md-2">
                                    <button type="submit" class="btn btn-danger btn-block" data-toggle="modal" data-target="#UserModal">
                                        <i class="fa fa-plus"></i> إضافة مستخدم
                                    </button>
                                </div>
                                <div class="col-md-2">
                                    <button type="submit" class="btn btn-danger btn-block text-white" data-toggle="modal" data-target="#ImportModal" title="استيراد المستخدمين من موقع الأرضية الرقمية">
                                        <i class="fa fa-database"></i> استيراد المستخدمين
                                    </button>
                                </div>
                                <div class="col-md-2">
                                    <button type="submit" class="btn btn-success btn-block text-white" data-toggle="modal" data-target="#ProfitabilityPrintModal" title="طباعة جدول منحة الأداء التربوي">
                                        <i class="fa fa-print"></i> جدول منحة الأداء التربوي
                                    </button>
                                </div>
                                <div class="col-md-2">
                                    <button type="submit" class="btn btn-success btn-block text-white" data-toggle="modal" data-target="#TENRPrintModal" title="طباعة محضر الدخول الجماعي">
                                        <i class="fa fa-print"></i> محضر الدخول الجماعي
                                    </button>
                                </div>
                                <div class="col-md-2">
                                    <button type="submit" class="btn btn-success btn-block text-white" data-toggle="modal" data-target="#TEXRPrintModal" title="طباعة محضر الخروج الجماعي">
                                        <i class="fa fa-print"></i> محضر الخروج الجماعي
                                    </button>
                                </div>
                                <div class="col-md-2">
                                    <button type="submit" class="btn btn-success btn-block text-white" data-toggle="modal" data-target="#FormPrintModal" title="طباعة استمارات المعلومات">
                                        <i class="fa fa-print"></i> استمارات المعلومات
                                    </button>
                                </div>
                        </div>
                        <div class="row mt-2">
                            <div class="col-md-2">
                                <button type="submit" class="btn btn-success btn-block text-white" data-toggle="modal" data-target="#CertificatePrintModal" title="طباعة شهادات العمل">
                                    <i class="fa fa-print"></i> شهادات العمل
                                </button>
                            </div>
                            <div class="col-md-2">
                                <button type="submit" class="btn btn-success btn-block text-white" data-toggle="modal" data-target="#WRSPrintModal" title="طباعة بيانات استئناف العمل">
                                    <i class="fa fa-print"></i> بيانات استئناف العمل
                                </button>
                            </div>
                            <div class="col-md-2">
                                <button type="submit" class="btn btn-success btn-block text-white" data-toggle="modal" data-target="#NRPrintModal" title="طباعة محاضر التنصيب">
                                    <i class="fa fa-print"></i> محاضر التنصيب
                                </button>
                            </div>
                            <div class="col-md-2">
                                <button type="submit" class="btn btn-success btn-block text-white" data-toggle="modal" data-target="#TSPrintModal" title="طباعة مجمل الخدمات">
                                    <i class="fa fa-print"></i> مجمل الخدمات
                                </button>
                            </div>							
                            <div class="col-md-2">
                                <button type="submit" class="btn btn-success btn-block text-white" onclick="exportXLS()" title="طباعة استمارات المعلومات">
                                    <i class="fa fa-file-excel-o"></i> تصدير بيانات المستخدمين
                                </button>
                            </div>
                            <div class="col-md-2">
                                <button type="submit" class="btn btn-warning btn-block text-white" onclick="cleanDatabase()" title="حذف بيانات المستخدمين">
                                    <i class="fa fa-exclamation-triangle "></i> حذف بيانات المستخدمين
                                </button>
                            </div>
                        </div>
                    </div>
                </section>
                <section id="posts" class="py-4 mb-4">
                    <div class="container">
                        <div class="row">
                            <div class="col">
                                <table id="show" class="table table-striped table-bordered" cellspacing="0" width="100%">
                                    <thead class="thead thead-light">
                                        <tr>
                                            <th>الرقم الوظيفي</th>
                                            <th>اللقب</th>
                                            <th>الاسم</th>
                                            <th>تاريخ الازدياد</th>
                                            <th>الرتبة</th>
                                            <th>المادة</th>
                                            <th>الدرجة</th>
                                            <th>آخر تحديث</th>
                                            <th>العمليات</th>
                                        </tr>
                                    </thead>
                                </table>
                            </div>
                        </div>
                    </div>
                </section>

                <div class="modal fade" id="UserModal" tabindex="-1" role="dialog" aria-labelledby="UserModal" aria-hidden="true">
                    <div class="modal-dialog modal-full" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">معلومات المستخدم</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">×</span>
                                </button>
                            </div>
                            <div class="modal-body p-4" id="result">
                                <div id="aeUserForm-msg">
                                    <!-- الخطأ يظهر هنا ! -->
                                </div>
                                <form id="aeUserForm">

                                    <div class="tabbable">
                                        <ul class="nav nav-tabs" role="tablist">
                                            <li class="nav-item"><a class="nav-link active" href="#tab1" data-toggle="tab">الحالة المدنية والعائلية</a></li>
                                            <li class="nav-item"><a class="nav-link" href="#tab2" data-toggle="tab">الحالة المهنية</a></li>
                                            <li class="nav-item"><a class="nav-link" href="#tab3" data-toggle="tab">الانتماء النقابي</a></li>
                                            <li class="nav-item"><a class="nav-link" href="#tab4" data-toggle="tab">منحة المردودية</a></li>
                                            <li class="nav-item"><a class="nav-link" href="#tab6" data-toggle="tab">مجمل الخدمات</a></li>											
                                            <li class="nav-item"><a class="nav-link" href="#tab5" data-toggle="tab">الدخول والخروج</a></li>
                                        </ul>

                                        <div class="tab-content">
                                            <input type="hidden" name="id" class="form-control" id="id" value="" title="">
                                            <input type="hidden" name="act" class="form-control" id="act" value="add" title="">

                                            <div class="tab-pane active" id="tab1">
                                                <div class="row">
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="surname"> اللقب: <i class="req">*</i> </label>
                                                        <input type="text" name="surname" class="form-control" id="surname" value="" title="اللقب" required>
                                                    </div>
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="name"> الاسم: <i class="req">*</i> </label>
                                                        <input type="text" name="name" class="form-control" id="name" value="" title="الاسم" required>
                                                    </div>
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="latin_surname"> اللقب بالاتينية: </label>
                                                        <input type="text" name="latin_surname" class="form-control" style="text-transform:uppercase" id="latin_surname" value="" title="اللقب بالاتينية">
                                                    </div>
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="latin_name"> الاسم بالاتينية: </label>
                                                        <input type="text" name="latin_name" class="form-control" style="text-transform:uppercase" id="latin_name" value="" title="الاسم بالاتينية">
                                                    </div>
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="father_name"> اسم الأب: </label>
                                                        <input type="text" name="father_name" class="form-control" id="father_name" value="" title="اسم الأب">
                                                    </div>
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="father_latin_name"> اسم الأب بالاتينية: </label>
                                                        <input type="text" name="father_latin_name" class="form-control" style="text-transform:uppercase" id="father_latin_name" value="" title="اسم الأب بالاتينية">
                                                    </div>
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="mother_surname"> لقب الأم: </label>
                                                        <input type="text" name="mother_surname" class="form-control" id="mother_surname" value="" title="لقب الأم">
                                                    </div>
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="mother_name"> اسم الأم: </label>
                                                        <input type="text" name="mother_name" class="form-control" id="mother_name" value="" title="اسم الأم">
                                                    </div>
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="mother_latin_surname"> لقب الأم بالاتينية: </label>
                                                        <input type="text" name="mother_latin_surname" class="form-control" style="text-transform:uppercase" id="mother_latin_surname" value="" title="لقب الأم بالاتينية">
                                                    </div>

                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="mother_latin_name"> اسم الأم بالاتينية: </label>
                                                        <input type="text" name="mother_latin_name" class="form-control" style="text-transform:uppercase" id="mother_latin_name" value="" title="اسم الأم بالاتينية">
                                                    </div>
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="family_status"> الحالة العائلية: </label>
                                                        <select name="family_status" id="family_status" class="form-control" title="الحالة العائلية">
                                                            <option value="" selected="selected">-- الرجاء الاختيار --</option>
                                                            <option value="متزوج(ة)">متزوج(ة)</option>
                                                            <option value="أعزب(ة)">أعزب(ة)</option>
                                                            <option value="مطلق(ة)">مطلق(ة)</option>
                                                            <option value="أرمل(ة)">أرمل(ة)</option>
                                                        </select>
                                                    </div>
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="married_women_orig_surname"> اللقب الأصلي للسيدات: </label>
                                                        <input type="text" name="married_women_orig_surname" class="form-control" id="married_women_orig_surname" value="" title="اللقب الأصلي للمتزوجات">
                                                    </div>

                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="children_number"> عدد الأولاد: </label>
                                                        <input type="text" name="children_number" class="form-control" id="children_number" value="" title="عدد الأولاد">
                                                    </div>
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="greater_than_10_years"> أكبر من 10 سنوات: </label>
                                                        <input type="text" name="greater_than_10_years" class="form-control" id="greater_than_10_years" value="" title="أكبر من 10 سنوات">
                                                    </div>
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="learning"> المتمدرسين: </label>
                                                        <input type="text" name="learning" class="form-control" id="learning" value="" title="المتمدرسين">
                                                    </div>
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="insurers"> المتكفل بهم: </label>
                                                        <input type="text" name="insurers" class="form-control" id="insurers" value="" title="المتكفل بهم">
                                                    </div>
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="birth_date"> تاريخ الميلاد: <i class="req">*</i> </label>
                                                        <input type="text" name="birth_date" class="form-control" id="datetimepicker1" placeholder="yyyy-mm-dd" title="تاريخ الميلاد" required>
                                                    </div>
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="birth_date2"> حُكم: </label>
                                                        <input type="number" id="birth_date2" name="birth_date2" class="form-control" onchange="bdate()" min="1900" max="2099" step="1" placeholder="yyyy" style="width:220px;" title="تاريخ الميلاد (حكم)" enabled>
                                                    </div>
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="birth_place"> مكان الميلاد: <i class="req">*</i> </label>
                                                        <input type="text" name="birth_place" class="form-control" id="birth_place" value="" title="مكان الميلاد" required>
                                                    </div>
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="nationality"> الجنسية: </label>
                                                        <input type="text" name="nationality" class="form-control" id="nationality" value="" title="الجنسية">
                                                    </div>
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="blood_type"> فصيلة الدم: </label>
                                                        <select name="blood_type" id="blood_type" class="form-control" title="فصيلة الدم">
                                                            <option value="" selected="selected">-- الرجاء الاختيار --</option>
                                                            <option value="O -">O -</option>
                                                            <option value="O +">O +</option>
                                                            <option value="A -">A -</option>
                                                            <option value="A +">A +</option>
                                                            <option value="B -">B -</option>
                                                            <option value="B +">B +</option>
                                                            <option value="AB -">AB -</option>
                                                            <option value="AB +">AB +</option>
                                                        </select>
                                                    </div>
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="optical_power"> القدرة البصرية: </label>
                                                        <input type="text" name="optical_power" class="form-control" id="optical_power" value="" title="القدرة البصرية">
                                                    </div>
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="address"> العنوان: </label>
                                                        <input type="text" name="address" class="form-control" id="address" value="" title="العنوان">
                                                    </div>
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="postal_code"> الرمز البريدي: </label>
                                                        <input type="text" name="postal_code" class="form-control" id="postal_code" value="" title="الرمز البريدي">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="tab-pane" id="tab2">
                                                <div class="row">
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="func_id"> الرقم الوظيفي: <i class="req">*</i> </label>
                                                        <input type="text" name="func_id" class="form-control" id="func_id" value="" title="الرقم الوظيفي" required>
                                                    </div>
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="sector_bilateral"> ثنائي في القطاع: </label>
                                                        <select name="sector_bilateral" id="sector_bilateral" class="form-control" title="ثنائي في القطاع">
                                                            <option value="" selected="selected">-- الرجاء الاختيار --</option>
                                                            <option value="لا">لا</option>
                                                            <option value="نعم">نعم</option>
                                                        </select>
                                                    </div>

                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="current_rank"> الرتبة الحالية: <i class="req">*</i> </label>
                                                        <select name="current_rank" id="current_rank" class="form-control" style="width:220px;" title="الرتبة الحالية" required>
                                                            <option value="" selected="selected">-- الرجاء الاختيار --</option>
                                                            <?php 	$engine->ranks('select');    ?>
                                                        </select>
                                                    </div>
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="current_rank_date"> تاريخ الرتبة الحالية: </label>
                                                        <input type="text" name="current_rank_date" class="form-control" id="datetimepicker2" placeholder="yyyy-mm-dd" title="تاريخ الرتبة الحالية">
                                                    </div>
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="type"> الصنف: </label>
                                                        <input type="text" name="type" class="form-control" id="type" title="الصنف">
                                                    </div>
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="specialization"> مادة التخصص: </label>
                                                        <input type="text" name="specialization" class="form-control" id="specialization" value="" title="مادة التخصص">
                                                    </div>
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="teaching_material"> مادة التدريس: </label>
                                                        <select name="teaching_material" id="teaching_material" class="form-control" style="width:220px;" title="مادة التدريس">
                                                            <option value="" selected="selected">-- الرجاء الاختيار --</option>
                                                            <option value="اللغة العربية">اللغة العربية</option>
                                                            <option value="اللغة اﻷمازيغية">اللغة اﻷمازيغية</option>
                                                            <option value="اللغة الفرنسية">اللغة الفرنسية</option>
                                                            <option value="اللغة  الإنجليزية">اللغة الإنجليزية</option>
                                                            <option value="اللغة الإسبانية">اللغة الإسبانية (ثانوي)</option>
                                                            <option value="اللغة الألمانية">اللغة الألمانية (ثانوي)</option>
                                                            <option value="اللغة الإيطالية">اللغة الإيطالية (ثانوي)</option>
                                                            <option value="التربية الإسلامية">التربية الإسلامية (متوسط)</option>
                                                            <option value="العلوم الإسلامية">العلوم الإسلامية (ثانوي)</option>
                                                            <option value="التربية المدنية">التربية المدنية (متوسط)</option>
                                                            <option value="التاريخ  والجغرافيا">التاريخ والجغرافيا</option>
                                                            <option value="الرياضيات">الرياضيات</option>
                                                            <option value="العلوم  الطبيعية">ع الطبيعة و الحياة</option>
                                                            <option value="العلوم الفيزيائية والتكنولوجيا">ع الفيزيائية والتكنولوجيا (متوسط)</option>
                                                            <option value="الفلسفة">الفلسفة (ثانوي)</option>
                                                            <option value="الهندسة المدنية">الهندسة المدنية (ثانوي)</option>
                                                            <option value="الهندسة الكهربائية">الهندسة الكهربائية (ثانوي)</option>
                                                            <option value="الهندسة الميكانيكية">الهندسة الميكانيكية (ثانوي)</option>
                                                            <option value="هندسة الطرائق">هندسة الطرائق (ثانوي)</option>
                                                            <option value="التسيير المحاسبي والمالي">التسيير المحاسبي والمالي (ثانوي)</option>
                                                            <option value="الاقتصاد والمناجمنت">الاقتصاد والمناجمنت (ثانوي)</option>
                                                            <option value="القانون">القانون (ثانوي)</option>
                                                            <option value="التربية الفنية التشكيلية">التربية الفنية التشكيلية (ثانوي)</option>
                                                            <option value="التكنولوجيا">التكنولوجيا (ثانوي)</option>
                                                            <option value="العلوم الفيزيائية">العلوم الفيزيائية (ثانوي)</option>
                                                            <option value="المعلوماتية">المعلوماتية</option>
                                                            <option value="التربية التشكيلية">التربية التشكيلية</option>
                                                            <option value="التربية الموسيقية">التربية الموسيقية</option>
                                                            <option value="ت البدنية و الرياضية">ت البدنية و الرياضية</option>
                                                        </select>
                                                    </div>
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="administrative_status"> الوضعية الإدارية: <i class="req">*</i> </label>
                                                        <select name="administrative_status" id="administrative_status" class="form-control" title="الوضعية الإدارية" onchange="admFD()" required>
                                                            <option value="" selected="selected">-- الرجاء الاختيار --</option>
                                                            <option value="مرسم(ة)">مرسم(ة)</option>
                                                            <option value="متربص(ة)">متربص(ة)</option>
                                                            <option value="مستخلف(ة)">مستخلف(ة)</option>
                                                        </select>
                                                    </div>
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="fixing_date"> تاريخ الترسيم: </label>
                                                        <input type="text" name="fixing_date" class="form-control" id="datetimepicker10" placeholder="yyyy-mm-dd" title="تاريخ الترسيم" disabled>
                                                    </div>													
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="class"> الدرجة: </label>
                                                        <input type="text" name="class" class="form-control" id="class" value="" title="الدرجة">
                                                    </div>
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="class_effective_date"> تاريخ سريان الدرجة: </label>
                                                        <input type="text" name="class_effective_date" class="form-control" id="datetimepicker3" placeholder="yyyy-mm-dd" title="تاريخ سريان الدرجة" format="YYYY-MM-DD">
                                                    </div>
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="employment_date"> تاريخ التوظيف: </label>
                                                        <input type="text" name="employment_date" class="form-control" id="datetimepicker4" placeholder="yyyy-mm-dd" title="تاريخ التوظيف">
                                                    </div>
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="nomination_report_number"> رقم قرار التعيين: </label>
                                                        <input type="text" name="nomination_report_number" class="form-control" id="type" title="رقم قرار التعيين">
                                                    </div>
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="nomination_report_date"> تاريخ قرار التعيين: </label>
                                                        <input type="text" name="nomination_report_date" class="form-control" id="datetimepicker5" placeholder="yyyy-mm-dd" title="تاريخ قرار التعيين">
                                                    </div>
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="c_school_employment_date"> تاريخ التعيين في مؤ.ح: </label>
                                                        <input type="text" name="c_school_employment_date" class="form-control" id="datetimepicker6" placeholder="yyyy-mm-dd" title="تاريخ التعيين في المؤسسة الحالية">
                                                    </div>
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="last_inspection_visit_date"> تاريخ آخر زيارة تفتيشية: </label>
                                                        <input type="text" name="last_inspection_visit_date" class="form-control" id="datetimepicker8" placeholder="yyyy-mm-dd" title="تاريخ آخر زيارة تفتيشية">
                                                    </div>
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for=""> المؤهلات العلمية: </label>
                                                        <input type="text" name="qualifications" class="form-control" id="qualifications" value="" title="المؤهلات العلمية">
                                                    </div>
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="postal_account_number"> رقم الحساب البريدي: </label>
                                                        <input type="text" name="postal_account_number" class="form-control" id="postal_account_number" value="" title="رقم الحساب البريدي">
                                                    </div>

                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="pan_key"> المفتاح: </label>
                                                        <input type="text" name="pan_key" class="form-control" id="pan_key" value="" title="المفتاح">
                                                    </div>
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="social_security_number"> رقم الضمان الاجتماعي: </label>
                                                        <input type="text" name="social_security_number" class="form-control" id="social_security_number" value="" title="رقم الضمان الاجتماعي">
                                                    </div>
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="mtutalism_number"> رقم التعاضدية: </label>
                                                        <input type="text" name="mtutalism_number" class="form-control" id="mtutalism_number" value="" title="رقم التعاضدية">
                                                    </div>

                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="phone_number"> الهاتف: </label>
                                                        <input type="nember" name="phone_number" class="form-control" id="phone_number" value="" title="الهاتف">
                                                    </div>
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="email"> البريد الإلكتروني: </label>
                                                        <input type="email" name="email" class="form-control" id="email" value="" title="البريد الإلكتروني">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="tab-pane" id="tab3">
                                                <div class="row">
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="syndicalist"> التنظيم النقابي: </label>
                                                        <select name="syndicalist" id="syndicalist" class="form-control" style="width:220px;" title="التنظيم النقابي">
                                                            <option value="" selected="selected">-- الرجاء الاختيار --</option>
                                                            <option value="مجلس ثانويات الجزائر">مجلس ثانويات الجزائر</option>
                                                            <option value="المجلس الوطني المستقل لمستخدمي التدريس للقطاع ثلاثي الأطوار للتربية">المجلس الوطني المستقل لمستخدمي التدريس للقطاع ثلاثي الأطوار للتربية</option>
                                                            <option value="النقابة المستقلة لعمال التربية و التكوين">النقابة المستقلة لعمال التربية و التكوين</option>
                                                            <option value="النقابة الوطنية المستقلة لموظفي الإدارة العمومية">النقابة الوطنية المستقلة لموظفي الإدارة العمومية</option>
                                                            <option value="النقابة الوطنية المستقلة لاساتذة التعليم الثانوي والتقني">النقابة الوطنية المستقلة لاساتذة التعليم الثانوي والتقني</option>
                                                            <option value="النقابة الوطنية لأساتذة التعليم الابتدائي">النقابة الوطنية لأساتذة التعليم الابتدائي</option>
                                                            <option value="النقابة الوطنية للأسلاك المشتركة و العمال المهنيين لقطاع التربية">النقابة الوطنية للأسلاك المشتركة و العمال المهنيين لقطاع التربية</option>
                                                            <option value="النقابة الوطنية لعمال التربية">النقابة الوطنية لعمال التربية</option>
                                                            <option value="الاتحاد العام للعمال الجزائريين">الاتحاد العام للعمال الجزائريين</option>
                                                            <option value="الاتحاد الوطني لعمال التربية و التكوين">الاتحاد الوطني لعمال التربية و التكوين</option>
                                                        </select>
                                                    </div>
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="syndicalistic_type"> صفة الانتماء: </label>
                                                        <select name="syndicalistic_type" id="syndicalist_type" class="form-control" style="width:220px;" title="صفة الانتماء">
                                                            <option value="" selected="selected">-- الرجاء الاختيار --</option>
                                                            <option value="منخرط">منخرط</option>
                                                            <option value="عضو فرع محلي">عضو فرع محلي</option>
                                                            <option value="عضو مكتب ولائي">عضو مكتب ولائي</option>
                                                            <option value="عضو مكتب جهوي">عضو مكتب جهوي</option>
                                                            <option value="عضو مكتب او مجلس وطني">عضو مكتب او مجلس وطني</option>
                                                        </select>
                                                    </div>

                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="syndicalistic_date"> تاريخ الانخراط: </label>
                                                        <input type="text" name="syndicalistic_date" class="form-control" id="datetimepicker9" placeholder="yyyy-mm-dd" title="تاريخ الانخراط">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="tab-pane" id="tab4">
                                                <div class="row">
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="profitability_note"> العلامة: </label>
                                                        <input type="text" name="profitability_note" class="form-control" id="profitability_note" value="" title="العلامة">
                                                    </div>
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="profitability_aps"> عدد الغيابات: </label>
                                                        <input type="text" name="profitability_aps" class="form-control" id="profitability_aps" value="" title="عدد الغيابات">
                                                    </div>

                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="profitability_notes"> الملاحظات: </label>
                                                        <input type="text" name="profitability_notes" class="form-control" id="profitability_notes" value="" title="الملاحظات">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="tab-pane" id="tab6">
                                                <div class="row">
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="administrative_point"> النقطة الإدارية: </label>
                                                        <input type="text" name="administrative_point" class="form-control" id="administrative_point" value="" title="النقطة الإدارية">
                                                    </div>
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="administrative_point_date"> تاريخ النقطة الإدارية: </label>
                                                        <input type="text" name="administrative_point_date" class="form-control" id="datetimepicker11" placeholder="yyyy-mm-dd" title="تاريخ النقطة الإدارية">
                                                    </div>
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="educational_point"> النقطة التربوية: </label>
                                                        <input type="text" name="educational_point" class="form-control" id="educational_point" value="" title="النقطة التربوية">
                                                    </div>
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="educational_point_date"> تاريخ النقطة التربوية: </label>
                                                        <input type="text" name="educational_point_date" class="form-control" id="datetimepicker7" placeholder="yyyy-mm-dd" title="تاريخ النقطة التربوية">
                                                    </div>
											    <div class="col-md-12 col-lg-12 form-group form-inline title text-center">
												    مجمل الخدمات
												</div>													
											    <div class="col-sm-12 col-lg-12 form-group form-inline uth">
												    <div class="col-md-2">الولاية</div>
												    <div class="col-md-2">المؤسسة</div>
												    <div class="col-md-2">الرتبة</div>
												    <div class="col-md-2">الصفة</div>
												    <div class="col-md-2">تاريخ مباشرة العمل</div>
												    <div class="col-md-2">تاريخ نهاية العمل</div>
												</div>
												
                                                <?php 	$engine->tsInputs(10);    ?>
												
											    <div class="col-md-12 col-lg-12 form-group form-inline title text-center">
												    المؤهلات العلمية
												</div>	
											    <div class="col-sm-12 col-lg-12 form-group form-inline uth">
												    <div class="col-md-4">المؤهل</div>
												    <div class="col-md-4">تاريخ الشهادة</div>
												    <div class="col-md-4">التخصص</div>
												</div>	
												
                                                 <?php 	$engine->tsInputs(10, 'q');    ?>
                          										
                                                </div>
                                            </div>											
                                            <div class="tab-pane" id="tab5">
                                                <div class="row">
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="entry_notes"> ملاحظات الدخول: </label>
                                                        <input type="text" name="entry_notes" class="form-control" id="entry_notes" value="" title="الملاحظات">
                                                    </div>
                                                    <div class="col-sm-6 col-lg-3 form-group form-inline">
                                                        <label class="col-sm-3 col-form-label" for="exit_notes"> ملاحظات الخروج: </label>
                                                        <input type="text" name="exit_notes" class="form-control" id="exit_notes" value="" title="الملاحظات">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-sm-6 col-lg-2 form-group ml-auto">
                                        <button type="submit" class="btn btn-primary btn-block" id="aeUserForm-btn">حفظ المعلومات</button>

                                    </div>
                                </form>

                            </div>

                            <div class="modal-footer">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal fade bd-example-modal-lg" id="PrintModal" tabindex="-1" role="dialog" aria-labelledby="PrintModal" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLongTitle">طباعة الوثائق الإدارية الخاصة بالمستخدم</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="col-md-3"> <a id="form" href="#" class="btn btn-primary btn-block" target="_blank" title="طباعة استمارة معلومات"><i class="fa fa-file-pdf-o"></i> استمارة معلومات</a></div>
                                        <div class="col-md-3"> <a id="certificate" href="#" class="btn btn-primary btn-block" target="_blank" title="طباعة شهادة عمل"><i class="fa fa-file-pdf-o"></i> شهادة عمل</a></div>
                                        <div class="col-md-3"> <a id="wrs" href="#" class="btn btn-primary btn-block" target="_blank" title="طباعة بيان استئناف العمل"><i class="fa fa-file-pdf-o"></i> بيان استئناف العمل</a></div>
                                        <div class="col-md-3"> <a id="nr" href="#" class="btn btn-primary btn-block" target="_blank" title="طباعة محضر التنصيب"><i class="fa fa-file-pdf-o"></i> محضر تنصيب</a></div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal fade bd-example-modal-lg" id="ProfitabilityPrintModal" tabindex="-1" role="dialog" aria-labelledby="ProfitabilityPrintModal" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLongTitle">طباعة جدول منحة الأداء التربوي</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="col-md-3"> <a href="print.php?doc=profitability" class="btn btn-primary btn-block" target="_blank" title="جميع المستخدمين"><i class="fa fa-file-pdf-o"></i> جميع المستخدمين</a></div>
                                        <div class="col-md-3"> <a href="print.php?doc=profitability&rnk_id=1" class="btn btn-primary btn-block" target="_blank" title="الأساتذة"><i class="fa fa-file-pdf-o"></i> الأساتذة</a></div>
                                        <div class="col-md-3"> <a href="print.php?doc=profitability&rnk_id=2" class="btn btn-primary btn-block" target="_blank" title="الإداريون"><i class="fa fa-file-pdf-o"></i> الإداريون</a></div>
                                        <div class="col-md-3"> <a href="print.php?doc=profitability&rnk_id=3" class="btn btn-primary btn-block" target="_blank" title="العمال"><i class="fa fa-file-pdf-o"></i> العمال</a></div>
                                    </div>
                                </div>

                            </div>
                            <div class="modal-footer">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal fade bd-example-modal-lg" id="TENRPrintModal" tabindex="-1" role="dialog" aria-labelledby="TENRPrintModal" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLongTitle">طباعة محضر الدخول الجماعي</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="col-md-4"> <a href="print.php?doc=enexr&rt=1&rnk_id=1" class="btn btn-primary btn-block" target="_blank" title="الأساتذة"><i class="fa fa-file-pdf-o"></i> الأساتذة</a></div>
                                        <div class="col-md-4"> <a href="print.php?doc=enexr&rt=1&rnk_id=2" class="btn btn-primary btn-block" target="_blank" title="الإداريون"><i class="fa fa-file-pdf-o"></i> الإداريون</a></div>
                                        <div class="col-md-4"> <a href="print.php?doc=enexr&rt=1&rnk_id=3" class="btn btn-primary btn-block" target="_blank" title="العمال"><i class="fa fa-file-pdf-o"></i> العمال</a></div>
                                    </div>
                                </div>

                            </div>
                            <div class="modal-footer">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal fade bd-example-modal-lg" id="TEXRPrintModal" tabindex="-1" role="dialog" aria-labelledby="TEXRPrintModal" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLongTitle">طباعة محضر الخروج الجماعي</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="col-md-4"> <a href="print.php?doc=enexr&rt=2&rnk_id=1" class="btn btn-primary btn-block" target="_blank" title="الأساتذة"><i class="fa fa-file-pdf-o"></i> الأساتذة</a></div>
                                        <div class="col-md-4"> <a href="print.php?doc=enexr&rt=2&rnk_id=2" class="btn btn-primary btn-block" target="_blank" title="الإداريون"><i class="fa fa-file-pdf-o"></i> الإداريون</a></div>
                                        <div class="col-md-4"> <a href="print.php?doc=enexr&rt=2&rnk_id=3" class="btn btn-primary btn-block" target="_blank" title="العمال"><i class="fa fa-file-pdf-o"></i> العمال</a></div>
                                    </div>
                                </div>

                            </div>
                            <div class="modal-footer">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal fade bd-example-modal-lg" id="FormPrintModal" tabindex="-1" role="dialog" aria-labelledby="FormPrintModal" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLongTitle">طباعة استمارات المعلومات</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="col-md-3"> <a href="print.php?doc=form" class="btn btn-primary btn-block" target="_blank" title="جميع المستخدمين"><i class="fa fa-file-pdf-o"></i> جميع المستخدمين</a></div>
                                        <div class="col-md-3"> <a href="print.php?doc=form&rnk_id=1" class="btn btn-primary btn-block" target="_blank" title="الأساتذة"><i class="fa fa-file-pdf-o"></i> الأساتذة</a></div>
                                        <div class="col-md-3"> <a href="print.php?doc=form&rnk_id=2" class="btn btn-primary btn-block" target="_blank" title="الإداريون"><i class="fa fa-file-pdf-o"></i> الإداريون</a></div>
                                        <div class="col-md-3"> <a href="print.php?doc=form&rnk_id=1" class="btn btn-primary btn-block" target="_blank" title="العمال"><i class="fa fa-file-pdf-o"></i> العمال</a></div>
                                    </div>
                                </div>

                            </div>
                            <div class="modal-footer">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal fade bd-example-modal-lg" id="CertificatePrintModal" tabindex="-1" role="dialog" aria-labelledby="CertificatePrintModal" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLongTitle">طباعة شهادات العمل</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="col-md-3"> <a href="print.php?doc=certificate" class="btn btn-primary btn-block" target="_blank" title="جميع المستخدمين"><i class="fa fa-file-pdf-o"></i> جميع المستخدمين</a></div>
                                        <div class="col-md-3"> <a href="print.php?doc=certificate&rnk_id=1" class="btn btn-primary btn-block" target="_blank" title="الأساتذة"><i class="fa fa-file-pdf-o"></i> الأساتذة</a></div>
                                        <div class="col-md-3"> <a href="print.php?doc=certificate&rnk_id=2" class="btn btn-primary btn-block" target="_blank" title="الإداريون"><i class="fa fa-file-pdf-o"></i> الإداريون</a></div>
                                        <div class="col-md-3"> <a href="print.php?doc=certificate&rnk_id=3" class="btn btn-primary btn-block" target="_blank" title="العمال"><i class="fa fa-file-pdf-o"></i> العمال</a></div>
                                    </div>
                                </div>

                            </div>
                            <div class="modal-footer">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal fade bd-example-modal-lg" id="WRSPrintModal" tabindex="-1" role="dialog" aria-labelledby="WRSPrintModal" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLongTitle">طباعة بيانات استئناف العمل</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="col-md-3"> <a href="print.php?doc=wrs" class="btn btn-primary btn-block" target="_blank" title="جميع المستخدمين"><i class="fa fa-file-pdf-o"></i> جميع المستخدمين</a></div>
                                        <div class="col-md-3"> <a href="print.php?doc=wrs&rnk_id=1" class="btn btn-primary btn-block" target="_blank" title="الأساتذة"><i class="fa fa-file-pdf-o"></i> الأساتذة</a></div>
                                        <div class="col-md-3"> <a href="print.php?doc=wrs&rnk_id=2" class="btn btn-primary btn-block" target="_blank" title="الإداريون"><i class="fa fa-file-pdf-o"></i> الإداريون</a></div>
                                        <div class="col-md-3"> <a href="print.php?doc=wrs&rnk_id=3" class="btn btn-primary btn-block" target="_blank" title="العمال"><i class="fa fa-file-pdf-o"></i> العمال</a></div>
                                    </div>
                                </div>

                            </div>
                            <div class="modal-footer">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal fade bd-example-modal-lg" id="NRPrintModal" tabindex="-1" role="dialog" aria-labelledby="NRPrintModal" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLongTitle">طباعة محاضر التنصيب</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="col-md-3"> <a href="print.php?doc=nr" class="btn btn-primary btn-block" target="_blank" title="جميع المستخدمين"><i class="fa fa-file-pdf-o"></i> جميع المستخدمين</a></div>
                                        <div class="col-md-3"> <a href="print.php?doc=nr&rnk_id=1" class="btn btn-primary btn-block" target="_blank" title="الأساتذة"><i class="fa fa-file-pdf-o"></i> الأساتذة</a></div>
                                        <div class="col-md-3"> <a href="print.php?doc=nr&rnk_id=2" class="btn btn-primary btn-block" target="_blank" title="الإداريون"><i class="fa fa-file-pdf-o"></i> الإداريون</a></div>
                                        <div class="col-md-3"> <a href="print.php?doc=nr&rnk_id=3" class="btn btn-primary btn-block" target="_blank" title="العمال"><i class="fa fa-file-pdf-o"></i> العمال</a></div>
                                    </div>
                                </div>

                            </div>
                            <div class="modal-footer">
                            </div>
                        </div>
                    </div>
                </div>
				
                <div class="modal fade bd-example-modal-lg" id="TSPrintModal" tabindex="-1" role="dialog" aria-labelledby="TSPrintModal" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLongTitle">طباعة مجمل الخدمات</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="col-md-3"> <a href="print.php?doc=ts" class="btn btn-primary btn-block" target="_blank" title="جميع المستخدمين"><i class="fa fa-file-pdf-o"></i> جميع المستخدمين</a></div>
                                        <div class="col-md-3"> <a href="print.php?doc=ts&rnk_id=1" class="btn btn-primary btn-block" target="_blank" title="الأساتذة"><i class="fa fa-file-pdf-o"></i> الأساتذة</a></div>
                                        <div class="col-md-3"> <a href="print.php?doc=ts&rnk_id=2" class="btn btn-primary btn-block" target="_blank" title="الإداريون"><i class="fa fa-file-pdf-o"></i> الإداريون</a></div>
                                        <div class="col-md-3"> <a href="print.php?doc=ts&rnk_id=3" class="btn btn-primary btn-block" target="_blank" title="العمال"><i class="fa fa-file-pdf-o"></i> العمال</a></div>
                                    </div>
                                </div>

                            </div>
                            <div class="modal-footer">
                            </div>
                        </div>
                    </div>
                </div>				

                <div class="modal fade" id="ImportModal" tabindex="-1" role="dialog" aria-labelledby="ImportModal" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="ImportModal">استيراد المستخدمين من موقع الأرضية الرقمية</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <div id="Import-msg">
                                    <!-- الخطأ يظهر هنا ! -->
                                </div>
                                <form id="Import-form">
                                    <input type="hidden" name="act" class="form-control" id="act" value="import" title="" required>
                                    <div class="form-group">
                                        <label for="iap" class="col-form-label">مديرية التربية:</label>
                                        <select name="iap" class="form-control" required>
                                            <option value="" selected="selected">-- يرجى الاختيار --</option>
                                            <option value="01021">مديرية التربية لولاية أدرار</option>
                                            <option value="02041">مديرية التربية لولاية الشلف</option>
                                            <option value="03021">مديرية التربية لولاية الأغواط</option>
                                            <option value="04041">مديرية التربية لولاية أم البواقي</option>
                                            <option value="05051">مديرية التربية لولاية باتنة</option>
                                            <option value="06051">مديرية التربية لولاية بجاية</option>
                                            <option value="07031">مديرية التربية لولاية بسكرة</option>
                                            <option value="08021">مديرية التربية لولاية بشار</option>
                                            <option value="09051">مديرية التربية لولاية البليدة</option>
                                            <option value="10041">مديرية التربية لولاية البويرة</option>
                                            <option value="11011">مديرية التربية لولاية تمنراست</option>
                                            <option value="12031">مديرية التربية لولاية تبسة</option>
                                            <option value="13041">مديرية التربية لولاية تلمسان</option>
                                            <option value="14041">مديرية التربية لولاية تيارت</option>
                                            <option value="15051">مديرية التربية لولاية تيزي وزو</option>
                                            <option value="16051">مديرية التربية للجزائر غرب</option>
                                            <option value="16052">مديرية التربية للجزائر وسط</option>
                                            <option value="16053">مديرية التربية للجزائر شرق</option>
                                            <option value="16181">وزارة التربية الوطنية</option>
                                            <option value="17031">مديرية التربية لولاية الجلفة</option>
                                            <option value="18041">مديرية التربية لولاية جيجل</option>
                                            <option value="19051">مديرية التربية لولاية سطيف</option>
                                            <option value="20031">مديرية التربية لولاية سعيدة</option>
                                            <option value="21041">مديرية التربية لولاية سكيكدة</option>
                                            <option value="22041">مديرية التربية لولاية سيدي بلعباس</option>
                                            <option value="23041">مديرية التربية لولاية عنابة</option>
                                            <option value="24031">مديرية التربية لولاية قالمة</option>
                                            <option value="25051">مديرية التربية لولاية قسنطينة</option>
                                            <option value="26041">مديرية التربية لولاية المدية</option>
                                            <option value="27041">مديرية التربية لولاية مستغانم</option>
                                            <option value="28041">مديرية التربية لولاية المسيلة</option>
                                            <option value="29041">مديرية التربية لولاية معسكر</option>
                                            <option value="30031">مديرية التربية لولاية ورقلة</option>
                                            <option value="31051">مديرية التربية لولاية وهران</option>
                                            <option value="32021">مديرية التربية لولاية البيض</option>
                                            <option value="33011">مديرية التربية لولاية إليزي</option>
                                            <option value="34041">مديرية التربية لولاية برج بوعريريج</option>
                                            <option value="35041">مديرية التربية لولاية بومرداس</option>
                                            <option value="36031">مديرية التربية لولاية الطارف</option>
                                            <option value="37011">مديرية التربية لولاية تندوف</option>
                                            <option value="38021">مديرية التربية لولاية تيسمسيلت</option>
                                            <option value="39031">مديرية التربية لولاية الوادي</option>
                                            <option value="40031">مديرية التربية لولاية خنشلة</option>
                                            <option value="41031">مديرية التربية لولاية سوق أهراس</option>
                                            <option value="42041">مديرية التربية لولاية تيبازة</option>
                                            <option value="43041">مديرية التربية لولاية ميلة</option>
                                            <option value="44041">مديرية التربية لولاية عين الدفلى</option>
                                            <option value="45011">مديرية التربية لولاية النعامة</option>
                                            <option value="46031">مديرية التربية لولاية عين تيموشنت</option>
                                            <option value="47021">مديرية التربية لولاية غرداية</option>
                                            <option value="48041">مديرية التربية لولاية غليزان</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="user_name" class="col-form-label">اسم المستخدم:</label>
                                        <input type="text" name="user_name" class="form-control" id="user_name" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="password" class="col-form-label">كلمة المرور:</label>
                                        <input type="password" name="password" class="form-control" id="password" required>
                                    </div>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary btn-block" id="Import-btn">استيراد</button>
                            </div>
                            </form>
                        </div>
                    </div>
                </div>
                <?php include_once 'includes/footer.inc.php'; ?>

                    <script type="text/javascript" language="javascript" class="init">
                        $(document).ready(function() {
                            var table = $('#show').DataTable({
                                "responsive": true,
                                "pageLength": 5,
                                "bLengthChange": false,
                                "info": false,
                                "aoColumns": [
                                    null,
                                    null,
                                    null,
                                    null, {
                                        "sClass": "rank"
                                    }, {
                                        "sClass": "mat"
                                    },
                                    null,
                                    null, {
                                        "sClass": "ops"
                                    },
                                ],
                                "order": [
                                    [4, 'asc']
                                ],
                                ajax: {
                                    url: "server.php",
                                    data: {
                                        'act': 'show',
                                    },
                                    dataType: "json",
                                    method: "POST"
                                }
                            });
                        });

                        function sendToServer(act, id) {

                            swal({
                                title: 'هل أنت متأكد من حذف المستخدم؟',
                                text: "لن تتمكن من التراجع عن هذا!",
                                type: 'warning',
                                showCancelButton: true,
                                confirmButtonColor: '#3085d6',
                                cancelButtonColor: '#d33',
                                cancelButtonText: 'تراجع',
                                confirmButtonText: 'نعم، احذف!'
                            }).then((result) => {
                                if (result.value) {
                                    $.post("server.php", {
                                        act: act,
                                        id: id,
                                    }, (data, status) => {
                                        if (data === "1") {
                                            swal({
                                                type: 'success',
                                                title: 'تمت عملية الحذف بنجاح',
                                                showConfirmButton: false,
                                                timer: 1500
                                            })
                                        } else {
                                            swal({
                                                type: 'error',
                                                title: 'حدث خطأ ما :(',
                                                showConfirmButton: false,
                                                timer: 1500
                                            })
                                        }
                                        $('#show').DataTable().ajax.reload().draw(false);
                                    });
                                }
                            })

                        }

                        function cleanDatabase() {

                            swal({
                                title: 'هل أنت متأكد من مسح جميع البيانات',
                                text: "لن تتمكن من التراجع عن هذا!",
                                type: 'warning',
                                showCancelButton: true,
                                confirmButtonColor: '#3085d6',
                                cancelButtonColor: '#d33',
                                cancelButtonText: 'تراجع',
                                confirmButtonText: 'نعم، امسح!'
                            }).then((result) => {
                                if (result.value) {
                                    $.post("server.php", {
                                        act: 'cleanDB',
                                    }, (data, status) => {
                                        if (data === "1") {
                                            swal({
                                                type: 'success',
                                                title: 'تمّت عملية المسح بنجاح',
                                                showConfirmButton: false,
                                                timer: 1500
                                            })
                                        } else {
                                            swal({
                                                type: 'error',
                                                title: 'حدث خطأ ما :(',
                                                showConfirmButton: false,
                                                timer: 1500
                                            })
                                        }
                                        $('#show').DataTable().ajax.reload().draw(false);
                                    });
                                }
                            })

                        }

                        function exportXLS() {
                            $.ajax({

                                type: 'POST',
                                url: 'server.php',
                                data: 'act=export',
                                success: function(response) {
                                    setTimeout(' window.location.href = "users.xls"; ', 2000);
                                }
                            });

                        }

                        function UserModal(id = 0) {

                            $.ajax({

                                type: 'POST',
                                url: 'server.php',
                                data: 'act=utoedit&id=' + id + '',
                                success: function(response) {
                                    if (response) {

                                        var re = JSON.parse(response);

                                        for (var key in re) {
                                            $("#aeUserForm [name=" + key + "").val(re[key]);
                                        }

                                    };

                                }

                            });

                            document.getElementById("act").setAttribute("value", "edit");

                        }

                        function PrintModal(id = 0) {
                            document.getElementById("form").setAttribute("href", "print.php?doc=form&id=" + id);
                            document.getElementById("certificate").setAttribute("href", "print.php?doc=certificate&id=" + id);
                            document.getElementById("wrs").setAttribute("href", "print.php?doc=wrs&id=" + id);
                            document.getElementById("nr").setAttribute("href", "print.php?doc=nr&id=" + id);
                        }

                        $('#UserModal').on('hidden.bs.modal', function() {
                            $('#aeUserForm')[0].reset();
                            document.getElementById("act").setAttribute("value", "add");

                        });

                        jQuery('#datetimepicker1').datetimepicker({
                            timepicker: false,
                            format: 'Y-m-d'
                        });
                        jQuery('#datetimepicker2').datetimepicker({
                            timepicker: false,
                            format: 'Y-m-d'
                        });
                        jQuery('#datetimepicker3').datetimepicker({
                            timepicker: false,
                            format: 'Y-m-d'
                        });
                        jQuery('#datetimepicker4').datetimepicker({
                            timepicker: false,
                            format: 'Y-m-d'
                        });
                        jQuery('#datetimepicker5').datetimepicker({
                            timepicker: false,
                            format: 'Y-m-d'
                        });
                        jQuery('#datetimepicker6').datetimepicker({
                            timepicker: false,
                            format: 'Y-m-d'
                        });
                        jQuery('#datetimepicker7').datetimepicker({
                            timepicker: false,
                            format: 'Y-m-d'
                        });
                        jQuery('#datetimepicker8').datetimepicker({
                            timepicker: false,
                            format: 'Y-m-d'
                        });
                        jQuery('#datetimepicker9').datetimepicker({
                            timepicker: false,
                            format: 'Y-m-d'
                        });

                        jQuery('#datetimepicker10').datetimepicker({
                            timepicker: false,
                            format: 'Y-m-d'
                        });
                        jQuery('#datetimepicker11').datetimepicker({
                            timepicker: false,
                            format: 'Y-m-d'
                        });						
						
                        function bdate() {
                        	 if(document.getElementById("birth_date2").value !== "") { 
                        			document.getElementById('datetimepicker1').value = "";	 
                                    document.getElementById('datetimepicker1').disabled = true; 
                                } else { 
                                    document.getElementById('datetimepicker1').disabled = false;
                                }
                        }
						
                        function admFD() {
                        	 if(document.getElementById("administrative_status").value == "مرسم(ة)") { 
                                    document.getElementById('datetimepicker10').disabled = false; 
                                } else { 
                        			document.getElementById('datetimepicker10').value = "";	 								
                                    document.getElementById('datetimepicker10').disabled = true;
                                }
                        }						
						
                    </script>

                    <script src="<?php echo HOME_URL . '/assets/js/jquery.dataTables.min.js'; ?>"></script>
                    <script src="<?php echo HOME_URL . '/assets/js/dataTables.bootstrap4.min.js '; ?>"></script>
                    <script src="<?php echo HOME_URL . '/assets/js/bootstrap.min.js'; ?>"></script>

    </body>

    </html>