<?php 
/*
-----------------------------------------------
            برنامج الرفيق            
-----------------------------------------------
برمجة وتطوير: عادل قصي
البريد الإلكتروني: adelbak2014@gmail.com
الموقع الرسمي: https://github.com/adelbak/EL-RAFIK
الصفحة الرسمية للمبرمج: https://www.facebook.com/adel.qusay.9
-----------------------------------------------
*/

include_once DIR_MODS . '/includes/header.inc.php';

?>

	<body>
		<?php 
		    if ( $_SESSION['last_up_check'] < (time() - 60*15) ) { 
    	        $engine->checkUpdate(); 
            }
	    ?>
			<?php include_once DIR_MODS . '/includes/navbar.inc.php'; ?>
				<!---Section-->
				<section id="sections" class="py-4 bg-faded">
					<div class="container">
						<div class="row">
							<?php $engine->settingsChecker(); ?>
								<div class="col-md-2">
									<button type="submit" class="btn btn-danger btn-block" data-toggle="modal" data-target="#UserModal"> <i class="fa fa-plus"></i> إضافة مستخدم </button>
								</div>
								<div class="col-md-2">
									<button type="submit" class="btn btn-danger btn-block text-white" data-toggle="modal" data-target="#ImportModal" title="استيراد المستخدمين من موقع الأرضية الرقمية"> <i class="fa fa-database"></i> استيراد المستخدمين </button>
								</div>
								<div class="col-md-2">
									<button type="submit" class="btn btn-success btn-block text-white" data-toggle="modal" data-target="#ProfitabilityPrintModal" title="طباعة جدول منحة الأداء التربوي"> <i class="fa fa-print"></i> جدول منحة الأداء التربوي </button>
								</div>
								<div class="col-md-2">
									<button type="submit" class="btn btn-success btn-block text-white" data-toggle="modal" data-target="#TENRPrintModal" title="طباعة محضر الدخول الجماعي"> <i class="fa fa-print"></i> محضر الدخول الجماعي </button>
								</div>
								<div class="col-md-2">
									<button type="submit" class="btn btn-success btn-block text-white" data-toggle="modal" data-target="#TEXRPrintModal" title="طباعة محضر الخروج الجماعي"> <i class="fa fa-print"></i> محضر الخروج الجماعي </button>
								</div>
								<div class="col-md-2">
									<button type="submit" class="btn btn-success btn-block text-white" data-toggle="modal" data-target="#FormPrintModal" title="طباعة استمارات المعلومات"> <i class="fa fa-print"></i> استمارات المعلومات </button>
								</div>
						</div>
						<div class="row mt-2">
							<div class="col-md-2">
								<button type="submit" class="btn btn-success btn-block text-white" data-toggle="modal" data-target="#CertificatePrintModal" title="طباعة شهادات العمل"> <i class="fa fa-print"></i> شهادات العمل </button>
							</div>
							<div class="col-md-2">
								<button type="submit" class="btn btn-success btn-block text-white" data-toggle="modal" data-target="#WRSPrintModal" title="طباعة بيانات استئناف العمل"> <i class="fa fa-print"></i> بيانات استئناف العمل </button>
							</div>
							<div class="col-md-2">
								<button type="submit" class="btn btn-success btn-block text-white" data-toggle="modal" data-target="#NRPrintModal" title="طباعة محاضر التنصيب"> <i class="fa fa-print"></i> محاضر التنصيب </button>
							</div>
							<div class="col-md-2">
								<button type="submit" class="btn btn-success btn-block text-white" data-toggle="modal" data-target="#TSPrintModal" title="طباعة مجمل الخدمات"> <i class="fa fa-print"></i> مجمل الخدمات </button>
							</div>
							<div class="col-md-2">
								<button type="submit" class="btn btn-success btn-block text-white" onclick="exportXLS()" title="تصدير بيانات المستخدمين"> <i class="fa fa-file-excel-o"></i> تصدير بيانات المستخدمين </button>
							</div>
							<div class="col-md-2">
								<button type="submit" class="btn btn-warning btn-block text-white" onclick="deleteUsers()" title="حذف بيانات المستخدمين"> <i class="fa fa-exclamation-triangle "></i> حذف بيانات المستخدمين </button>
							</div>
						</div>
					</div>
				</section>
				<section id="posts" class="py-4 mb-4">
					<div class="container">
						<div class="row">
							<div class="col">
								<table id="show" class="table table-striped table-bordered" cellspacing="0" width="100%">
									<thead class="thead thead-light">
										<tr>
											<th>الرقم الوظيفي</th>
											<th>اللقب</th>
											<th>الاسم</th>
											<th>تاريخ الازدياد</th>
											<th>الرتبة</th>
											<th>المادة</th>
											<th>الدرجة</th>
											<th>آخر تحديث</th>
											<th>العمليات</th>
										</tr>
									</thead>
								</table>
							</div>
						</div>
					</div>
				</section>
				<div class="modal fade" id="UserModal" tabindex="-1" role="dialog" aria-labelledby="UserModal" aria-hidden="true">
					<div class="modal-dialog modal-full" role="document">
						<div class="modal-content">
							<div class="modal-header">
								<h5 class="modal-title">معلومات المستخدم <span class="note"> <i class="fa fa-bell"></i> ملحوظة: يجب ملء كل الخانات المؤشرة بالنجمة</span></h5>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">×</span> </button>
							</div>
							<div class="modal-body p-4" id="result">
								<div id="aeUserForm-msg">
									<!-- الخطأ يظهر هنا ! -->
								</div>
								<form id="aeUserForm">
									<div class="tabbable">
										<ul class="nav nav-tabs" role="tablist">
											<li class="nav-item"><a class="nav-link active" href="#tab1" data-toggle="tab">الحالة المدنية والمهنية</a></li>
											<li class="nav-item"><a class="nav-link" href="#tab2" data-toggle="tab">مجمل الخدمات</a></li>
										</ul>
										<div class="tab-content">
											<input type="hidden" name="id" class="form-control" id="id" value="" title="">
											<input type="hidden" name="act" class="form-control" id="act" value="add" title="">
											<div class="tab-pane active" id="tab1">
												<br>
												<div class="row">
													<div class="col-md-2">
														<h6 class="text-muted">الحالة المدنية والعائلية</h6> </div>
													<div class="col-md-10">
														<hr class="mb-4"> </div>
												</div>
												<div class="form-group">
													<div class="row">
														<div class="col-md-2">
															<label for="surname">اللقب: <i class="req">*</i></label>
															<input type="text" name="surname" id="surname" value="" class="form-control" maxlength="100" placeholder="" required> </div>
														<div class="col-md-2">
															<label for="name">الاسم: <i class="req">*</i></label>
															<input type="text" name="name" id="name" value="" class="form-control" maxlength="100" placeholder="" required> </div>
														<div class="col-md-2">
															<label for="latin_surname">اللقب بالاتينية:</label>
															<input type="text" name="latin_surname" id="latin_surname" value="" class="form-control" maxlength="100" placeholder=""> </div>
														<div class="col-md-2">
															<label for="latin_name">الاسم بالاتينية:</label>
															<input type="text" name="latin_name" id="latin_name" value="" class="form-control" maxlength="100" placeholder=""> </div>
														<div class="col-md-2">
															<label for="father_name">اسم الأب:</label>
															<input type="text" name="father_name" id="father_name" value="" class="form-control" maxlength="100" placeholder=""> </div>
														<div class="col-md-2">
															<label for="father_latin_name">اسم الأب بالاتينية:</label>
															<input type="text" name="father_latin_name" id="father_latin_name" value="" class="form-control" maxlength="100" placeholder=""> </div>
													</div>
												</div>
												<div class="form-group">
													<div class="row">
														<div class="col-md-2">
															<label for="mother_surname">لقب الأم:</label>
															<input type="text" name="mother_surname" id="mother_surname" value="" class="form-control" maxlength="100" placeholder=""> </div>
														<div class="col-md-2">
															<label for="mother_name">اسم الأم:</label>
															<input type="text" name="mother_name" id="mother_name" value="" class="form-control" maxlength="100" placeholder=""> </div>
														<div class="col-md-2">
															<label for="mother_latin_surname">لقب الأم بالاتينية:</label>
															<input type="text" name="mother_latin_surname" id="mother_latin_surname" value="" class="form-control" maxlength="100" placeholder=""> </div>
														<div class="col-md-2">
															<label for="mother_latin_name">اسم الأم بالاتينية:</label>
															<input type="text" name="mother_latin_name" id="mother_latin_name" value="" class="form-control" maxlength="100" placeholder=""> </div>
														<div class="col-md-2">
															<label for="family_status">الحالة العائلية:</label>
															<select name="family_status" id="family_status" class="form-control" title="الحالة العائلية">
																<option value="" selected="selected">-- الرجاء الاختيار --</option>
																<option value="متزوج(ة)">متزوج(ة)</option>
																<option value="أعزب(ة)">أعزب(ة)</option>
																<option value="مطلق(ة)">مطلق(ة)</option>
																<option value="أرمل(ة)">أرمل(ة)</option>
															</select>
														</div>
														<div class="col-md-2">
															<label for="married_women_orig_surname">اللقب الأصلي للسيدات:</label>
															<input type="text" name="married_women_orig_surname" id="married_women_orig_surname" value="" class="form-control" maxlength="100" placeholder=""> </div>
													</div>
												</div>
												<div class="form-group">
													<div class="row">
														<div class="col-md-2">
															<label for="children_number">عدد الأولاد:</label>
															<input type="number" name="children_number" id="children_number" value="" class="form-control" min="0" max="100" placeholder="" number="true"> </div>
														<div class="col-md-2">
															<label for="greater_than_10_years">أكبر من 10 سنوات:</label>
															<input type="number" name="greater_than_10_years" id="greater_than_10_years" value="" class="form-control" min="0" max="100" step="1" placeholder="" number="true"> </div>
														<div class="col-md-2">
															<label for="learning">المتمدرسون:</label>
															<input type="number" name="learning" id="learning" value="" class="form-control" min="0" max="100" step="1" placeholder="" number="true"> </div>
														<div class="col-md-2">
															<label for="insurers">المتكفل بهم:</label>
															<input type="number" name="insurers" id="insurers" value="" class="form-control" min="0" max="100" step="1" placeholder="" number="true"> </div>
														<div class="col-md-2">
															<label for="birth_date">تاريخ الميلاد: <i class="req">*</i></label>
															<input type="text" id="birth_date" name="birth_date" class="form-control datepicker" dateISO="true" placeholder="" required> </div>
														<div class="col-md-2">
															<label for="birth_date2">حُكم:</label>
															<input type="number" id="birth_date2" name="birth_date2" class="form-control" onchange="bdate()" min="1900" max="2099" step="1"> </div>
													</div>
												</div>
												<div class="form-group">
													<div class="row">
														<div class="col-md-2">
															<label for="birth_place">مكان الميلاد: <i class="req">*</i></label>
															<input type="text" name="birth_place" id="birth_place" value="" class="form-control" maxlength="100" placeholder="" required> </div>
														<div class="col-md-2">
															<label for="nationality">الجنسية:</label>
															<input type="text" name="nationality" class="form-control" id="nationality" value="" maxlength="100" placeholder=""> </div>
														<div class="col-md-2">
															<label for="blood_type">فصيلة الدم:</label>
															<select name="blood_type" id="blood_type" class="form-control" title="فصيلة الدم">
																<option value="" selected="selected">-- الرجاء الاختيار --</option>
																<option value="O -">O -</option>
																<option value="O +">O +</option>
																<option value="A -">A -</option>
																<option value="A +">A +</option>
																<option value="B -">B -</option>
																<option value="B +">B +</option>
																<option value="AB -">AB -</option>
																<option value="AB +">AB +</option>
															</select>
														</div>
														<div class="col-md-2">
															<label for="optical_power">القدرة البصرية:</label>
															<input type="number" name="optical_power" class="form-control" min="0" max="10" step=".01"> </div>
														<div class="col-md-2">
															<label for="address">العنوان:</label>
															<input type="text" name="address" id="address" value="" class="form-control" maxlength="100" placeholder=""> </div>
														<div class="col-md-2">
															<label for="postal_code">الرمز البريدي:</label>
															<input type="number" name="postal_code" class="form-control"> </div>
													</div>
												</div>
												<div class="row">
													<div class="col-md-2">
														<h6 class="text-muted">الحالة المهنية:</h6> </div>
													<div class="col-md-10">
														<hr class="mb-4"> </div>
												</div>
												<div class="form-group">
													<div class="row">
														<div class="col-md-2">
															<label for="func_id">الرقم الوظيفي: <i class="req">*</i></label>
															<input type="number" name="func_id" id="func_id" value="" class="form-control" maxlength="18" placeholder="" required> </div>
														<div class="col-md-2">
															<label for="sector_bilateral">ثنائي في القطاع:</label>
															<select name="sector_bilateral" id="sector_bilateral" class="form-control">
																<option value="" selected="selected">-- الرجاء الاختيار --</option>
																<option value="لا">لا</option>
																<option value="نعم">نعم</option>
															</select>
														</div>
														<div class="col-md-2">
															<label for="current_rank">الرتبة الحالية: <i class="req">*</i></label>
															<select name="current_rank" id="current_rank" class="form-control" required>
																<option value="" selected="selected">-- الرجاء الاختيار --</option>
																<?php 	$engine->ranks('select');    ?>
															</select>
														</div>
														<div class="col-md-2">
															<label for="current_rank_date">تاريخ الرتبة الحالية:</label>
															<input type="text" id="current_rank_date" name="current_rank_date" class="form-control datepicker" dateISO="true" placeholder=""> </div>
														<div class="col-md-2">
															<label for="type">الصنف:</label>
															<input type="number" name="type" id="type" value="" class="form-control" min="0" max="20" step="1"> </div>
														<div class="col-md-2">
															<label for="specialization">مادة التخصص:</label>
															<input type="text" name="specialization" id="specialization" value="" class="form-control" maxlength="100" placeholder=""> </div>
													</div>
												</div>
												<div class="form-group">
													<div class="row">
														<div class="col-md-2">
															<label for="teaching_material">مادة التدريس:</label>
															<input type="text" id="teaching_material" name="teaching_material" class="form-control" maxlength="100" placeholder=""> </div>
														<div class="col-md-2">
															<label for="administrative_status">الوضعية الإدارية: <i class="req">*</i></label>
															<select name="administrative_status" id="administrative_status" onchange="admFD()" class="form-control" required>
																<option value="" selected="selected">-- الرجاء الاختيار --</option>
																<option value="مرسم(ة)">مرسم(ة)</option>
																<option value="متربص(ة)">متربص(ة)</option>
																<option value="متعاقد(ة)">متعاقد(ة)</option>
																<option value="مستخلف(ة)">مستخلف(ة)</option>
															</select>
														</div>
														<div class="col-md-2">
															<label for="fixing_date">تاريخ الترسيم:</label>
															<input type="text" id="fixing_date" name="fixing_date" class="form-control datepicker" dateISO="true" placeholder=""> </div>
														<div class="col-md-2">
															<label for="class">الدرجة:</label>
															<input type="number" name="class" id="class" value="" class="form-control" min="0" max="30" step="1"> </div>
														<div class="col-md-2">
															<label for="class_effective_date">تاريخ سريان الدرجة:</label>
															<input type="text" id="class_effective_date" name="class_effective_date" class="form-control datepicker" dateISO="true" placeholder=""> </div>
														<div class="col-md-2">
															<label for="employment_date">تاريخ التوظيف:</label>
															<input type="text" id="employment_date" name="employment_date" class="form-control datepicker" dateISO="true" placeholder=""> </div>
													</div>
												</div>
												<div class="form-group">
													<div class="row">
														<div class="col-md-2">
															<label for="nomination_report_number">رقم قرار التعيين:</label>
															<input type="text" id="nomination_report_number" name="nomination_report_number" class="form-control" maxlength="100" placeholder=""> </div>
														<div class="col-md-2">
															<label for="nomination_report_date">تاريخ قرار التعيين:</label>
															<input type="text" id="nomination_report_date" name="nomination_report_date" class="form-control datepicker" dateISO="true" placeholder=""> </div>
														<div class="col-md-2">
															<label for="c_school_employment_date">تاريخ التعيين في المؤسسة الحالية:</label>
															<input type="text" id="c_school_employment_date" name="c_school_employment_date" class="form-control datepicker" dateISO="true" placeholder=""> </div>
														<div class="col-md-2">
															<label for="last_inspection_visit_date">تاريخ آخر زيارة تفتيشية:</label>
															<input type="text" id="last_inspection_visit_date" name="last_inspection_visit_date" class="form-control datepicker" dateISO="true" placeholder=""> </div>
														<div class="col-md-2">
															<label for="qualifications">المؤهلات العلمية:</label>
															<input type="text" id="qualifications" name="qualifications" class="form-control" maxlength="500" placeholder=""> </div>
														<div class="col-md-2">
															<label for="postal_account_number">رقم الحساب البريدي:</label>
															<input type="text" id="postal_account_number" name="postal_account_number" class="form-control" maxlength="50" placeholder=""> </div>
													</div>
												</div>
												<div class="form-group">
													<div class="row">
														<div class="col-md-2">
															<label for="pan_key">المفتاح:</label>
															<input type="text" id="pan_key" name="pan_key" class="form-control" maxlength="5" placeholder=""> </div>
														<div class="col-md-2">
															<label for="social_security_number">رقم الضمان الاجتماعي:</label>
															<input type="text" id="social_security_number" name="social_security_number" class="form-control" maxlength="50" placeholder=""> </div>
														<div class="col-md-2">
															<label for="mtutalism_number">رقم التعاضدية:</label>
															<input type="text" id="mtutalism_number" name="mtutalism_number" class="form-control" maxlength="50" placeholder=""> </div>
														<div class="col-md-2">
															<label for="phone_number">الهاتف:</label>
															<input type="text" id="phone_number" name="phone_number" class="form-control" maxlength="50" placeholder=""> </div>
														<div class="col-md-2">
															<label for="email">البريد الإلكتروني:</label>
															<input type="email" id="email" name="email" class="form-control" placeholder="" email="true"> </div>
													</div>
												</div>
												<div class="row">
													<div class="col-md-2">
														<h6 class="text-muted">العمل النقابي</h6> </div>
													<div class="col-md-10">
														<hr class="mb-4"> </div>
												</div>
												<div class="form-group">
													<div class="row">
														<div class="col-md-4">
															<label for="syndicalist">التنظيم النقابي:</label>
															<select name="syndicalist" id="syndicalist" class="form-control">
																<option value="" selected="selected">-- الرجاء الاختيار --</option>
																<option value="مجلس ثانويات الجزائر">مجلس ثانويات الجزائر</option>
																<option value="المجلس الوطني المستقل لمستخدمي التدريس للقطاع ثلاثي الأطوار للتربية">المجلس الوطني المستقل لمستخدمي التدريس للقطاع ثلاثي الأطوار للتربية</option>
																<option value="النقابة المستقلة لعمال التربية و التكوين">النقابة المستقلة لعمال التربية و التكوين</option>
																<option value="النقابة الوطنية المستقلة لموظفي الإدارة العمومية">النقابة الوطنية المستقلة لموظفي الإدارة العمومية</option>
																<option value="النقابة الوطنية المستقلة لاساتذة التعليم الثانوي والتقني">النقابة الوطنية المستقلة لاساتذة التعليم الثانوي والتقني</option>
																<option value="النقابة الوطنية لأساتذة التعليم الابتدائي">النقابة الوطنية لأساتذة التعليم الابتدائي</option>
																<option value="النقابة الوطنية للأسلاك المشتركة و العمال المهنيين لقطاع التربية">النقابة الوطنية للأسلاك المشتركة و العمال المهنيين لقطاع التربية</option>
																<option value="النقابة الوطنية لعمال التربية">النقابة الوطنية لعمال التربية</option>
																<option value="الاتحاد العام للعمال الجزائريين">الاتحاد العام للعمال الجزائريين</option>
																<option value="الاتحاد الوطني لعمال التربية و التكوين">الاتحاد الوطني لعمال التربية و التكوين</option>
															</select>
														</div>
														<div class="col-md-4">
															<label for="syndicalistic_type">صفة الانتماء:</label>
															<select name="syndicalistic_type" id="syndicalistic_type" class="form-control">
																<option value="" selected="selected">-- الرجاء الاختيار --</option>
																<option value="منخرط">منخرط</option>
																<option value="عضو فرع محلي">عضو فرع محلي</option>
																<option value="عضو مكتب ولائي">عضو مكتب ولائي</option>
																<option value="عضو مكتب جهوي">عضو مكتب جهوي</option>
																<option value="عضو مكتب او مجلس وطني">عضو مكتب او مجلس وطني</option>
															</select>
														</div>
														<div class="col-md-4">
															<label for="syndicalistic_date">تاريخ الانخراط:</label>
															<input type="text" id="syndicalistic_date" name="syndicalistic_date" class="form-control datepicker" dateISO="true" placeholder=""> </div>
													</div>
												</div>
												<div class="row">
													<div class="col-md-2">
														<h6 class="text-muted">منحة المردودية</h6> </div>
													<div class="col-md-10">
														<hr class="mb-4"> </div>
												</div>
												<div class="form-group">
													<div class="row">
														<div class="col-md-4">
															<label for="profitability_note">العلامة:</label>
															<input type="number" name="profitability_note" id="profitability_note" value="" class="form-control" min="0" max="20" step="1"> </div>
														<div class="col-md-4">
															<label for="profitability_aps">عدد الغيابات:</label>
															<input type="number" name="profitability_aps" id="profitability_aps" value="" class="form-control" min="0" max="100" step="1"> </div>
														<div class="col-md-4">
															<label for="profitability_notes">الملاحظات:</label>
															<input type="text" id="profitability_notes" name="profitability_notes" class="form-control" maxlength="500" placeholder=""> </div>
													</div>
												</div>
												<div class="row">
													<div class="col-md-2">
														<h6 class="text-muted">الدخول والخروج</h6> </div>
													<div class="col-md-10">
														<hr class="mb-4"> </div>
												</div>
												<div class="form-group">
													<div class="row">
														<div class="col-md-6">
															<label for="entry_notes">ملاحظات الدخول:</label>
															<input type="text" id="entry_notes" name="entry_notes" class="form-control" maxlength="500" placeholder=""> </div>
														<div class="col-md-6">
															<label for="exit_notes">ملاحظات الخروج:</label>
															<input type="text" id="exit_notes" name="exit_notes" class="form-control" maxlength="500" placeholder=""> </div>
													</div>
												</div>
											</div>
											<div class="tab-pane" id="tab2">
												<br>
												<div class="row">
													<div class="col-md-2">
														<h6 class="text-muted">النقاط الإدارية والتربوية</h6> </div>
													<div class="col-md-10">
														<hr class="mb-4"> </div>
												</div>
												<div class="form-group">
													<div class="row">
														<div class="col-md-3">
															<label for="administrative_point">النقطة الإدارية:</label>
															<input type="number" name="administrative_point" id="administrative_point" value="" class="form-control" min="0" max="20" step=".01"> </div>
														<div class="col-md-3">
															<label for="administrative_point_date">تاريخ النقطة الإدارية:</label>
															<input type="text" id="administrative_point_date" name="administrative_point_date" class="form-control datepicker" dateISO="true" placeholder=""> </div>
														<div class="col-md-3">
															<label for="educational_point">النقطة التربوية:</label>
															<input type="number" name="educational_point" id="educational_point" value="" class="form-control" min="0" max="20" step=".01"> </div>
														<div class="col-md-3">
															<label for="educational_point_date">تاريخ النقطة التربوية:</label>
															<input type="text" id="educational_point_date" name="educational_point_date" class="form-control datepicker" dateISO="true" placeholder=""> </div>
													</div>
												</div>
												<div class="row">
													<div class="col-md-2">
														<h6 class="text-muted">مجمل الخدمات</h6> </div>
													<div class="col-md-8">
														<hr class="mb-4"> </div>
													<div class="col-md-2">
														<button type="button" class="btn btn-outline-danger btn-block ml-auto" id="moreFields1" onclick="addMoreFields('1')"><i class="fa fa-plus"></i> أضف خانة خدمة</button>
													</div>
												</div>
												<?php 	$engine->tsInputs();    ?>
													<div class="row">
														<div class="col-md-2">
															<h6 class="text-muted">المؤهلات العلمية</h6> </div>
														<div class="col-md-8">
															<hr class="mb-4"> </div>
														<div class="col-md-2">
															<button type="button" class="btn btn-outline-danger btn-block ml-auto" id="moreFields2" onclick="addMoreFields('2')"><i class="fa fa-plus"></i> أضف خانة مؤهل</button>
														</div>
													</div>
													<?php 	$engine->tsInputs('q');    ?>
											</div>
										</div>
									</div>
							</div>
							<div class="modal-footer">
								<div class="btn-group">
									<button type="submit" class="btn btn-success" id="aeUserForm-btn">حــفظ</button>
									<button type="button" class="btn btn-danger" data-dismiss="modal">تراجع</button>
								</div>
							</div>
							</form>
						</div>
					</div>
				</div>
				<div class="modal fade bd-example-modal-lg" id="PrintModal" tabindex="-1" role="dialog" aria-labelledby="PrintModal" aria-hidden="true">
					<div class="modal-dialog modal-lg">
						<div class="modal-content">
							<div class="modal-header">
								<h5 class="modal-title" id="exampleModalLongTitle">طباعة الوثائق الإدارية الخاصة بالمستخدم</h5>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
							</div>
							<div class="modal-body">
								<div class="container-fluid">
									<div class="row">
										<div class="col-md-3"> <a id="form" href="#" class="btn btn-primary btn-block" target="_blank" title="طباعة استمارة معلومات"><i class="fa fa-file-pdf-o"></i> استمارة معلومات</a></div>
										<div class="col-md-3"> <a id="certificate" href="#" class="btn btn-primary btn-block" target="_blank" title="طباعة شهادة عمل"><i class="fa fa-file-pdf-o"></i> شهادة عمل</a></div>
										<div class="col-md-3"> <a id="wrs" href="#" class="btn btn-primary btn-block" target="_blank" title="طباعة بيان استئناف العمل"><i class="fa fa-file-pdf-o"></i> بيان استئناف العمل</a></div>
										<div class="col-md-3"> <a id="nr" href="#" class="btn btn-primary btn-block" target="_blank" title="طباعة محضر التنصيب"><i class="fa fa-file-pdf-o"></i> محضر تنصيب</a></div>
									</div>
									<div class="row mt-2">
										<div class="col-md-3"> <a id="ts" href="#" class="btn btn-primary btn-block" target="_blank" title="طباعة مجمل الخدمات"><i class="fa fa-file-pdf-o"></i> مجمل الخدمات</a></div>
									</div>
								</div>
							</div>
							<div class="modal-footer"> </div>
						</div>
					</div>
				</div>
				<div class="modal fade bd-example-modal-lg" id="ProfitabilityPrintModal" tabindex="-1" role="dialog" aria-labelledby="ProfitabilityPrintModal" aria-hidden="true">
					<div class="modal-dialog modal-lg">
						<div class="modal-content">
							<div class="modal-header">
								<h5 class="modal-title" id="exampleModalLongTitle">طباعة جدول منحة الأداء التربوي</h5>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
							</div>
							<div class="modal-body">
								<div class="container-fluid">
									<div class="row">
										<div class="col-md-3"> <a href="print.php?doc=profitability" class="btn btn-primary btn-block" target="_blank" title="جميع المستخدمين"><i class="fa fa-file-pdf-o"></i> جميع المستخدمين</a></div>
										<div class="col-md-3"> <a href="print.php?doc=profitability&rnk_id=1" class="btn btn-primary btn-block" target="_blank" title="الأساتذة"><i class="fa fa-file-pdf-o"></i> الأساتذة</a></div>
										<div class="col-md-3"> <a href="print.php?doc=profitability&rnk_id=2" class="btn btn-primary btn-block" target="_blank" title="الإداريون"><i class="fa fa-file-pdf-o"></i> الإداريون</a></div>
										<div class="col-md-3"> <a href="print.php?doc=profitability&rnk_id=3" class="btn btn-primary btn-block" target="_blank" title="العمال"><i class="fa fa-file-pdf-o"></i> العمال</a></div>
									</div>
								</div>
							</div>
							<div class="modal-footer"> </div>
						</div>
					</div>
				</div>
				<div class="modal fade bd-example-modal-lg" id="TENRPrintModal" tabindex="-1" role="dialog" aria-labelledby="TENRPrintModal" aria-hidden="true">
					<div class="modal-dialog modal-lg">
						<div class="modal-content">
							<div class="modal-header">
								<h5 class="modal-title" id="exampleModalLongTitle">طباعة محضر الدخول الجماعي</h5>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
							</div>
							<div class="modal-body">
								<div class="container-fluid">
									<div class="row">
										<div class="col-md-4"> <a href="print.php?doc=enexr&rt=1&rnk_id=1" class="btn btn-primary btn-block" target="_blank" title="الأساتذة"><i class="fa fa-file-pdf-o"></i> الأساتذة</a></div>
										<div class="col-md-4"> <a href="print.php?doc=enexr&rt=1&rnk_id=2" class="btn btn-primary btn-block" target="_blank" title="الإداريون"><i class="fa fa-file-pdf-o"></i> الإداريون</a></div>
										<div class="col-md-4"> <a href="print.php?doc=enexr&rt=1&rnk_id=3" class="btn btn-primary btn-block" target="_blank" title="العمال"><i class="fa fa-file-pdf-o"></i> العمال</a></div>
									</div>
								</div>
							</div>
							<div class="modal-footer"> </div>
						</div>
					</div>
				</div>
				<div class="modal fade bd-example-modal-lg" id="TEXRPrintModal" tabindex="-1" role="dialog" aria-labelledby="TEXRPrintModal" aria-hidden="true">
					<div class="modal-dialog modal-lg">
						<div class="modal-content">
							<div class="modal-header">
								<h5 class="modal-title" id="exampleModalLongTitle">طباعة محضر الخروج الجماعي</h5>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
							</div>
							<div class="modal-body">
								<div class="container-fluid">
									<div class="row">
										<div class="col-md-4"> <a href="print.php?doc=enexr&rt=2&rnk_id=1" class="btn btn-primary btn-block" target="_blank" title="الأساتذة"><i class="fa fa-file-pdf-o"></i> الأساتذة</a></div>
										<div class="col-md-4"> <a href="print.php?doc=enexr&rt=2&rnk_id=2" class="btn btn-primary btn-block" target="_blank" title="الإداريون"><i class="fa fa-file-pdf-o"></i> الإداريون</a></div>
										<div class="col-md-4"> <a href="print.php?doc=enexr&rt=2&rnk_id=3" class="btn btn-primary btn-block" target="_blank" title="العمال"><i class="fa fa-file-pdf-o"></i> العمال</a></div>
									</div>
								</div>
							</div>
							<div class="modal-footer"> </div>
						</div>
					</div>
				</div>
				<div class="modal fade bd-example-modal-lg" id="FormPrintModal" tabindex="-1" role="dialog" aria-labelledby="FormPrintModal" aria-hidden="true">
					<div class="modal-dialog modal-lg">
						<div class="modal-content">
							<div class="modal-header">
								<h5 class="modal-title" id="exampleModalLongTitle">طباعة استمارات المعلومات</h5>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
							</div>
							<div class="modal-body">
								<div class="container-fluid">
									<div class="row">
										<div class="col-md-3"> <a href="print.php?doc=form" class="btn btn-primary btn-block" target="_blank" title="جميع المستخدمين"><i class="fa fa-file-pdf-o"></i> جميع المستخدمين</a></div>
										<div class="col-md-3"> <a href="print.php?doc=form&rnk_id=1" class="btn btn-primary btn-block" target="_blank" title="الأساتذة"><i class="fa fa-file-pdf-o"></i> الأساتذة</a></div>
										<div class="col-md-3"> <a href="print.php?doc=form&rnk_id=2" class="btn btn-primary btn-block" target="_blank" title="الإداريون"><i class="fa fa-file-pdf-o"></i> الإداريون</a></div>
										<div class="col-md-3"> <a href="print.php?doc=form&rnk_id=1" class="btn btn-primary btn-block" target="_blank" title="العمال"><i class="fa fa-file-pdf-o"></i> العمال</a></div>
									</div>
								</div>
							</div>
							<div class="modal-footer"> </div>
						</div>
					</div>
				</div>
				<div class="modal fade bd-example-modal-lg" id="CertificatePrintModal" tabindex="-1" role="dialog" aria-labelledby="CertificatePrintModal" aria-hidden="true">
					<div class="modal-dialog modal-lg">
						<div class="modal-content">
							<div class="modal-header">
								<h5 class="modal-title" id="exampleModalLongTitle">طباعة شهادات العمل</h5>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
							</div>
							<div class="modal-body">
								<div class="container-fluid">
									<div class="row">
										<div class="col-md-3"> <a href="print.php?doc=certificate" class="btn btn-primary btn-block" target="_blank" title="جميع المستخدمين"><i class="fa fa-file-pdf-o"></i> جميع المستخدمين</a></div>
										<div class="col-md-3"> <a href="print.php?doc=certificate&rnk_id=1" class="btn btn-primary btn-block" target="_blank" title="الأساتذة"><i class="fa fa-file-pdf-o"></i> الأساتذة</a></div>
										<div class="col-md-3"> <a href="print.php?doc=certificate&rnk_id=2" class="btn btn-primary btn-block" target="_blank" title="الإداريون"><i class="fa fa-file-pdf-o"></i> الإداريون</a></div>
										<div class="col-md-3"> <a href="print.php?doc=certificate&rnk_id=3" class="btn btn-primary btn-block" target="_blank" title="العمال"><i class="fa fa-file-pdf-o"></i> العمال</a></div>
									</div>
								</div>
							</div>
							<div class="modal-footer"> </div>
						</div>
					</div>
				</div>
				<div class="modal fade bd-example-modal-lg" id="WRSPrintModal" tabindex="-1" role="dialog" aria-labelledby="WRSPrintModal" aria-hidden="true">
					<div class="modal-dialog modal-lg">
						<div class="modal-content">
							<div class="modal-header">
								<h5 class="modal-title" id="exampleModalLongTitle">طباعة بيانات استئناف العمل</h5>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
							</div>
							<div class="modal-body">
								<div class="container-fluid">
									<div class="row">
										<div class="col-md-3"> <a href="print.php?doc=wrs" class="btn btn-primary btn-block" target="_blank" title="جميع المستخدمين"><i class="fa fa-file-pdf-o"></i> جميع المستخدمين</a></div>
										<div class="col-md-3"> <a href="print.php?doc=wrs&rnk_id=1" class="btn btn-primary btn-block" target="_blank" title="الأساتذة"><i class="fa fa-file-pdf-o"></i> الأساتذة</a></div>
										<div class="col-md-3"> <a href="print.php?doc=wrs&rnk_id=2" class="btn btn-primary btn-block" target="_blank" title="الإداريون"><i class="fa fa-file-pdf-o"></i> الإداريون</a></div>
										<div class="col-md-3"> <a href="print.php?doc=wrs&rnk_id=3" class="btn btn-primary btn-block" target="_blank" title="العمال"><i class="fa fa-file-pdf-o"></i> العمال</a></div>
									</div>
								</div>
							</div>
							<div class="modal-footer"> </div>
						</div>
					</div>
				</div>
				<div class="modal fade bd-example-modal-lg" id="NRPrintModal" tabindex="-1" role="dialog" aria-labelledby="NRPrintModal" aria-hidden="true">
					<div class="modal-dialog modal-lg">
						<div class="modal-content">
							<div class="modal-header">
								<h5 class="modal-title" id="exampleModalLongTitle">طباعة محاضر التنصيب</h5>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
							</div>
							<div class="modal-body">
								<div class="container-fluid">
									<div class="row">
										<div class="col-md-3"> <a href="print.php?doc=nr" class="btn btn-primary btn-block" target="_blank" title="جميع المستخدمين"><i class="fa fa-file-pdf-o"></i> جميع المستخدمين</a></div>
										<div class="col-md-3"> <a href="print.php?doc=nr&rnk_id=1" class="btn btn-primary btn-block" target="_blank" title="الأساتذة"><i class="fa fa-file-pdf-o"></i> الأساتذة</a></div>
										<div class="col-md-3"> <a href="print.php?doc=nr&rnk_id=2" class="btn btn-primary btn-block" target="_blank" title="الإداريون"><i class="fa fa-file-pdf-o"></i> الإداريون</a></div>
										<div class="col-md-3"> <a href="print.php?doc=nr&rnk_id=3" class="btn btn-primary btn-block" target="_blank" title="العمال"><i class="fa fa-file-pdf-o"></i> العمال</a></div>
									</div>
								</div>
							</div>
							<div class="modal-footer"> </div>
						</div>
					</div>
				</div>
				<div class="modal fade bd-example-modal-lg" id="TSPrintModal" tabindex="-1" role="dialog" aria-labelledby="TSPrintModal" aria-hidden="true">
					<div class="modal-dialog modal-lg">
						<div class="modal-content">
							<div class="modal-header">
								<h5 class="modal-title" id="exampleModalLongTitle">طباعة مجمل الخدمات</h5>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
							</div>
							<div class="modal-body">
								<div class="container-fluid">
									<div class="row">
										<div class="col-md-3"> <a href="print.php?doc=ts" class="btn btn-primary btn-block" target="_blank" title="جميع المستخدمين"><i class="fa fa-file-pdf-o"></i> جميع المستخدمين</a></div>
										<div class="col-md-3"> <a href="print.php?doc=ts&rnk_id=1" class="btn btn-primary btn-block" target="_blank" title="الأساتذة"><i class="fa fa-file-pdf-o"></i> الأساتذة</a></div>
										<div class="col-md-3"> <a href="print.php?doc=ts&rnk_id=2" class="btn btn-primary btn-block" target="_blank" title="الإداريون"><i class="fa fa-file-pdf-o"></i> الإداريون</a></div>
										<div class="col-md-3"> <a href="print.php?doc=ts&rnk_id=3" class="btn btn-primary btn-block" target="_blank" title="العمال"><i class="fa fa-file-pdf-o"></i> العمال</a></div>
									</div>
								</div>
							</div>
							<div class="modal-footer"> </div>
						</div>
					</div>
				</div>
				<div class="modal fade" id="ImportModal" tabindex="-1" role="dialog" aria-labelledby="ImportModal" aria-hidden="true">
					<div class="modal-dialog" role="document">
						<div class="modal-content">
							<div class="modal-header">
								<h5 class="modal-title" id="ImportModal">استيراد المستخدمين من ملف إكسل</h5>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
							</div>
							<div class="modal-body">
								<form id="mImport-form">
									<input type="hidden" name="act" class="form-control" id="act" value="uImport" title="">
									<div class="form-group">
										<label class="btn btn-success btn-block"> <i class="fa fa-upload"></i> <span id="uInputFile">ملف قائمة المستخدمين إكسل</span>
											<input type="file" id="inputFile01" name="uList" hidden> </label>
										<div class="progress progress-bar-striped active">
											<div class="progress-bar" style="width:0%"></div>
										</div>
									</div>
									<div class="form-group">
										<button type="submit" value="submit" class="btn btn-danger btn-block btn-import"> <i class="fa fa-step-backward"></i> استيراد </button>
									</div>
									<div class="modal-footer"> </div>
								</form>
							</div>
						</div>
					</div>
				</div>
				<?php include_once DIR_MODS . '/includes/footer.inc.php'; ?>
					<script>
					$('#inputFile01').on('change', function() {
						var fileName = event.target.files[0].name;
						$('#uInputFile').html(fileName);
					});
					var counter = 0;

					function addMoreFields(f) {
						counter++;
						var newFields = document.getElementById('readroot_' + f).cloneNode(true);
						newFields.id = '';
						newFields.style.display = '';
						var newField = newFields.getElementsByTagName("*");
						for(var i = 0; i < newField.length; i++) {
							var theName = newField[i].name
							if(theName) newField[i].name = theName + '_' + counter;
						}
						var insertHere = document.getElementById('writeroot_' + f);
						insertHere.parentNode.insertBefore(newFields, insertHere);
						$(document).ready(function() {
							$('.datepicker').datepicker({
								todayHighlight: true,
								todayBtn: "linked",
								language: "ar",
								autoclose: true,
								clearBtn: true,
								calendarWeeks: true,
								format: 'yyyy-mm-dd'
							});
						});
					}
					for(var i = 0; i < 3; i++) $('#moreFields1').trigger('click');
					for(var i = 0; i < 3; i++) $('#moreFields2').trigger('click');
					$(document).ready(function() {
						$('.datepicker').datepicker({
							todayHighlight: true,
							todayBtn: "linked",
							language: "ar",
							autoclose: true,
							clearBtn: true,
							calendarWeeks: true,
							format: 'yyyy-mm-dd'
						});
						var table = $('#show').DataTable({
							"responsive": true,
							"pageLength": 5,
							"bLengthChange": false,
							"info": false,
							"aoColumns": [
								null,
								null,
								null,
								null, {
									"sClass": "rank"
								}, {
									"sClass": "mat"
								},
								null,
								null, {
									"sClass": "ops"
								},
							],
							"order": [
								[4, 'asc']
							],
							ajax: {
								url: "server.php",
								data: {
									'act': 'show',
								},
								dataType: "json",
								method: "POST"
							}
						});
						$.validator.setDefaults({
							highlight: function(element) {
								$(element).addClass('is-invalid').removeClass('is-valid');
							},
							unhighlight: function(element) {
								$(element).removeClass('is-invalid').addClass('is-valid');
							},
							errorElement: 'div ',
							errorClass: 'invalid-feedback',
							errorPlacement: function(error, element) {
								if(element.parent('.input-group').length) {
									error.insertAfter(element.parent());
								} else if($(element).is('.select')) {
									element.next().after(error);
								} else if(element.hasClass('select2')) {
									//error.insertAfter(element);
									error.insertAfter(element.next());
								} else if(element.hasClass('selectpicker')) {
									error.insertAfter(element.next());
								} else {
									error.insertAfter(element);
								}
							},
							submitHandler: function(form) {
								var data = $("#aeUserForm").serialize();
								$.ajax({
									type: 'POST',
									url: 'server.php',
									data: data,
									beforeSend: function() {
										$("#aeUserForm-msg").fadeOut();
										$("#aeUserForm-btn").html('<i class="fa fa-spinner fa-spin"></i>');
									},
									success: function(response) {
										if(response == "1") {
											$("#aeUserForm-msg").fadeIn(1000, function() {
												$("#aeUserForm-msg").html('<div class="alert alert-success">تمّ حفظ البيانات بنجاح..</div>');
											});
											setTimeout(' window.location.href = "index.php?page=users"; ', 2000);
										} else {
											$("#aeUserForm-msg").fadeIn(1000, function() {
												$("#aeUserForm-msg").html('<div class="alert alert-danger">' + response + ' </div>');
												$("#aeUserForm-btn").html('حفظ المعلومات');
											});
										}
									}
								});
								$('#show').DataTable().ajax.reload().draw(false);
								return false;
							}
						});
						$('#aeUserForm').validate();
					});
					$('#ImportModal').on('shown.bs.modal', function() {
						$.ajax({
							url: "server.php",
							data: {
								act: 'amattiImportUsersForm',
							},
							type: "POST",
							beforeSend: function() {
								$("#amattiImportUsersForm").html('<h1 class="text-center"><i class="fa fa-spinner fa-spin"></i></h1>');
							},
							success: function(data) {
								$("#amattiImportUsersForm").html(data);
							}
						});
					})

					function sendToServer(act, id) {
						swal({
							title: 'هل أنت متأكد من حذف المستخدم؟',
							text: "لن تتمكن من التراجع عن هذا!",
							type: 'warning',
							showCancelButton: true,
							confirmButtonColor: '#3085d6',
							cancelButtonColor: '#d33',
							cancelButtonText: 'تراجع',
							confirmButtonText: 'نعم، احذف!'
						}).then((result) => {
							if(result.value) {
								$.post("server.php", {
									act: act,
									id: id,
								}, (data, status) => {
									if(data === "1") {
										swal({
											type: 'success',
											title: 'تمت عملية الحذف بنجاح',
											showConfirmButton: false,
											timer: 1500
										})
									} else {
										swal({
											type: 'error',
											title: 'حدث خطأ ما :(',
											showConfirmButton: false,
											timer: 1500
										})
									}
									$('#show').DataTable().ajax.reload().draw(false);
								});
							}
						})
					}

					function deleteUsers() {
						swal({
							title: 'هل أنت متأكد من مسح جميع البيانات',
							text: "لن تتمكن من التراجع عن هذا!",
							type: 'warning',
							showCancelButton: true,
							confirmButtonColor: '#3085d6',
							cancelButtonColor: '#d33',
							cancelButtonText: 'تراجع',
							confirmButtonText: 'نعم، امسح!'
						}).then((result) => {
							if(result.value) {
								$.post("server.php", {
									act: 'deleteUsers',
								}, (data, status) => {
									if(data === "1") {
										swal({
											type: 'success',
											title: 'تمّت عملية المسح بنجاح',
											showConfirmButton: false,
											timer: 1500
										})
									} else {
										swal({
											type: 'error',
											title: 'حدث خطأ ما :(',
											showConfirmButton: false,
											timer: 1500
										})
									}
									$('#show').DataTable().ajax.reload().draw(false);
								});
							}
						})
					}

					function exportXLS() {
						$.ajax({
							type: 'POST',
							url: 'server.php',
							data: 'act=export',
							success: function(response) {
								setTimeout(' window.location.href = "users.xls"; ', 2000);
							}
						});
					}

					function UserModal(id = 0) {
						$.ajax({
							type: 'POST',
							url: 'server.php',
							data: 'act=utoedit&id=' + id + '',
							success: function(response) {
								if(response) {
									var re = JSON.parse(response);
									if(re['ts_form'] > 0) {
										for(var i = 0; i < re['ts_form']; i++) $('#moreFields1').trigger('click');
									}
									if(re['q_form'] > 0) {
										for(var i = 0; i < re['q_form']; i++) $('#moreFields2').trigger('click');
									}
									for(var key in re) {
										$("#aeUserForm [name=" + key + "").val(re[key]);
									}
								};
							}
						});
						document.getElementById("act").setAttribute("value", "edit");
					}

					function PrintModal(id = 0) {
						document.getElementById("form").setAttribute("href", "print.php?doc=form&id=" + id);
						document.getElementById("certificate").setAttribute("href", "print.php?doc=certificate&id=" + id);
						document.getElementById("wrs").setAttribute("href", "print.php?doc=wrs&id=" + id);
						document.getElementById("nr").setAttribute("href", "print.php?doc=nr&id=" + id);
						document.getElementById("ts").setAttribute("href", "print.php?doc=ts&id=" + id);
					}
					$('#UserModal').on('hidden.bs.modal', function() {
						$('#aeUserForm')[0].reset();
						document.getElementById("act").setAttribute("value", "add");
					});

					function bdate() {
						if(document.getElementById("birth_date2").value !== "") {
							document.getElementById('birth_date').value = "";
							document.getElementById('birth_date').disabled = true;
						} else {
							document.getElementById('birth_date').disabled = false;
						}
					}

					function admFD() {
						if(document.getElementById("administrative_status").value == "مرسم(ة)") {
							document.getElementById('fixing_date').disabled = false;
						} else {
							document.getElementById('fixing_date').value = "";
							document.getElementById('fixing_date').disabled = true;
						}
					}
					</script>
					<script src="<?php echo HOME_URL . '/assets/js/jquery.dataTables.min.js'; ?>"></script>
					<script src="<?php echo HOME_URL . '/assets/js/dataTables.bootstrap4.min.js '; ?>"></script>
					<script src="<?php echo HOME_URL . '/assets/js/bootstrap.min.js'; ?>"></script>
					<script src="<?php echo HOME_URL . '/assets/js/datepicker/bootstrap-datepicker.min.js'; ?>"></script>
					<script src="<?php echo HOME_URL . '/assets/js/datepicker/bootstrap-datepicker.ar.min.js'; ?>"></script>
					<script src="<?php echo HOME_URL . '/assets/js/jquery-validation/jquery.validate.min.js'; ?>"></script>
					<script src="<?php echo HOME_URL . '/assets/js/jquery-validation/localization/messages_ar.js'; ?>"></script>
	</body>

	</html>