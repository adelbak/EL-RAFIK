<?php

trait upload
{

	public function uploadFile($file, $new_upload_folder, $allowed_file_size = 1000000, $allowed_mime_types = array()) {
	$uploaded_file = array();
	try {
		if (!isset($file['error']) || is_array($file['error'])) {
	        throw new RuntimeException('Invalid parameters.');
	    }
	    switch ($file['error']) {
	        case UPLOAD_ERR_OK:
	            break;
	        case UPLOAD_ERR_NO_FILE:
	            throw new RuntimeException('يرجى اختيار الملف.');
	        case UPLOAD_ERR_INI_SIZE:
	        case UPLOAD_ERR_FORM_SIZE:
	            throw new RuntimeException('حجم الملف تجاوز المسموح.');
	        default:
	            throw new RuntimeException('خطأ غير معروف.');
	    }
		// You should also check filesize here.
		if ($file['size'] > $allowed_file_size) {
			throw new RuntimeException('حجم الملف تجاوز المسموح.');
		}
		if(empty($allowed_mime_types)) {
			$allowed_mime_types = array(
		         "ez" => "application/andrew-inset",
		         "hqx" => "application/mac-binhex40",
		         "cpt" => "application/mac-compactpro",
		         "doc" => "application/msword",
		         "bin" => "application/octet-stream",
		         "dms" => "application/octet-stream",
		         "lha" => "application/octet-stream",
		         "lzh" => "application/octet-stream",
		         "exe" => "application/octet-stream",
		         "class" => "application/octet-stream",
		         "so" => "application/octet-stream",
		         "dll" => "application/octet-stream",
		         "oda" => "application/oda",
		         "pdf" => "application/pdf",
		         "ai" => "application/postscript",
		         "eps" => "application/postscript",
		         "ps" => "application/postscript",
		         "smi" => "application/smil",
		         "smil" => "application/smil",
		         "wbxml" => "application/vnd.wap.wbxml",
		         "wmlc" => "application/vnd.wap.wmlc",
		         "wmlsc" => "application/vnd.wap.wmlscriptc",
		         "bcpio" => "application/x-bcpio",
		         "vcd" => "application/x-cdlink",
		         "pgn" => "application/x-chess-pgn",
		         "cpio" => "application/x-cpio",
		         "csh" => "application/x-csh",
		         "dcr" => "application/x-director",
		         "dir" => "application/x-director",
		         "dxr" => "application/x-director",
		         "dvi" => "application/x-dvi",
		         "spl" => "application/x-futuresplash",
		         "gtar" => "application/x-gtar",
		         "hdf" => "application/x-hdf",
		         "js" => "application/x-javascript",
		         "skp" => "application/x-koan",
		         "skd" => "application/x-koan",
		         "skt" => "application/x-koan",
		         "skm" => "application/x-koan",
		         "latex" => "application/x-latex",
		         "nc" => "application/x-netcdf",
		         "cdf" => "application/x-netcdf",
		         "sh" => "application/x-sh",
		         "shar" => "application/x-shar",
		         "swf" => "application/x-shockwave-flash",
		         "sit" => "application/x-stuffit",
		         "sv4cpio" => "application/x-sv4cpio",
		         "sv4crc" => "application/x-sv4crc",
		         "tar" => "application/x-tar",
		         "tcl" => "application/x-tcl",
		         "tex" => "application/x-tex",
		         "texinfo" => "application/x-texinfo",
		         "texi" => "application/x-texinfo",
		         "t" => "application/x-troff",
		         "tr" => "application/x-troff",
		         "roff" => "application/x-troff",
		         "man" => "application/x-troff-man",
		         "me" => "application/x-troff-me",
		         "ms" => "application/x-troff-ms",
		         "ustar" => "application/x-ustar",
		         "src" => "application/x-wais-source",
		         "xhtml" => "application/xhtml+xml",
		         "xht" => "application/xhtml+xml",
		         "zip" => "application/zip",
		         "au" => "audio/basic",
		         "snd" => "audio/basic",
		         "mid" => "audio/midi",
		         "midi" => "audio/midi",
		         "kar" => "audio/midi",
		         "mpga" => "audio/mpeg",
		         "mp2" => "audio/mpeg",
		         "mp3" => "audio/mpeg",
		         "aif" => "audio/x-aiff",
		         "aiff" => "audio/x-aiff",
		         "aifc" => "audio/x-aiff",
		         "m3u" => "audio/x-mpegurl",
		         "ram" => "audio/x-pn-realaudio",
		         "rm" => "audio/x-pn-realaudio",
		         "rpm" => "audio/x-pn-realaudio-plugin",
		         "ra" => "audio/x-realaudio",
		         "wav" => "audio/x-wav",
		         "pdb" => "chemical/x-pdb",
		         "xyz" => "chemical/x-xyz",
		         "bmp" => "image/bmp",
		         "gif" => "image/gif",
		         "ief" => "image/ief",
		         "jpeg" => "image/jpeg",
		         "jpg" => "image/jpeg",
		         "jpe" => "image/jpeg",
		         "png" => "image/png",
		         "tiff" => "image/tiff",
		         "tif" => "image/tif",
		         "djvu" => "image/vnd.djvu",
		         "djv" => "image/vnd.djvu",
		         "wbmp" => "image/vnd.wap.wbmp",
		         "ras" => "image/x-cmu-raster",
		         "pnm" => "image/x-portable-anymap",
		         "pbm" => "image/x-portable-bitmap",
		         "pgm" => "image/x-portable-graymap",
		         "ppm" => "image/x-portable-pixmap",
		         "rgb" => "image/x-rgb",
		         "xbm" => "image/x-xbitmap",
		         "xpm" => "image/x-xpixmap",
		         "xwd" => "image/x-windowdump",
		         "igs" => "model/iges",
		         "iges" => "model/iges",
		         "msh" => "model/mesh",
		         "mesh" => "model/mesh",
		         "silo" => "model/mesh",
		         "wrl" => "model/vrml",
		         "vrml" => "model/vrml",
		         "css" => "text/css",
		         "html" => "text/html",
		         "htm" => "text/html",
		         "asc" => "text/plain",
		         "txt" => "text/plain",
		         "rtx" => "text/richtext",
		         "rtf" => "text/rtf",
		         "sgml" => "text/sgml",
		         "sgm" => "text/sgml",
		         "tsv" => "text/tab-seperated-values",
		         "wml" => "text/vnd.wap.wml",
		         "wmls" => "text/vnd.wap.wmlscript",
		         "etx" => "text/x-setext",
		         "xml" => "text/xml",
		         "xsl" => "text/xml",
		         "mpeg" => "video/mpeg",
		         "mpg" => "video/mpeg",
		         "mpe" => "video/mpeg",
		         "qt" => "video/quicktime",
		         "mov" => "video/quicktime",
		         "mxu" => "video/vnd.mpegurl",
		         "avi" => "video/x-msvideo",
		         "movie" => "video/x-sgi-movie",
		         "ice" => "x-conference-xcooltalk",
		         "xls" => "application/vnd.ms-excel",
		         "xlsx" => "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
		      ); 
		}
		// DO NOT TRUST $_FILES['xxx']['mime'] VALUE !!
	    // Check MIME Type by yourself.
		$file_parts = pathinfo($file['name']);
		$ext = $file_parts['extension'];

		if (!in_array($ext, $allowed_mime_types)){
    		die('نوع الملف خاطئ.');
		}
	
	    // You should name it uniquely.
	    // DO NOT USE $_FILES['xxx']['name'] WITHOUT ANY VALIDATION !!
	    // On this example, obtain safe unique name from its binary data.
	    if (!move_uploaded_file(
	        $file['tmp_name'],
	        sprintf('%s%s.%s',
	        	$new_upload_folder,
	            md5($file['tmp_name']),
	            $ext
	        )
	    )) {
	        throw new RuntimeException('فشلت عملية رفع الملف.');
	    }
		
        $uploaded_file['result'] = true;
        $uploaded_file['file_path'] = $new_upload_folder.md5($file['tmp_name']).'.'.$ext;

	    return $uploaded_file;
		
	} catch (RuntimeException $e) {
	
        $uploaded_file['result'] = false;	
		$uploaded_file['err'] = $e->getMessage();
		
		 return $uploaded_file;

		//return false;
	}
  }
}
?>