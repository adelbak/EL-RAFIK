<?php

trait CEM
{

	public function CEM_Upl_Gen_lists($_GL_File, $_GL_POST)
	{
	
		$new_upload_folder = DIR_UPLOADS .'/';
		$allowed_file_size = 900000;
		$allowed_mime_types = array(
			"xls",
			"html",
		);
		
		$_POST = $this->sanitize($_GL_POST);

		$file = $_GL_File;
		$educ_ins_name =  $_POST['educ_ins_name'];
		$annee_school =  $_POST['annee_school'];

		$uploaded = $this->uploadFile($file, $new_upload_folder, $allowed_file_size, $allowed_mime_types);
  
		if ($uploaded['result']) {

        	$this->gen_lists($uploaded['file_path'], $educ_ins_name, $annee_school);

	    }else {
		    echo $uploaded['err'];
		}

    }		
	
	public function CEM_Upl_Pre_Send_list($L_File)
	{
		
		// Upload Ver
		$new_upload_folder = DIR_UPLOADS .'/';
		$allowed_file_size = 900000;
		$allowed_mime_types = array(
			"xls",
	        "xlsx",		
			"html"
		);

		// Send Ver
       $Login_URL = 'https://amatti.education.gov.dz/login/verif_login';
        $User_Agent = 'Mozilla/5.0 (X11; Linux i686; rv:24.0) Gecko/20140319 Firefox/24.0 Iceweasel/24.4.0';
        $Insert_URL = 'https://amatti.education.gov.dz/scolarite/bulletin/bulletin/table_sasie';
		
		$file = $L_File;

		$uploaded = $this->uploadFile($file, $new_upload_folder, $allowed_file_size, $allowed_mime_types);
  
		if ($uploaded['result']) {

		    $prepares_data = $this->prepare_data($uploaded['file_path']);

        	if ($prepares_data['result']) {
			
			    $sended = $this->send_data($Login_URL, $User_Agent, $this->get_iap($_SESSION['iap'], 'KV'), $_SESSION['amatti_username'], $this->Decrypt($_SESSION['amatti_password'], CKEY), $Insert_URL, $prepares_data['parameters']);
				
            }
			
	    }else {
		    echo $uploaded['err'];
		}

    }	

	/*public function get_educ_institution($value, $method = 'VK')
	{
	    $educ_institution_array = Array(
            '1' => 'ابتدائية',
            '2' => 'متوسطة',
            '3' => 'ثانوية'
		);
		
        if ($method === 'VK')
        {		

        	return isset($educ_institution_array[$value]) ? $educ_institution_array[$value] : false;			
			
		}
        elseif ($method === 'KV')
        {				
		    return array_search ($value, $educ_institution_array);

		}else	
		{
		    return False;
		}	
	}*/	
			
	public function get_division($value, $method = 'VK')
	{
	    $dev_array = Array(
            '2100001' =>'1م1',
            '2100002' =>'1م2',
            '2100003' =>'1م3',
            '2100004' =>'1م4',
            '2100005' =>'1م5',
            '2100006' =>'1م6',
            '2100007' =>'1م7',
            '2100008' =>'1م8',
            '2100009' =>'1م9',
            '2200001' =>'2م1',
            '2200002' =>'2م2',
            '2200003' =>'2م3',
            '2200004' =>'2م4',
            '2200005' =>'2م5',
            '2200006' =>'2م6',
            '2200007' =>'2م7',
            '2200008' =>'2م8',
            '2200009' =>'2م9',				
            '2300001' =>'3م1',
            '2300002' =>'3م2',
            '2300003' =>'3م3',
            '2300004' =>'3م4',
            '2300005' =>'3م5',
            '2300006' =>'3م6',
            '2300007' =>'3م7',
            '2300008' =>'3م8',
            '2300009' =>'3م9',				
            '2400001' =>'4م1',
            '2400002' =>'4م2',
            '2400003' =>'4م3',
            '2400004' =>'4م4',
            '2400005' =>'4م5',
            '2400006' =>'4م6',
            '2400007' =>'4م7',
            '2400008' =>'4م8',
            '2400009' =>'4م9'
		);
		
        if ($method === 'VK')
        {
	
        	return isset($dev_array[$value]) ? $dev_array[$value] : false;			

		}
        elseif ($method === 'KV')
        {
            return array_search ($value, $dev_array);

		}else	
		{
		    return False;
		}	
	}
	
	/*
	public function translate_division($value)
	{
		$ar_level   = array("1م", "2م", "3م", "4م");
		$fr_level   = array("1am", "2am", "3am", "4am");

		return str_replace($ar_level, $fr_level, $value);
	}
	*/
	
	public function get_matiere($value, $method = 'VK')
	{
	    $mat_array = Array(
            '1' => 'اللغة العربية',
            '2' => 'اللغة اﻷمازيغية',
            '3' => 'اللغة الفرنسية',
            '4' => 'اللغة الإنجليزية',
            '5' => 'التربية الإسلامية',
            '6' => 'التربية المدنية',
            '7' => 'التاريخ والجغرافيا',
            '9' => 'الرياضيات',
            '10' => 'ع الطبيعة و الحياة',
            '11' => 'ع الفيزيائية والتكنولوجيا',
            '12' => 'المعلوماتية',
            '13' => 'التربية التشكيلية',
            '14' => 'التربية الموسيقية',	  
            '15' => 'ت البدنية و الرياضية'	
		);
		
        if ($method === 'VK')
        {		
        	return isset($mat_array[$value]) ? $mat_array[$value] : false;			
			
		}
        elseif ($method === 'KV')
        {				
		    return array_search ($value, $mat_array);
			
		}else	
		{
		    return False;
		}	
	}
	
/*	public function translate_matiere($value)
	{
	    $mat_array = Array(
            'اللغة العربية' => 'Arabe',
            'اللغة اﻷمازيغية' => 'Tamazight',
            'اللغة الفرنسية' => 'Francais',
            'اللغة الانجليزية' => 'Anglais',
            'التربية الاسلامية' => 'Education Islamique',
            'التربية المدنية' => 'Education Civique',
            'الاجتماعيات' => 'Histoire et Geographie',
            'الرياضيات' => 'Mathematiques',
            'العلوم الطبيعية وح' => 'Sciences Naturelles',
            'العلوم الفيزيائية وتك' => 'Physique',
            'المعلوماتية' => 'Informatique',
            'التربية التشكيلية' => 'Education Artistique',
            'التربية الموسيقية' => 'Education Musicale',	  
            'ت البدنية و الرياضية' => 'Education Physique'	
		);
	
        return isset($mat_array[$value]) ? $mat_array[$value] : false;			

	}
*/	
	public function get_annee_school($value, $method = 'VK')
	{
	    $annee_school_array = Array(
            '20181' => 'الفصل الأول 2019-2018',
            '20182' => 'الفصل الثاني 2019-2018',
            '20183' => 'الفصل الثالث 2019-2018',
		);
		
        if ($method === 'VK')
        {		
        	return isset($annee_school_array[$value]) ? $annee_school_array[$value] : false;			
			
		}
        elseif ($method === 'KV')
        {				
		    return array_search ($value, $annee_school_array);
			
		}else	
		{
		    return False;
		}	
	}
	
	public function get_iap($value, $method = 'VK')
	{
	   $iap_array = Array(
            '01021' =>'مديرية التربية لولاية أدرار',
            '02041' =>'مديرية التربية لولاية الشلف',
            '03021' =>'مديرية التربية لولاية الأغواط',
            '04041' =>'مديرية التربية لولاية أم البواقي',
            '05051' =>'مديرية التربية لولاية باتنة',
            '06051' =>'مديرية التربية لولاية بجاية',
            '07031' =>'مديرية التربية لولاية بسكرة',
            '08021' =>'مديرية التربية لولاية بشار',
            '09051' =>'مديرية التربية لولاية البليدة',
            '10041' =>'مديرية التربية لولاية البويرة',
            '11011' =>'مديرية التربية لولاية تمنراست',
            '12031' =>'مديرية التربية لولاية تبسة',
            '13041' =>'مديرية التربية لولاية تلمسان',
            '14041' =>'مديرية التربية لولاية تيارت',
            '15051' =>'مديرية التربية لولاية تيزي وزو',
            '16051' =>'مديرية التربية للجزائر غرب',
            '16052' =>'مديرية التربية للجزائر وسط',
            '16053' =>'مديرية التربية للجزائر شرق',
            '16181' =>'وزارة التربية الوطنية',
            '17031' =>'مديرية التربية لولاية الجلفة',
            '18041' =>'مديرية التربية لولاية جيجل',
            '19051' =>'مديرية التربية لولاية سطيف',
            '20031' =>'مديرية التربية لولاية سعيدة',
            '21041' =>'مديرية التربية لولاية سكيكدة',
            '22041' =>'مديرية التربية لولاية سيدي بلعباس',
            '23041' =>'مديرية التربية لولاية عنابة',
            '24031' =>'مديرية التربية لولاية قالمة',
            '25051' =>'مديرية التربية لولاية قسنطينة',
            '26041' =>'مديرية التربية لولاية المدية',
            '27041' =>'مديرية التربية لولاية مستغانم',
            '28041' =>'مديرية التربية لولاية المسيلة',
            '29041' =>'مديرية التربية لولاية معسكر',
            '30031' =>'مديرية التربية لولاية ورقلة',
            '31051' =>'مديرية التربية لولاية وهران',
            '32021' =>'مديرية التربية لولاية البيض',
            '33011' =>'مديرية التربية لولاية إليزي',
            '34041' =>'مديرية التربية لولاية برج بوعريريج',
            '35041' =>'مديرية التربية لولاية بومرداس',
            '36031' =>'مديرية التربية لولاية الطارف',
            '37011' =>'مديرية التربية لولاية تندوف',
            '38021' =>'مديرية التربية لولاية تيسمسيلت',
            '39031' =>'مديرية التربية لولاية الوادي',
            '40031' =>'مديرية التربية لولاية خنشلة',
            '41031' =>'مديرية التربية لولاية سوق أهراس',
            '42041' =>'مديرية التربية لولاية تيبازة',
            '43041' =>'مديرية التربية لولاية ميلة',
            '44041' =>'مديرية التربية لولاية عين الدفلى',
            '45011' =>'مديرية التربية لولاية النعامة',
            '46031' =>'مديرية التربية لولاية عين تيموشنت',
            '47021' =>'مديرية التربية لولاية غرداية',
            '48041' =>'مديرية التربية لولاية غليزان',
		);		
		
        if ($method === 'VK')
        {		

        	return isset($iap_array[$value]) ? $iap_array[$value] : false;			

		}
        elseif ($method === 'KV')
        {				
		    return array_search ($value, $iap_array);			
			
		}else	
		{
		    return false;
		}	
	}
	

	public function prepare_section($level, $section)
	{	
		$old_level   = array("أولى", "ثانية", "ثالثة", "رابعة");
		$new_level   = array("1م", "2م", "3م", "4م");

		return str_replace($old_level, $new_level, $level).$section;
    }

	/* EXEL */
	public function gen_lists($XLS_file, $Educ_ins_name, $annee_school)
	{
		$results = array(); // مصفوفة التلاميذ
  	    $result = array();	// مصفوفة التلاميذ حسب الأقسام
  	    $tmpdir = DIR_TEMP.'/'.$this->GenKey();	//المجلد المؤقت للقوائم
		if (!file_exists($tmpdir)) { mkdir($tmpdir, 0777, true); } // إنشاء المجلد
  	    $zip_filename = $Educ_ins_name.'_'.time().'.zip'; // اسم الملف المضغوط للتحميل	
		$zip_path = DIR_TEMP.'/'.$zip_filename;		
        $school_year = str_replace('/', '-', $_SESSION['school_year']);		
        $i = 6; // الخانة لبدء كتابى القائمة

		// متوسط
		$exel_template = DIR_EXCEL.'/cem.xls';	
		$mat_array = array("اللغة العربية", "اللغة اﻷمازيغية", "اللغة الفرنسية", "اللغة الإنجليزية", "التربية الإسلامية", "التربية المدنية", "التاريخ والجغرافيا", "الرياضيات", "ع الطبيعة و الحياة", "ع الفيزيائية والتكنولوجيا", "المعلوماتية", "التربية التشكيلية", "التربية الموسيقية", "ت البدنية و الرياضية");
		
		
		$tmpfname = $XLS_file;
		$excelReader = PHPExcel_IOFactory::createReaderForFile($tmpfname);
		$excelObj = $excelReader->load($tmpfname);
		$worksheet = $excelObj->getSheet(0);
		$lastRow = $worksheet->getHighestRow();
		
		$excel2 = PHPExcel_IOFactory::createReaderForFile($exel_template);
		$excel2 = $excel2->load($exel_template); // Empty Sheet
		$excel2->setActiveSheetIndex(0);
        $za = new FlxZipArchive;

	
		for ($row = 1; $row <= $lastRow; $row++) {
			
			$identification_number = $worksheet->getCell('A'.$row)->getValue(); // رقم التعريف
			$surname = $worksheet->getCell('B'.$row)->getValue();               // اللقب


			if( $identification_number != "" && is_numeric($identification_number) && $identification_number > 0 && $identification_number == round( $identification_number, 0) && $surname != ""){ // التحقق من أن الخانة خاصة بالتلميذ

			    $name = $worksheet->getCell('C'.$row)->getValue();                  // الاسم
			    $date_of_birth = $worksheet->getCell('E'.$row)->getValue();         // تاريخ الازدياد
			    $registration_number = $worksheet->getCell('N'.$row)->getValue();   // رقم التسجيل
			    $level = $worksheet->getCell('K'.$row)->getValue();                  // السنة
			    $section = $worksheet->getCell('L'.$row)->getValue();               // القسم
			    $level_section = $this->prepare_section($level, $section);
				// إدراج النقاط في مصفوفة
		        $results[] = array($identification_number, $surname, $name, $date_of_birth, $registration_number, $level_section);
			}
			
		}
		
		// ترتيب قائمة التلاميذ ترتيبا أبجديا
		usort($results, function ($a, $b) {
    	    return $a['1'] > $b['1'];
		});
		
		// تقسيم المصفوفة إلى مصفوفات حسب القسم
  	    foreach ($results as $element) {
  	        $result[$element['5']][] = $element;
	        
        }

		
		foreach ($mat_array as $mat) {
		
		//$mat = iconv("UTF-8","Windows-1256//IGNORE",$mat);
			//$fr_name_mat = $this->translate_matiere($mat);

        	if (!file_exists($tmpdir.'/'.$mat)) { mkdir($tmpdir.'/'.$mat, 0777, true); }

            foreach ($result as $key=>$course) {

			//$key = iconv("UTF-8","Windows-1256//IGNORE",$key);

                $excel2->getActiveSheet()->setCellValue('H3', $key) // القسم
                ->setCellValue('N2', $mat) // المادة
                ->setCellValue('A1', $_SESSION['iap'])	
                ->setCellValue('K1', $annee_school)
                ->setCellValue('N1', $school_year)				
                ->setCellValue('A2', $_SESSION['educ_institution_name']);
						

                foreach ($course as $cr) {
                    $excel2->getActiveSheet()->setCellValue('B'.$i, $cr['4'])
                    ->setCellValue('C'.$i, $cr['0'])					
                    ->setCellValue('D'.$i, $cr['1'].' '.$cr['2'])
                    ->setCellValue('E'.$i, $cr['3']);
                    $i++;
                }
				
			//	$fr_name_key = $this->translate_division($key);
				
				$objWriter = PHPExcel_IOFactory::createWriter($excel2, 'Excel2007');
                $objWriter->save($tmpdir.'/'.$mat.'/'.$key.'.xls');
				
                $i=6; // إعادة مؤشر الكتابة إلى ستة
	  
	            // إفراغ النموذج من أجل تعبئته مرة أخرى
	            $n = 6;
                for($n = 6; $n<=60; $n++) {   	    
                    $excel2->getActiveSheet()->setCellValue('B'.$n, "")
                    ->setCellValue('C'.$n, "")
                    ->setCellValue('D'.$n, "")
                    ->setCellValue('E'.$n, "");
                }

             }
        }
		
        $res = $za->open(DIR_DOWNLOADS.'/'.$zip_filename, ZipArchive::CREATE);
        if($res === TRUE)    {
            $za->addDir($tmpdir, basename($tmpdir));
			$za->close();
        }
        else  { die('Could not create a zip archive'); }

		die(HOME_URL.'/downloads/'.$zip_filename);

	}

	public function prepare_data($XLS_file)
	{
		$results = array();
		$parameters = array();
		$Data2Post = "";
		
		$tmpfname = $XLS_file;
		$excelReader = PHPExcel_IOFactory::createReaderForFile($tmpfname);
		$excelObj = $excelReader->load($tmpfname);
		$worksheet = $excelObj->getSheet(0);
		$lastRow = $worksheet->getHighestRow();
		
		$annee_school = $this->get_annee_school($worksheet->getCell('K1')->getValue().' '.$worksheet->getCell('N1')->getValue(), 'KV');   // الفترة
		$division = $this->get_division($worksheet->getCell('H3')->getValue(), 'KV');           // الفوج التربوي
		$matiere = $this->get_matiere($worksheet->getCell('N2')->getValue(), 'KV');             // المادة
		
		if (!$annee_school) {
			die('خانة "الفترة" خالية أو غير صحيحة.');
		}elseif(!$division) {
			die('خانة "الفوج التربوي" خالية أو غير صحيحة.');
		}elseif(!$matiere) {
			die('خانة "المادة" خالية أو غير صحيحة.');			
		}else{
			
		    for ($row = 1; $row <= $lastRow; $row++) {
			
				$Num = $worksheet->getCell('B'.$row)->getValue();                                       // الرقم			
				$Matricule = $worksheet->getCell('C'.$row)->getFormattedValue();                                 // رقم التعريف
				$N_P = $worksheet->getCell('D'.$row)->getValue().' '.$worksheet->getCell('C'.$row)->getValue();   // اللقب والاسم

				if( $Matricule != "" && is_numeric($Matricule) && $Matricule > 0 && $Matricule == round( $Matricule, 0) && $N_P != ""){ // التحقق من أن الخانة خاصة بالتلميذ

				    $Continuous_assessment = $worksheet->getCell('F'.$row)->getValue();    // التقييم المستمر
				    $Test1 = $worksheet->getCell('G'.$row)->getValue();                    // الفرض 1		
				    $Test2 = $worksheet->getCell('H'.$row)->getValue();                    // الفرض 2
				    $Exam = $worksheet->getCell('I'.$row)->getValue();                     // الاختبار

				    $Ratings = $worksheet->getCell('N'.$row)->getCalculatedValue();                  // التقديرات	
					
					// التحقق من أن العلامات تحت 20
                    if ($Continuous_assessment > 20 or $Test1 > 20 or $Test2 > 20 or $Exam > 20) {
			          die('خطا، توجد علامة فوق 20.');
		            }
					
					// إدراج النقاط في مصفوفة
		            $results[] = array($Num, $Matricule, $N_P, $Continuous_assessment, $Test1, $Test2, $Exam, $Ratings);
            	}
			}
			
			// ترتيب قائمة التلاميذ ترتيبا أبجديا
			usort($results, function ($a, $b) {
    		    return $a['2'] > $b['2'];
		    });
			$i=0;

			foreach ($results as $result) {
			
			    $note =  "note[$i]";

			    // توليد قيم الإدخال لإرسالها
			    if($matiere == 1 OR $matiere == 3 OR $matiere == 4 OR $matiere == 9){ // المواد الأساسية
			        $Data2Post .= $note."[matricule]=".$result['1']."&". $note."[01]=".$result['3']."&".$note."[07]=".$result['4']."&".$note."[08]=".$result['5']."&".$note."[09]=".$result['6']."&".$note."[obs]=".$result['7']."&";
			    }else{
			        $Data2Post .= $note."[matricule]=".$result['1']."&". $note."[01]=".$result['3']."&".$note."[08]=".$result['4']."&".$note."[09]=".$result['6']."&".$note."[obs]=".$result['7']."&";				
			    }
                $i++;

			}
					
			$Data2Post .= "annee=".$annee_school."&division=".$division."&matiere=".$matiere."&isAjax=true";

			//die($Data2Post);
			$parameters['result'] = true;
            $parameters['parameters'] = $Data2Post;

  	        return $parameters;
	    }
    }
	
	public function send_data($Login_URL, $User_Agent, $IAP, $Login_User, $Login_Password, $Insert_URL, $Notes) {
		
		$curl_s = curl_init();
		
		curl_setopt($curl_s,CURLOPT_URL,$Login_URL); // https://amatti.education.gov.dz/login/verif_login
		curl_setopt($curl_s,CURLOPT_USERAGENT,$User_Agent); // Mozilla/5.0 (X11; Linux i686; rv:24.0) Gecko/20140319 Firefox/24.0 Iceweasel/24.4.0
		curl_setopt($curl_s,CURLOPT_POST,True);
		curl_setopt($curl_s,CURLOPT_POSTFIELDS,"iap=$IAP&user_name=$Login_User&password=$Login_Password"); //iap=17031&user_name=C17012019&password=19601970
		curl_setopt($curl_s,CURLOPT_RETURNTRANSFER,True);
		curl_setopt($curl_s,CURLOPT_FOLLOWLOCATION,True);
		curl_setopt($curl_s,CURLOPT_COOKIEFILE,"cookie.txt"); //Put the full path of the cookie file if you want it to write on it
		curl_setopt($curl_s,CURLOPT_COOKIEJAR,"cookie.txt"); //Put the full path of the cookie file if you want it to write on it
		curl_setopt($curl_s,CURLOPT_CONNECTTIMEOUT,30);
		curl_setopt($curl_s,CURLOPT_TIMEOUT,30);  
		curl_setopt($curl_s,CURLOPT_SSL_VERIFYPEER,false);  
		
		$exec = curl_exec($curl_s);
		$statusCode = curl_getinfo($curl_s, CURLINFO_HTTP_CODE);
		
		if($statusCode !== 200){
			
			die('موقع الأرضية الرقمية مغلق حاليا أو عليه ضغط، يرجى المحاولة لاحقا');
			
		} elseif (strpos($exec, 'فضاء الأولياء') == false) {
		
			die('فشلت عملية الدخول إلى الموقع، يرجى التأكد من بيانات الدخول إلى موقع الأرضية الرقمية من خلال صفحة الإعدادات');

		}else {
		
			curl_setopt($curl_s, CURLOPT_URL, $Insert_URL); // set url for next request
 		    curl_setopt($curl_s, CURLOPT_POST,True); 
		    curl_setopt($curl_s, CURLOPT_POSTFIELDS, $Notes); // set post data
            curl_setopt($curl_s, CURLOPT_REFERER, $Insert_URL);
		
  		    $exec = curl_exec($curl_s); // make request to buy on the same handle with the current login session

			curl_close($curl_s);
		
		}
		
		if($exec == '0'){
			
			die('لم تنجح العملية، قد تكون القوائم غير متوافقة من حيث عدد التلاميذ أو رقم التعريف لبعض التلاميذ.');
			
		} else {
		
			die('1');

		}

		
	}
	
	public function sendListsForms($n)
	{

        for ($i = 1; $i <= $n; $i++) {	
					echo'  <form name="sform" id="sform" action="#">
							<div class="row">
								<div class="col-md-4">
									<label class="btn btn-primary btn-block">
										 <i class="fa fa-upload"></i> الملف<input class="custom-file-input" type="file" name="list" hidden>
										 <span class="custom-file-control"></span>  										
										</label>
										<label>
											<input type="text" value="submit" name="go" hidden>
										</label>
										</div>
										<div class="col-md-8">
											<div class="progress progress-bar-striped active">
												<div class="progress-bar" style="width:0%"></div>
											</div>
										</div>
								</div>
							</form>
					';		
	    }
	}	
}


?>