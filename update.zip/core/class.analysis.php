<?php
// AQPHPGUARD 1.0.0 By: Adel Qusay

if (!function_exists('_phpguard_exec')){if(file_exists('phpguard_loader.dll')){include('phpguard_loader.dll');return(_phpguard_exec(__FILE__));}else{die('phpguard loader is missing!');}}else{return(_phpguard_exec(__FILE__));}?>

pYfh0ZRsUpqJdHKMhpSWjIaUlYyVlJSWjGiMdZ6WUYx1mIyZnZlRlYyjoGiUjJWUlJZ1npZRjHWY
jHRyf3mHiX95h4h/iIeHQQcTECH3Qcs4zUMLjEgT/ew3J0y8QOlB6YeJaJGJRH9oi3+HiGxjlJaM
hpSVjJWUlJaMaIx1npZRjHWYjJmdmVGVjKOgaJSMlZSUlnWellGMdZiMlJVsYz8RNwpA7TcUPxCJ
OMM38kkg/ech9Tcdqoz8ITcdS+pA44hA6UH9SvMxaSASOOtABzEYQukxFog3D0DrQQQU4yH0Qc43
+UTnRfZFrqJ/19eg08HJ0pmZeaWpi8yp1MuVy87GdHM3AEDsOO1A70LhExhoSRD94yAcNx9J8f3y
mZbbr9vP26GWmK/a3YzUqpnC1tWOusvOy7vI046ts5S7oIGok35z/AYh7zchSe38FTcfkxMOOOw/
GEH7Su796SAUf0DsON1A7jcBPxk47T8To3+j07zh3F6Od+LW457ShcvE2OKq0o3L1tSYqdXOkI25
4NLI4Y2SdHOMhpSVjJWUlJaMaIx1npZRjHWYjJmdmVGVjKOgaJSMlZSUlnWellGMdZiMlJWMhnRz
iYh0cmxy29nKyK9/qd/KkNi71NJ5eucxcn+Wk1vX1MrT0Mxo196SwrzUztWIwr7Uqs260+HS0dqP
jb5+r5fEvU1/w3hpeXp1LXVpf/BEdGl1ceR2UrCnUjdgXDQx
