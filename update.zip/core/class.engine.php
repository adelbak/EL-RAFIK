<?php
/*
-----------------------------------------------
            سكربت المدير الرقمي            
-----------------------------------------------
برمجة وتطوير: عادل قصي
البريد الإلكتروني: adelbak2014@gmail.com
الموقع الرسمي: www.cem11.com
الصفحة الرسمية للمبرمج: https://www.facebook.com/adel.qusay.9
-----------------------------------------------
السكربت مجاني، يرجى طلب الإذن عند الرغبة في
التطوير.
-----------------------------------------------
*/

class engine
{	
	use upload, CEM;	
	private $db;

	function __construct($db)
	{
        session_start(); // بداية الجلسة		
		$this->db = $db;
		
	}
	
	public function Login($_LoginPOST)
	{

		$_POST = $this->sanitize($_LoginPOST);

	    if(!$_POST['password'])
		{
			die( 'يرجى إدخال كلمة السر!');
		}
		
		else
		{
			$u = $this->db->get_row("SELECT * FROM settings WHERE password = '".md5($_POST['password'])."'", true);
			if($u) {
			
    			$_SESSION = $u;	
	
	            die('1');
				
			} else {
				
			    die( 'كلمة السر غير صحيحة!');

			}	
		}
		exit;
    }		
	
	public function getUsers()
	{
			$outputjsonarray = array();
            $users = $this->db->get_rows ("SELECT * FROM users", true);

            if($this->db->num_rows() > 0) {

    			foreach ($users as $c) {

                    $id = $c['id'];
                    $func_id = $c['func_id'];
                    $surname = $c['surname'];
                    $name = $c['name'];
                    $birth_date = $c['birth_date'];
	                $current_rank = mb_substr($c['current_rank'], 0, 30, "UTF-8");
                    $teaching_material = $c['teaching_material'];
                    $administrative_status = $c['administrative_status'];
                    $class = $c['class'];
                    $last_update = $this->timeElapsedString($c['last_update']);

					$ops = '<button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#UserModal" onclick="UserModal('.$id.')"><i class="fa fa-edit"></i></button>
					<button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#PrintModal" onclick="PrintModal('.$id.')"><i class="fa fa-print"></i></button>
					<button type="button" class="btn btn-danger btn-sm" onclick="sendToServer(\'delete\','.$id.')"><i class="fa fa-trash"></i></button>
					';					

                    $outputjsonarray[] = array($func_id, $surname, $name, $birth_date, $current_rank, $teaching_material, $class, $last_update, $ops);
					
              }
				
				die(json_encode(array("data"=>$outputjsonarray)));

            } else {
				
				die('No items found');	
				
            }
	}		
	
	public function aeUser($_CPOST)
	{
		
		$errors = array();
			
		$_POST = $this->sanitize($_CPOST); 
		
		$birth_date = ($_POST['birth_date'] != '' ? $_POST['birth_date'] : ' حكم '.$_POST['birth_date2']); 

		if( !$_POST['surname'] || !$_POST['name'] || !$birth_date || !$_POST['birth_place'] || !$_POST['func_id'] || !$_POST['current_rank'] || !$_POST['administrative_status'])
		{
			$errors[] = 'يرجى إدخال المعلومات المؤشرة بالنجمة الحمراء.';
		}

		if( !is_numeric($_POST['func_id']))
		{
			$errors[] = 'بعض الخانات ينبغي أن تتكون من أرقام فقط.';

		}
		
		
		if(count($errors) > 0)
        {
            foreach ($errors as $error){
				echo $error.'<br>';
	            exit;
            }
	    }

				$q_ts = Array();
                // Q+TS
				for ($i = 1; $i <= 10; $i++) {
					
					//TS
					$q_ts['ts_state_'.$i] = @$_POST['ts_state_'.$i];
					$q_ts['ts_institution_'.$i] = @$_POST['ts_institution_'.$i];
					$q_ts['ts_rank_'.$i] = @$_POST['ts_rank_'.$i];
					$q_ts['ts_administrative_status_'.$i] = @$_POST['ts_administrative_status_'.$i];
					$q_ts['ts_entry_date_'.$i] = @$_POST['ts_entry_date_'.$i];
					$q_ts['ts_exit_date_'.$i] = @$_POST['ts_exit_date_'.$i];
					
					//Q
					$q_ts['q_qualification_'.$i] = @$_POST['q_qualification_'.$i];
					$q_ts['q_qualification_date_'.$i] = @$_POST['q_qualification_date_'.$i];
					$q_ts['q_specialization_'.$i] = @$_POST['q_specialization_'.$i];
					
                }
				
				$q_ts_je = json_encode($q_ts);
				
                $rank_id = $this->ranks('', $_POST['current_rank']); 

				$data = Array(
	    	        'surname' => $_POST['surname'],
	    	        'name' => $_POST['name'],
	    	        'latin_surname' => $_POST['latin_surname'],
	    	        'latin_name' => $_POST['latin_name'],
	    	        'father_name' => $_POST['father_name'],
	    	        'father_latin_name' => $_POST['father_latin_name'],
	    	        'mother_surname' => $_POST['mother_surname'],
	    	        'mother_name' => $_POST['mother_name'],
	    	        'mother_latin_surname' => $_POST['mother_latin_surname'],	
	    	        'mother_latin_name' => $_POST['mother_latin_name'],
	    	        'family_status' => $_POST['family_status'],
	    	        'married_women_orig_surname' => $_POST['married_women_orig_surname'],
	    	        'children_number' => $_POST['children_number'],
	    	        'greater_than_10_years' => $_POST['greater_than_10_years'],
	    	        'learning' => $_POST['learning'],
	    	        'insurers' => $_POST['insurers'],
	    	        'birth_date' => $birth_date,
	    	        'birth_place' => $_POST['birth_place'],
	    	        'nationality' => $_POST['nationality'],				
	    	        'blood_type' => $_POST['blood_type'],
	    	        'optical_power' => $_POST['optical_power'],
	    	        'address' => $_POST['address'],
	    	        'postal_code' => $_POST['postal_code'],
	    	        'func_id' => $_POST['func_id'],
	    	        'sector_bilateral' => $_POST['sector_bilateral'],
	    	        'rank_id' => $rank_id,					
	    	        'current_rank' => $_POST['current_rank'],
	    	        'current_rank_date' => $_POST['current_rank_date'],
	    	        'specialization' => $_POST['specialization'],
	    	        'teaching_material' => $_POST['teaching_material'],
	    	        'administrative_status' => $_POST['administrative_status'],
	    	        'fixing_date' => $_POST['fixing_date'],			
	    	        'class' => $_POST['class'],
	    	        'class_effective_date' => $_POST['class_effective_date'],
	    	        'type' => $_POST['type'],					
	    	        'employment_date' => $_POST['employment_date'],
	    	        'nomination_report_number' => $_POST['nomination_report_number'],
		    	    'nomination_report_date' => $_POST['nomination_report_date'],
	    	        'c_school_employment_date' => $_POST['c_school_employment_date'],
	    	        'educational_point' => $_POST['educational_point'],
	    	        'educational_point_date' => $_POST['educational_point_date'],
	    	        'administrative_point' => $_POST['administrative_point'],
	    	        'administrative_point_date' => $_POST['administrative_point_date'],	
	    	        'last_inspection_visit_date' => $_POST['last_inspection_visit_date'],
	    	        'qualifications' => $_POST['qualifications'],
	    	        'postal_account_number' => $_POST['postal_account_number'],
	    	        'pan_key' => $_POST['pan_key'],
	    	        'social_security_number' => $_POST['social_security_number'],
	    	        'mtutalism_number' => $_POST['mtutalism_number'],
	    	        'phone_number' => $_POST['phone_number'],
	    	        'email' => $_POST['email'],
	    	        'syndicalist' => $_POST['syndicalist'],
	    	        'syndicalistic_type' => $_POST['syndicalistic_type'],
	    	        'syndicalistic_date' => $_POST['syndicalistic_date'],
	    	        'profitability_note' => $_POST['profitability_note'],
	    	        'profitability_aps' => $_POST['profitability_aps'],
	    	        'profitability_notes' => $_POST['profitability_notes'],
	    	        'entry_notes' => $_POST['entry_notes'],
	    	        'exit_notes' => $_POST['exit_notes'],
	    	        'q_ts' => $q_ts_je,					
	    	        'last_update' => time()		
	    	    );
	        
		if($_POST['act'] == 'add') {
		    if($this->db->insert ('users', $data)){
                die('1');
		    } else {
				die('خطأ في إضافة المستخدم!');		
            }
		} else {
			if($this->db->update ('users', $data, Array('id' => $_POST['id']))){
                die('1');
		    } else {
				die('خطأ في تحديث معلومات المستخدم!');		
            }
		}

	}
	
	public function saveSettings($_CPOST)
	{
		
		$errors = array();
		
		$_POST = $this->sanitize($_CPOST); 		
        
		if( !$_POST['iap'] || !$_POST['educ_institution_name'] || !$_POST['state'] || !$_POST['school_year'] || !$_POST['teachers_entry_date'] || !$_POST['teachers_exit_date'] || !$_POST['administrators_entry_date'] || !$_POST['administrators_exit_date'] || !$_POST['documents_release_date'] || !$_POST['profitability_triplex'] || !$_POST['profitability_year'])
		{
			$errors[] = 'يرجى ضبط كل الإعدادات.';
		}
		
		if(count($errors) > 0)
        {
            foreach ($errors as $error){
				echo $error.'<br>';
	            exit;
            }
	    }

		$documents_release_date = (($_POST['documents_release_date'] == 'تاريخ الطباعة') ? 'ON' : $_POST['documents_release_date']); 
		
				$data = Array(
	    	        'iap' => $_POST['iap'],
	    	        'amatti_username' => $_POST['amatti_username'],
	    	        'amatti_password' => $_POST['amatti_password'],
	    	        'educ_institution_name' => $_POST['educ_institution_name'],
	    	        'state' => $_POST['state'],
	    	        'school_year' => $_POST['school_year'],
	    	        'teachers_entry_date' => $_POST['teachers_entry_date'],
	    	        'teachers_exit_date' => $_POST['teachers_exit_date'],
	    	        'administrators_entry_date' => $_POST['administrators_entry_date'],
	    	        'administrators_exit_date' => $_POST['administrators_exit_date'],
	    	        'documents_release_date' => $documents_release_date,
	    	        'profitability_triplex' => $_POST['profitability_triplex'],
	    	        'profitability_year' => $_POST['profitability_year'],
	    	        'barcode' => $_POST['barcode'],					
	    	        'last_update' => date("Y-m-d H:i:s", time()),
	    	        'last_up_check' => time()
	    	    );

		        // إعادة تعيين كلمة سر جديدة
		        if(isset($_POST['new_password']) && $_POST['new_password'] !== '')
                {
			        if($_POST['new_password'] !== $_POST['re_new_password'])die('كلمة السر الجديدة غير متطابقة مع الإعادة!');
        
		     		$data['password'] = md5($_POST['new_password']);
		        }
		
			if($this->db->update ('settings', $data, Array('id' => '1'))){
                die('1');
		    } else {
				die('خطأ في حفظ الإعدادات!');		
            }
			

	}
	
	
	public function userToEdit($_CPOST)
	{
			$_POST = $this->sanitize($_CPOST); 

			$e = $this->db->get_row("SELECT * FROM users WHERE id = '".$_POST['id']."'", true);
			
			if($e) {
				
                $e['current_rank'] = $this->ranks('search', $e['current_rank'], 'f');
				
				$e_2 = json_decode($e['q_ts'], true);
				
				if( $e_2 !== NULL && is_array($e_2) ){
					
				    $f_e = array_merge($e, $e_2);
					 
                }else{
					
					$f_e = $e;
	
				}	
				
			    die(json_encode($f_e));

			} else {
				
			    die( 'خطأ!');

			}	

	}
	
	public function settingsToEdit()
	{

			$e = $this->db->get_row("SELECT * FROM settings WHERE id = '1'", true);
			
			if($e) {
                
				unset($e['password']);
				
		       $e['documents_release_date'] = (($e['documents_release_date'] == 'ON') ? 'تاريخ الطباعة' : $e['documents_release_date']); 
				
			    die(json_encode($e));

			} else {
				
			    die( 'خطأ!');

			}	

	}
	
	function toPrint( $table = '', $where = NULL, $limit = 0 )
	{
		//check all necessary arguments
		if( !$table)
			return FALSE;
		
		//prepare a list to store the insert args as they come
		$arg_list = array();
		
		//begin building the query
		$query = 'SELECT * FROM';
		
		//set the table name in the query
		if( is_array( $table ) ) //allow for different prefix
		{
			$query		.= array_shift(array_keys($table));
			$arg_list[]	= array_shift(array_values($table));
		}
		else
		{
			$query .= ' '.$table;
			$arg_list[] = $table;
		}
		
		if($where){

			$query .= ' WHERE';
		
			//add each where condition to the query
			$i=0;
			foreach( $where as $name => $value )
			{

				$query .= ' '.$name.' = '.$value;
		
				//append the value to the arglist
				$arg_list[] = $value;
			
				//if not the final value, be sure to append a comma
				if( $i < count( $where ) - 1)
					$query .= ' AND ';
				
				$i++;			
			}
		}
		
		//append limit if specified
		if( $limit > 0 )
			$query .= ' LIMIT '.$limit;
		
		$query .= ';';
		
		$e = $this->db->get_rows($query, true);
			
		if($e) {

		    return $e;

		} else {
				
		//	header("Location: index.php");
			exit;
			
		}			
	}

	
	public function deleteUser($_CPOST)
	{
		    $_POST = $this->sanitize($_CPOST); 	
			
			if (isset($_POST['id']) || is_numeric($_POST['id'])){							

		        if($this->db->delete ('users', Array('id' => $_POST['id']))) {

                    die('1');
					
		        } else {
				
				    die('0');	
				
                }
				
			}else{
				
				die('Error !');	
				
	        }

	}

	public function cleanDB()
	{
			
		if($this->db->query ('Delete from users')) {

            die('1');
					
		} else {
				
		    die('0');	
				
        }

	}
	
	public function settingsChecker()
	{

			$settings = $this->db->get_row("SELECT * FROM settings", true);
			unset($settings['amatti_username']);
    		unset($settings['amatti_password']);
			if($settings) {

			    foreach ($settings as $setting) {
					
                    if (!isset($setting) || $setting == '') {
						
                        die( '<div class="alert alert-vdanger" role="alert">
                                مرحبا بك عزيزي المستخدم، يبدو أن هذا أول استخدام لبرنامجنا، يرجى  الدخول إلى صفحة  <a href="?page=settings" >الإعدادات</a> وضبط كل المعلومات ثم حفظها، هذه العملية ضرورية من أجل البدء في تسيير المستخدمين.							 </div>');

                    }
					
				}
			} else {
				
			    die( 'خطأ في استلام الإعدادات!');

			}	

	}

	public function checkUpdate()
	{	
			
			$_SESSION['last_up_check'] = time();
			$this->db->update ('settings', Array('last_up_check' => time()), Array('id' => '1'));		

        $content = @file_get_contents(UPDATE_URL);

        if($content !== false And strpos($content, 'ADELQCEM112019DZ17HBB') !== false) {

			$explode_content = explode('|',trim($content));
            if($explode_content[0] !== APP_VERSION){


        echo '<!-- Modal -->
<div class="modal fade" id="modal-update-now" tabindex="-1" role="dialog" aria-labelledby="modal-update-now" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modal-update-now">تحديث جديد متوفر.</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
              <p>أنت تستخدم النسخة: <span style="color: #ff0000;"><strong>'. APP_VERSION .'</strong></span></p>
              <p>تمّ إصدار نسخة جديدة: <span style="color: #ff0000;"><strong>'. $explode_content[0].'</strong></span></p>
              <p>'. $explode_content[1] .'</p>  
			  <button type="submit" id="modal-update-now-btn" class="btn btn-outline-info btn-lg btn-block" onclick="ExucUpdate(\''.$explode_content[2].'\')">
                    <i class="fa fa-fire"></i> التحديث الآن
              </button>

      </div>
      <div class="modal-footer">
       </div>
    </div>
  </div>
</div>';
        
            echo "
            <script type='text/javascript'>
            $(window).on('load',function(){
                $('#modal-update-now').modal('show');
                
            });
            </script>";            
            }
        } 
	}	

	public function SDDU($_CPOST)
	{
		
		$_POST = $this->sanitize($_CPOST); 	
		
		if (isset($_POST['rf']) and !filter_var($_POST['rf'], FILTER_VALIDATE_URL)){ die('خطأ في رابط تحميل ملف التحديث !'); }
			
        $remote_update_file_cont = @file_get_contents($_POST['rf']);			
			
		if ($remote_update_file_cont === false){
				
        	die('خطأ في تحميل ملف التحديث !');	

        }elseif(!file_put_contents("update.php", $remote_update_file_cont)){
				
		    die('خطأ في حفظ ملف التحديث !');	
        
		}elseif(!file_exists('update.php')){
			
    		die('خطأ في العثور على ملف التحديث !');	
		
		}else{
			
    		sleep(3);
			
			require_once('update.php');
		        
			@unlink('update.php');	
			    
			die('1');

        }
			
	}
	
    public function timeElapsedString($time_ago)
	{
		
		$time_ago =  strtotime($time_ago) ? strtotime($time_ago) : $time_ago;
		$time  = time() - $time_ago;

		switch($time):
	
		case $time <= 60;
		return 'قبل ثواني';
	
		case $time >= 60 && $time < 3600;
		return (round($time/60) == 1) ? 'قبل دقيقة' : 'قبل '.round($time/60).' دقائق';
	
		case $time >= 3600 && $time < 86400;
		return (round($time/3600) == 1) ? 'قبل ساعة' : 'قبل '.round($time/3600).' ساعات';

		case $time >= 86400 && $time < 604800;
		return (round($time/86400) == 1) ? 'قبل يوم' : 'قبل '.round($time/86400).' أيام';

		case $time >= 604800 && $time < 2600640;
		return (round($time/604800) == 1) ? 'قبل أسبوع' : 'قبل '.round($time/604800).' أسابيع';

		case $time >= 2600640 && $time < 31207680;
		return (round($time/2600640) == 1) ? 'قبل شهر' : 'قبل '.round($time/2600640).' أشهر';

		case $time >= 31207680;
		return (round($time/31207680) == 1) ? 'قبل سنة' : 'قبل '.round($time/31207680).' سنوات' ;

		endswitch;

	}

	public function exportUsers()
	{
        
		$filename = 'users.xls';
        
		$users = $this->db->get_rows ("SELECT * FROM users", true);
			
        $objPHPExcel = new PHPExcel(); 
        $objPHPExcel->setActiveSheetIndex(0) 
            ->setRightToLeft(true);		
			
        $i = 2; 
        $uCount = 1; 

        if($this->db->num_rows() > 0) {
			
            $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue('A1', 'الرقم')
                ->setCellValue('B1', 'الرقم الوظيفي')
                ->setCellValue('C1', 'اللقب')
                ->setCellValue('D1', 'الاسم')
                ->setCellValue('E1', 'اللقب باللاتينية')
                ->setCellValue('F1', 'الاسم باللاتينية')
                ->setCellValue('G1', 'اسم الأب')
                ->setCellValue('H1', 'اسم الأب باللاتينية')
                ->setCellValue('I1', 'لقب الأم')
                ->setCellValue('J1', 'اسم الأم')
                ->setCellValue('K1', 'لقب الأم باللاتينية')
                ->setCellValue('L1', 'اسم الأم باللاتينية')
                ->setCellValue('M1', 'الحالة العائلية')
                ->setCellValue('N1', 'اللقب الأصلي للمتزوجات')
                ->setCellValue('O1', 'عدد الأطفال')
                ->setCellValue('P1', 'الأطفال فوق 10 سنوات')
                ->setCellValue('Q1', 'المتمدرسون')
                ->setCellValue('R1', 'المتكفل بهم')
                ->setCellValue('S1', 'تاريخ الميلاد')
                ->setCellValue('T1', 'مكان الميلاد')
                ->setCellValue('U1', 'الجنسية')
                ->setCellValue('V1', 'فصيلة الدم')
                ->setCellValue('W1', 'القدرة البصرية')
                ->setCellValue('X1', 'العنوان')
                ->setCellValue('Y1', 'الرمز البريدي')
                ->setCellValue('Z1', 'ثنائي في القطاع')
                ->setCellValue('AA1', 'الرتبة')
                ->setCellValue('AB1', 'تاريخ الرتبة الحالية')
                ->setCellValue('AC1', 'الاختصاص')
                ->setCellValue('AD1', 'مادة التدريس')
                ->setCellValue('AE1', 'الوضعية الإدارية')
                ->setCellValue('AF1', 'الدرجة')
                ->setCellValue('AG1', 'تاريخ سريان الدرجة')
                ->setCellValue('AH1', 'الصنف')
                ->setCellValue('AI1', 'تاريخ التوظيف')
                ->setCellValue('AJ1', 'رقم مقررة التوظيف')
                ->setCellValue('AK1', 'تاريخ مقررة التوظيف')
                ->setCellValue('AL1', 'تاريخ التوظيف في المؤسسة الحالية')
                ->setCellValue('AM1', 'النقطة التربوية')
                ->setCellValue('AN1', 'تاريخ النقطة التربوية')
                ->setCellValue('AO1', 'آخر زيارة تفتيشية')
                ->setCellValue('AP1', 'المؤهلات العلمية')
                ->setCellValue('AQ1', 'رقم الحساب البريد')
                ->setCellValue('AR1', 'المفتاح')
                ->setCellValue('AS1', 'رقم الضمان الاجتماعي')
                ->setCellValue('AT1', 'رقم التعاضدية')
                ->setCellValue('AU1', 'رقم الهاتف')
                ->setCellValue('AV1', 'البريد الإلكتروني')
                ->setCellValue('AW1', 'التنظيم النقابي')
                ->setCellValue('AX1', 'صفة الانتماء')
                ->setCellValue('AY1', 'تاريخ الانتماء');
				
            $objPHPExcel->getActiveSheet()
                ->getStyle('A1:AY1')
                ->applyFromArray(
                    array(
                        'fill' => array(
                            'type' => PHPExcel_Style_Fill::FILL_SOLID,
                            'color' => array('rgb' => 'BFBFBF')
                        )
                    )
                );
	
    		foreach ($users as $u) {
    		    $objPHPExcel->setActiveSheetIndex(0)
    		    ->setCellValue('A'.$i, $uCount)
    		    ->setCellValue('B'.$i, $u['func_id'])
    		    ->setCellValue('C'.$i, $u['surname'])
    		    ->setCellValue('D'.$i, $u['name'])
    		    ->setCellValue('E'.$i, $u['latin_surname'])
    		    ->setCellValue('F'.$i, $u['latin_name'])
    		    ->setCellValue('G'.$i, $u['father_name'])
    		    ->setCellValue('H'.$i, $u['father_latin_name'])
    		    ->setCellValue('I'.$i, $u['mother_surname'])
    		    ->setCellValue('G'.$i, $u['mother_name'])
    		    ->setCellValue('K'.$i, $u['mother_latin_surname'])
    		    ->setCellValue('L'.$i, $u['mother_latin_name'])
    		    ->setCellValue('M'.$i, $u['family_status'])
    		    ->setCellValue('N'.$i, $u['married_women_orig_surname'])
    		    ->setCellValue('O'.$i, $u['children_number'])
    		    ->setCellValue('P'.$i, $u['greater_than_10_years'])
    		    ->setCellValue('Q'.$i, $u['learning'])
    		    ->setCellValue('R'.$i, $u['insurers'])
    		    ->setCellValue('S'.$i, $u['birth_date'])
    		    ->setCellValue('T'.$i, $u['birth_place'])
    		    ->setCellValue('U'.$i, $u['nationality'])
    		    ->setCellValue('V'.$i, $u['blood_type'])
    		    ->setCellValue('W'.$i, $u['optical_power'])
    		    ->setCellValue('X'.$i, $u['address'])
    		    ->setCellValue('Y'.$i, $u['postal_code'])
    		    ->setCellValue('Z'.$i, $u['sector_bilateral'])
    		    ->setCellValue('AA'.$i, $u['current_rank'])
    		    ->setCellValue('AB'.$i, $u['current_rank_date'])
    		    ->setCellValue('AC'.$i, $u['specialization'])
    		    ->setCellValue('AD'.$i, $u['teaching_material'])
    		    ->setCellValue('AE'.$i, $u['administrative_status'])
    		    ->setCellValue('AF'.$i, $u['class'])
    		    ->setCellValue('AG'.$i, $u['class_effective_date'])
    		    ->setCellValue('AH'.$i, $u['type'])
    		    ->setCellValue('AI'.$i, $u['employment_date'])
    		    ->setCellValue('AG'.$i, $u['nomination_report_number'])
    		    ->setCellValue('AK'.$i, $u['nomination_report_date'])
    		    ->setCellValue('AL'.$i, $u['c_school_employment_date'])
    		    ->setCellValue('AM'.$i, $u['educational_point'])
    		    ->setCellValue('AN'.$i, $u['educational_point_date'])
    		    ->setCellValue('AO'.$i, $u['last_inspection_visit_date'])
    		    ->setCellValue('AP'.$i, $u['qualifications'])
    		    ->setCellValue('AQ'.$i, $u['postal_account_number'])
    		    ->setCellValue('AR'.$i, $u['pan_key'])
    		    ->setCellValue('AS'.$i, $u['social_security_number'])
    		    ->setCellValue('AT'.$i, $u['mtutalism_number'])
    		    ->setCellValue('AU'.$i, $u['phone_number'])
    		    ->setCellValue('AV'.$i, $u['email'])
    		    ->setCellValue('AW'.$i, $u['syndicalist'])
    		    ->setCellValue('AX'.$i, $u['syndicalistic_type'])
    		    ->setCellValue('AY'.$i, $u['syndicalistic_date']);
				
    		    $i++;
    		    $uCount++;				
            }

            $objPHPExcel->getActiveSheet()
                ->getStyle('A1:AY'.$uCount)
                ->getAlignment()
                ->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
                
				
            $objPHPExcel->getActiveSheet()
                ->getStyle('A1:AY'.$uCount)
                ->applyFromArray(
                    array(
                        'borders' => array(
                            'allborders' => array(
                            'style' => PHPExcel_Style_Border::BORDER_THIN
                            )
                        )
                    )
                );	
				
            foreach ($objPHPExcel->getWorksheetIterator() as $worksheet) {

                $objPHPExcel->setActiveSheetIndex($objPHPExcel->getIndex($worksheet));

                $sheet = $objPHPExcel->getActiveSheet();
                $cellIterator = $sheet->getRowIterator()->current()->getCellIterator();
                $cellIterator->setIterateOnlyExistingCells(true);
                foreach ($cellIterator as $cell) {
                    $sheet->getColumnDimension($cell->getColumn())->setAutoSize(true);
                }
            }
			
            $objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel); 
            $objWriter->save($filename); 
        
		} else {
			
			die('لا توجد بيانات لتصديرها');	
				
        }

	}
	
    public function amattiImportUsers($_CPOST) {

		$_POST = $this->sanitize($_CPOST); 	
	
		sleep(3);

		$curl_s = curl_init();
		
		curl_setopt($curl_s,CURLOPT_URL,'https://amatti.education.gov.dz/login/verif_login');
		curl_setopt($curl_s,CURLOPT_USERAGENT,'Mozilla/5.0 (X11; Linux i686; rv:24.0) Gecko/20140319 Firefox/24.0 Iceweasel/24.4.0');
		curl_setopt($curl_s,CURLOPT_POST,True);
		curl_setopt($curl_s,CURLOPT_POSTFIELDS,'iap='.$_POST['iap'].'&user_name='.$_POST['user_name'].'&password='.$_POST['password']);
		curl_setopt($curl_s,CURLOPT_RETURNTRANSFER,True);
		curl_setopt($curl_s,CURLOPT_FOLLOWLOCATION,True);
		curl_setopt($curl_s,CURLOPT_COOKIEFILE,"cookie.txt");
		curl_setopt($curl_s,CURLOPT_COOKIEJAR,"cookie.txt");
		curl_setopt($curl_s,CURLOPT_CONNECTTIMEOUT,30);
		curl_setopt($curl_s,CURLOPT_TIMEOUT,30);  
		curl_setopt($curl_s,CURLOPT_SSL_VERIFYPEER,false);  
		
		$exec = curl_exec($curl_s);
		$statusCode = curl_getinfo($curl_s, CURLINFO_HTTP_CODE);
		
		if($statusCode !== 200){
			
			die('موقع الأرضية الرقمية مغلق حاليا أو عليه ضغط، يرجى المحاولة لاحقا');
			
		} elseif (strpos($exec, 'فضاء الأولياء') == false) {
		
			die('فشلت عملية الدخول إلى الموقع، يرجى التأكد من معلومات الدخول');

		}else {
		
			curl_setopt($curl_s, CURLOPT_URL, 'https://amatti.education.gov.dz/pers/personnel/list_etablissement'); // set url for next request
 		    curl_setopt($curl_s, CURLOPT_POST,True); 
		//  curl_setopt($curl_s, CURLOPT_POSTFIELDS, $Down_Post); // set post data
            curl_setopt($curl_s, CURLOPT_REFERER, 'https://amatti.education.gov.dz/pers/personnel/list_etablissement');
	
  		    $exec = curl_exec($curl_s); // make request to buy on the same handle with the current login session

			curl_close($curl_s);
		
			$dataz = json_decode($exec);

			foreach ($dataz->data as $data){
            	
				$data2db = Array(
	    	        'func_id' => trim($data[1]),				
	    	        'surname' => trim($data[2]),
	    	        'name' => trim($data[3]),
	    	        'birth_date' => trim($data[4]),
	    	        'current_rank' => trim($data[5]),
	    	        'rank_id' => $this->ranks('search', trim($data[5])),									
	    	        'teaching_material' => trim($data[6]),					
	    	        'class' => trim($data[7]),
	    	        'class_effective_date' => trim($data[8]),
	    	        'last_update' => time()		
	    	    );
	        	
				$this->db->insert ('users', $data2db);

            }

		}
		
		die('1');
		
	}	
	
	public function ranks($op, $value = null, $t = null)
	{
	    $ranks_array = Array(
            'مدير الثانوية' => '2',
            'مدير المتوسطة' => '2',
            'مدير الابتدائية' => '2',
            'أستاذ التعليم الثانوي' => '1',
            'أستاذ التعليم المتوسط' => '1',
            'أستاذ التعليم الابتدائي' => '1',			
            'مستشار رئيسي للتربية' => '2',
            'مستشار التربية' => '2',
            'مشرف رئيسي للتربية' => '2',
            'مشرف للتربية' => '2',
            'مساعد رئيسي للتربية' => '2',
            'مساعد التربية' => '2',
            'مقتصد رئيسي' => '2',
            'مقتصد' => '2',
            'نائب مقتصد مسير' => '2',
            'نائب مقتصد' => '2',
            'م.ر.م اقتصادية' => '2',
            'مساعد.م اقتصادية' => '2',
            'عون إدارة رئيسي' => '2',
            'عون إدارة' => '2',
            'كاتب' => '2',
            'عون حفظ بيانات' => '2',
            'مساعد وثائقي أمين محفوظات' => '2',
            'ملحق بالمخبر' => '2',
            'معاون تقني في المخبر والصيانة' => '2',
            'معاون تقني في الخبر' => '2',
            'تقني في المخبر والصيانة' => '2',
            'عون تقني في المخبر والصيانة' => '2',
            'عون تقني في المخبر' => '2',
            'ممرض مؤهل' => '2',
            'مساعد تمريض رئيسي للصحة ع' => '2',
            'مساعد تمريض للصحة' => '2',
            'عامل مهني خارج الصنف' => '3',
            'مسؤول مخزن' => '3',
            'مسؤول مطبخ' => '3',
            'مسؤول خدمة داخلية' => '3',
            'عامل مهني من الصنف الأول' => '3',
            'عامل مهني صنف 1' => '3',
            'مخزني' => '3',
            'طباخ صنف 1' => '3',
            'عامل مهني من الصنف الثاني' => '3',
            'بواب المؤسسة' => '3',
            'عامل مهني صنف 2' => '3',
            'طباخ صنف 2' => '3',
            'بياضة مرقعة' => '3',
            'عامل مهني من الصنف 3' => '3',
            'سائق سيارة من الصنف 1' => '3',
            'سائق سيارة من الصنف 2' => '3',
            'سائق سيارة من المستوى 1' => '3',
            'سائق سيارة من المستوى 2' => '3',
            'عون وقاية من المستوى 1' => '3',
            'عون وقاية من المستوى 2' => '3',
            'عامل مهني من المستوى الأول' => '3',
            'عامل مهني من المستوى الثالث' => '3',
            'عامل مهني من الصنف 1' => '3',
            'مخزني' => '3',
            'طباخ صنف 1' => '3',
            'مسؤولة غسيل' => '3',
            'عامل مهني من المستوى الثاني' => '3',
            'بواب المؤسسة' => '3',
            'عامل مهني صنف 2' => '3',
            'طباخ صنف 2' => '3',
            'بياضة مرقعة' => '3',
            'تعريف مستشار التوجيه والإرشاد التربوي والمهني' => '2'
		);
		
        if ($op == 'select') {
			foreach ($ranks_array as $key => $value) {
				echo '<option value="'.$key.'">'.$key.'</option>';
	        }
        } elseif($op == 'search') {
            $shortest = -1;
			foreach ($ranks_array as $word => $val) {
			    $lev = levenshtein($value, $word);
			    if ($lev == 0) {
		    	    $closest = $word;
	    		    $shortest = 0;
    			    break;
			    }
                if ($lev <= $shortest || $shortest < 0) {
        	   	    $closest  = $word;
			        $shortest = $lev;
			    }
			}

			if ($shortest == 0) {
				if ($t == 'f') {
			        return $closest;
			    } else {
			        return $ranks_array[$closest];
			    }	
			} else {
				if ($t == 'f') {
			        return $closest;
			    } else {
			        return $ranks_array[$closest];
			    }			}			
        }else {
			return isset($ranks_array[$value]) ? $ranks_array[$value] : false;				
        }
	}

	public function states()
	{
	    $states_array = Array(
            'أدرار' => 'أدرار',
            'الشلف' => 'الشلف',
            'الأغواط' => 'الأغواط',
            'أم البواقي' => 'أم البواقي',
            'باتنة' => 'باتنة',
            'بجاية' => 'بجاية',
            'بسكرة' => 'بسكرة',
            'بشار' => 'بشار',
            'البليدة' => 'البليدة',
            'البويرة' => 'البويرة',
            'تمنراست' => 'تمنراست',
            'تبسة' => 'تبسة',
            'تلمسان' => 'تلمسان',
            'تيارت' => 'تيارت',
            'تيزي وزو' => 'تيزي وزو',
            'الجزائر' => 'الجزائر',
            'الجلفة' => 'الجلفة',
            'جيجل' => 'جيجل',
            'سطيف' => 'سطيف',
            'سعيدة' => 'سعيدة',
            'سكيكدة' => 'سكيكدة',
            'سيدي بلعباس' => 'سيدي بلعباس',
            'عنابة' => 'عنابة',
            'قالمة' => 'قالمة',
            'قسنطينة' => 'قسنطينة',
            'المدية' => 'المدية',
            'مستغانم' => 'مستغانم',
            'المسيلة' => 'المسيلة',
            'معسكر' => 'معسكر',
            'ورقلة' => 'ورقلة',
            'وهران' => 'وهران',
            'البيض' => 'البيض',
            'إيليزي' => 'إيليزي',
            'برج بوعريريج' => 'برج بوعريريج',
            'بومرداس' => 'بومرداس',
            'الطارف' => 'الطارف',
            'تندوف' => 'تندوف',
            'تيسمسيلت' => 'تيسمسيلت',
            'الوادي' => 'الوادي',
            'خنشلة' => 'خنشلة',
            'سوق أهراس' => 'سوق أهراس',
            'تيبازة' => 'تيبازة',
            'ميلة' => 'ميلة',
            'عين الدفلى' => 'عين الدفلى',
            'النعامة' => 'النعامة',
            'عين تيموشنت' => 'عين تيموشنت',
            'غرداية' => 'غرداية',
            'غليزان' => 'غليزان'
		);
			
		foreach ($states_array as $key => $value) {
			echo '<option value="'.$key.'">'.$key.'</option>';
	    }
}
	
	public function tsInputs($n, $t = 's' )
	{
		
		if ($t == 's') {

        for ($i = 1; $i <= $n; $i++) {
	        echo '
                                                    <div class="col-sm-2 col-lg-2 form-group form-inline">
                                                      <select name="ts_state_'.$i.'" class="form-control" title="الولاية">
                                                        <option value="" selected="selected">-- الرجاء الاختيار --</option>
                                                              '; 
															  $this->states();
            echo '                                 </select>
                                                    </div>
                                                    <div class="col-sm-2 col-lg-2 form-group form-inline">
                                                        <input type="text" name="ts_institution_'.$i.'" class="form-control" id="ts_institution_'.$i.'" value="" title="المؤسسة">
                                                    </div>													
                                                    <div class="col-sm-2 col-lg-2 form-group form-inline">
                                                        <select name="ts_rank_'.$i.'" id="ts_rank_'.$i.'" class="form-control" style="width:220px;" title="الرتبة">
                                                            <option value="" selected="selected">-- الرجاء الاختيار --</option>';
                                                               $this->ranks('select');
            echo '                                            </select>
													</div>
                                                    <div class="col-sm-2 col-lg-2 form-group form-inline">
                                                        <select name="ts_administrative_status_'.$i.'" id="ts_administrative_status_'.$i.'" class="form-control" title="الصفة">
                                                            <option value="" selected="selected">-- الرجاء الاختيار --</option>
                                                            <option value="مرسم(ة)">مرسم(ة)</option>
                                                            <option value="متربص(ة)">متربص(ة)</option>
                                                            <option value="مستخلف(ة)">مستخلف(ة)</option>
                                                        </select>
													</div>
                                                    <div class="col-sm-2 col-lg-2 form-group form-inline">
                                                        <input type="text" name="ts_entry_date_'.$i.'" class="form-control" id="ts_datetimepicker1_'.$i.'" placeholder="yyyy-mm-dd"  title="تاريخ مباشرة العمل">
                                                    </div>
                                                    <div class="col-sm-2 col-lg-2 form-group form-inline">
                                                        <input type="text" name="ts_exit_date_'.$i.'" class="form-control" id="ts_datetimepicker2_'.$i.'" placeholder="yyyy-mm-dd"  title="تاريخ نهاية العمل">
                                                    </div>';
													
		echo "
                	<script>

		                jQuery('#ts_datetimepicker1_$i').datetimepicker({
                            timepicker: false,
                            format: 'Y-m-d'
                        }); 
						
		                jQuery('#ts_datetimepicker2_$i').datetimepicker({
                            timepicker: false,
                            format: 'Y-m-d'
                        }); 						
						
						
					</script>";
											
 			
	    }
	   
	   }else {
	
        for ($i = 1; $i <= $n; $i++) {
	        echo '                                  <div class="col-sm-4 col-lg-4 form-group form-inline">
                                                        <input type="text" name="q_qualification_'.$i.'" class="form-control" id="ts_qualification_'.$i.'" value="" title="المؤهل">
                                                    </div>
                                                    <div class="col-sm-4 col-lg-4 form-group form-inline">
                                                        <input type="text" name="q_qualification_date_'.$i.'" class="form-control"  id="q_datetimepicker1_'.$i.'" placeholder="yyyy-mm-dd" title="تاريخ الشهادة">
                                                    </div>
                                                    <div class="col-sm-4 col-lg-4 form-group form-inline">
                                                        <input type="text" name="q_specialization_'.$i.'" class="form-control" id="q_specialization_'.$i.'" value="" title="التخصص">
                                                    </div>	';
													
		echo "  
		            <script>
    
		                jQuery('#q_datetimepicker1_$i').datetimepicker({
                            timepicker: false,
                            format: 'Y-m-d'
                        }); 						
						
					</script>";													
 			
	    }
	}	
		
}

	public function GenKey($length = 7)
    {
        $password = "";
        $possible = "0123456789abcdefghijkmnopqrstuvwxyz";

        $i = 0;

        while ($i < $length) {


            $char = substr($possible, mt_rand(0, strlen($possible)-1), 1);


            if (!strstr($password, $char)) {
                $password .= $char;
                $i++;
            }

		}

	    return $password;
    }
	
    public function sanitize(array $input, array $fields = array(), $utf8_encode = true)
    {
        $magic_quotes = (bool) get_magic_quotes_gpc();

        if (empty($fields)) {
            $fields = array_keys($input);
        }

        $return = array();

        foreach ($fields as $field) {
            if (!isset($input[$field])) {
                continue;
            } else {
                $value = $input[$field];
                if (is_array($value)) {
                    $value = $this->sanitize($value);
                }
                if (is_string($value)) {
                    if ($magic_quotes === true) {
                        $value = stripslashes($value);
                    }

                    if (strpos($value, "\r") !== false) {
                        $value = trim($value);
                    }

                    if (function_exists('iconv') && function_exists('mb_detect_encoding') && $utf8_encode) {
                        $current_encoding = mb_detect_encoding($value);

                        if ($current_encoding != 'UTF-8' && $current_encoding != 'UTF-16') {
                            $value = iconv($current_encoding, 'UTF-8', $value);
                        }
                    }

                    $value = filter_var($value, FILTER_SANITIZE_STRING);
                }

                $return[$field] = $value;
            }
        }

        return $return;
    }
}


class FlxZipArchive extends ZipArchive {
        /** Add a Dir with Files and Subdirs to the archive;;;;; @param string $location Real Location;;;;  @param string $name Name in Archive;;; @author Nicolas Heimann;;;; @access private  **/
    public function addDir($location, $name) {
        $this->addEmptyDir($name);
         $this->addDirDo($location, $name);
     } // EO addDir;

        /**  Add Files & Dirs to archive;;;; @param string $location Real Location;  @param string $name Name in Archive;;;;;; @author Nicolas Heimann * @access private   **/
    private function addDirDo($location, $name) {
        $name .= '/';         $location .= '/';
      // Read all Files in Dir
        $dir = opendir ($location);
        while ($file = readdir($dir))    {
            if ($file == '.' || $file == '..') continue;
          // Rekursiv, If dir: FlxZipArchive::addDir(), else ::File();
            $do = (filetype( $location . $file) == 'dir') ? 'addDir' : 'addFile';
            $this->$do($location . $file, $name . $file);
        }
    } 
}