<?php
/*
-----------------------------------------------
            سكربت المدير الرقمي            
-----------------------------------------------
برمجة وتطوير: عادل قصي
البريد الإلكتروني: adelbak2014@gmail.com
الموقع الرسمي: www.cem11.com
الصفحة الرسمية للمبرمج: https://www.facebook.com/adel.qusay.9
-----------------------------------------------
السكربت مجاني، يرجى طلب الإذن عند الرغبة في
التطوير.
-----------------------------------------------
*/

require 'config.php';

if (@$_SERVER['REQUEST_METHOD'] !== 'POST') { die('0'); }

/*------------------------
          Login
------------------------*/
if (isset($_POST['act']) && $_POST['act'] === 'login') {

    $engine->Login($_POST);

}

if (isset($_SESSION['educ_institution_name']) == '') { die('0'); }

/*========================
     تسيير المستخدمين
/*========================*/

/*------------------------
         Items
------------------------*/
if (isset($_POST['act']) && $_POST['act'] === 'show') {

    $engine->getUsers();

}

/*------------------------
          Delete
------------------------*/
if (isset($_POST['act']) && $_POST['act'] === 'delete') {

    $engine->deleteUser($_POST);

}
/*------------------------
         Add
------------------------*/
if (isset($_POST['act']) && $_POST['act'] === 'add' or isset($_POST['act']) && $_POST['act'] === 'edit') {

    $engine->aeUser($_POST);

}

/*------------------------
         Settings
------------------------*/
if (isset($_POST['act']) && $_POST['act'] === 'settings') {

    $engine->saveSettings($_POST);

}

/*------------------------
       User to edit
------------------------*/
if (isset($_POST['act']) && $_POST['act'] === 'utoedit') {

    $engine->userToEdit($_POST);

}

/*------------------------
      Settings to edit
------------------------*/
if (isset($_POST['act']) && $_POST['act'] === 'stoedit') {

    $engine->settingsToEdit();

}

/*------------------------
         Export
------------------------*/
if (isset($_POST['act']) && $_POST['act'] === 'export') {

    $engine->exportUsers();

}

/*------------------------
         Import
------------------------*/
if (isset($_POST['act']) && $_POST['act'] === 'import') {

    $engine->amattiImportUsers($_POST);

}

/*------------------------
         cleanDB
------------------------*/
if (isset($_POST['act']) && $_POST['act'] === 'cleanDB') {

    $engine->cleanDB();

}

/*========================
         الرقمنة
/*========================*/

/*------------------------
     CEM Generate Lists
------------------------*/
if (isset($_POST['annee_school']) && isset($_POST['educ_ins_name']) && isset($_FILES['eleve'])) {
	
   $engine->CEM_Upl_Gen_lists($_FILES['eleve'], $_POST);	  
	  
} 

/*------------------------
     CEM Send Notes
------------------------*/
if (isset($_POST['go']) && $_POST['go'] === 'submit' && isset($_FILES['list'])) {

    $engine->CEM_Upl_Pre_Send_list($_FILES['list']);

} 

/*------------------------
          Update
------------------------*/
if (isset($_POST['act']) && $_POST['act'] === 'SDDU') {

    $engine->SDDU($_POST);

}


?>