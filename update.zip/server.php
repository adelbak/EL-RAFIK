<?php
/*
-----------------------------------------------
            برنامج الرفيق            
-----------------------------------------------
برمجة وتطوير: عادل قصي
البريد الإلكتروني: adelbak2014@gmail.com
الموقع الرسمي: https://github.com/adelbak/EL-RAFIK
الصفحة الرسمية للمبرمج: https://www.facebook.com/adel.qusay.9
-----------------------------------------------
*/

require 'config.php';

if (@$_SERVER['REQUEST_METHOD'] !== 'POST') { die('0'); }

/*========================
         License
/*========================*/

if (isset($_POST['license']) && $_POST['license'] === 'license') {

    $engine->checkLicenseCode($_POST);

}

/*------------------------
          Login
------------------------*/
if (isset($_POST['act']) && $_POST['act'] === 'login') {
	
    $engine->login($_POST);

}

/*------------------------
          Update
------------------------*/
if (isset($_POST['act']) && $_POST['act'] === 'SDDU') {

    $engine->SDDU($_POST);

}

if (isset($_SESSION['educ_institution_name']) == '') { die('0'); }

/*------------------------
        Contact Us
------------------------*/
if (isset($_POST['op']) && $_POST['op'] === 'contact') {

    $engine->contactUs($_POST);

}

/*------------------------
        Check Update
------------------------*/
if (isset($_POST['act']) && $_POST['act'] === 'cupdate') {

    $engine->mCheckUpdate();

}

/*========================
     تسيير المستخدمين
/*========================*/
/*------------------------
         Exams
------------------------*/
if (isset($_POST['act']) && $_POST['act'] === 'getExam') {

    $engine->getExam($_POST);

}

if (isset($_POST['act']) && $_POST['act'] === 'deleteExam') {

    $engine->deleteExam($_POST);

}
if (isset($_POST['act']) && $_POST['act'] === 'deleteExams') {

    $engine->deleteExams($_POST);

}
if (isset($_POST['act']) && $_POST['act'] === 'examToEdit') {

    $engine->examToEdit($_POST);

}
if (isset($_POST['act']) && $_POST['act'] === 'addExam' or isset($_POST['act']) && $_POST['act'] === 'editExam') {

    $engine->aeExam($_POST);

}


/*------------------------
         Users
------------------------*/
if (isset($_POST['act']) && $_POST['act'] === 'show') {

    $engine->getUsers();

}

/*------------------------
          Delete
------------------------*/
if (isset($_POST['act']) && $_POST['act'] === 'delete') {

    $engine->deleteUser($_POST);

}
/*------------------------
         Add
------------------------*/
if (isset($_POST['act']) && $_POST['act'] === 'add' or isset($_POST['act']) && $_POST['act'] === 'edit') {

    $engine->aeUser($_POST);

}

/*------------------------
         Settings
------------------------*/
if (isset($_POST['act']) && $_POST['act'] === 'settings') {

    $engine->saveSettings($_POST);

}

/*------------------------
       User to edit
------------------------*/
if (isset($_POST['act']) && $_POST['act'] === 'utoedit') {

    $engine->userToEdit($_POST);

}

/*------------------------
      Settings to edit
------------------------*/
if (isset($_POST['act']) && $_POST['act'] === 'settToEdit') {

    $engine->settingsToEdit();

}

/*------------------------
         Export
------------------------*/
if (isset($_POST['act']) && $_POST['act'] === 'export') {

    $engine->exportUsers();

}

/*------------------------
         deleteUsers
------------------------*/
if (isset($_POST['act']) && $_POST['act'] === 'deleteUsers') {

    $engine->deleteUsers();

}

/*========================
     إدارة التلاميذ
/*========================*/
/*------------------------
       Students
------------------------*/
if (isset($_POST['act']) && $_POST['act'] === 'showS') {

    $engine->getStudents($_POST);

}
/*------------------------
       Add Student
------------------------*/
if (isset($_POST['act']) && $_POST['act'] === 'sAdd' && !isset($_POST['op'])) {

    $engine->addStudent($_POST);

}
/*------------------------
          Delete
------------------------*/
if (isset($_POST['act']) && $_POST['act'] === 'deleteS') {

    $engine->deleteStudent($_POST);

}
/*------------------------
     Student to edit
------------------------*/
if (isset($_POST['act']) && $_POST['act'] === 'sToEdit') {

    $engine->studentToEdit($_POST);

}
/*------------------------
       Edit Student
------------------------*/
if (isset($_POST['act']) && $_POST['act'] === 'sEdit' && !isset($_POST['op'])) {

    $engine->editStudents($_POST);

}

/*------------------------
         Import
------------------------*/
if (isset($_POST['act']) && $_POST['act'] === 'sImport' && !isset($_POST['op'])) {

    $engine->amattiImportStudents($_POST, $_FILES['list']);

}

/*------------------------
         Import
------------------------*/
if (isset($_POST['act']) && $_POST['act'] === 'uImport') {

    $engine->amattiImportUsers($_POST, $_FILES['uList']);

}

if (isset($_POST['act']) && $_POST['act'] === 'mImport' && !isset($_POST['op'])) {

    $engine->amattiImportMStudents($_POST, $_FILES['mList']);

}
/*------------------------
     Delete Students Info
------------------------*/
if (isset($_POST['op']) && $_POST['op'] === 'massDeleteStudents') {

    $engine->massDeleteStudents($_POST);

}

/*------------------------
     Students Counter
------------------------*/
if (isset($_POST['op']) && $_POST['op'] === 'sc') {

    $engine->studentsCounter($_POST);

}

/*------------------------
         cleanDB
------------------------*/
if (isset($_POST['act']) && $_POST['act'] === 'deleteStudents') {

    $engine->deleteStudents();

}


?>