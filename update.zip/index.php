<?php
/*
-----------------------------------------------
            سكربت المدير الرقمي            
-----------------------------------------------
برمجة وتطوير: عادل قصي
البريد الإلكتروني: adelbak2014@gmail.com
الموقع الرسمي: www.cem11.com
الصفحة الرسمية للمبرمج: https://www.facebook.com/adel.qusay.9
-----------------------------------------------
السكربت مجاني، يرجى طلب الإذن عند الرغبة في
التطوير.
-----------------------------------------------
*/

require 'config.php';

$page = isset( $_GET['page'] ) ? $_GET['page'] : '';

if(isset($_SESSION['educ_institution_name']) != '')
{	
    switch ( $page ) {
        case 'users':
            require( DIR_MODS . "/users.php" );
        break;
        case 'cem_notes':
            require( DIR_MODS . "/cem_notes.php" );
        break;			
        case 'settings':
            require( DIR_MODS . "/settings.php" );
        break;			
        case 'logout':
            require( DIR_MODS . "/logout.php" );
        break;		
        default:
            require( DIR_MODS . "/users.php" );
        }

}
else
{

    switch ( $page ) {
        case 'login':
            require( DIR_MODS . "/login.php" );
        break;
        case 'forgot':
            require( DIR_MODS . "/forgot.php" );
        break;		
        default:
            require( DIR_MODS . "/login.php" );
        }

}


?>