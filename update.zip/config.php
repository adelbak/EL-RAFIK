<?php
/*
-----------------------------------------------
            سكربت المدير الرقمي            
-----------------------------------------------
برمجة وتطوير: عادل قصي
البريد الإلكتروني: adelbak2014@gmail.com
الموقع الرسمي: www.cem11.com
الصفحة الرسمية للمبرمج: https://www.facebook.com/adel.qusay.9
-----------------------------------------------
السكربت مجاني، يرجى طلب الإذن عند الرغبة في
التطوير.
-----------------------------------------------
*/

error_reporting(E_ALL);
ini_set('display_errors', 0);

/*
|--------------------------------------------------------------------------
| Define dirs
|--------------------------------------------------------------------------
|
*/
define('ABSPATH', 		dirname( __FILE__ ) . '/');
define('DIR_CORE',    	ABSPATH . 'core');
define('DIR_MODS',   	ABSPATH . 'modules');
define('DIR_ASSETS',   	'../assets');
define('DIR_UPLOADS',   ABSPATH . 'uploads');
define('DIR_DOWNLOADS', ABSPATH . 'downloads');
define('DIR_TEMP',   	ABSPATH . 'tmp');
define('DIR_EXCEL',   	ABSPATH . 'excel');
define('HOME_URL',   	(isset($_SERVER['HTTPS']) ? 'http' : 'http') . '://'.$_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']));
define('APP_VERSION',   '2.0.4');
define('UPDATE_URL',    'http://pastebin.com/raw/Du9VzGt4');
//define('UPDATE_URL',    'http://127.0.0.1/gsm/sdd_update/api.txt');
define('OFFICIEL_URL',  'https://www.facebook.com/adel.qusay.9');

/*
|--------------------------------------------------------------------------
| Database configurations
|--------------------------------------------------------------------------
|
*/

define( 'CKEY', 'AQDZ17HBB' );
define( 'DB', 'database.db' );

/*
|--------------------------------------------------------------------------
| Include files required for initialization.
|--------------------------------------------------------------------------
|
*/
include_once DIR_CORE . '/db.sqlite.class.php';
include_once DIR_CORE . '/PHPExcel/PHPExcel.php';
include_once DIR_CORE . '/class.upload.php';
include_once DIR_CORE . '/class.cem.php';
include_once DIR_CORE . '/class.engine.php';


// Establish database connection
$db = new SQLite3Database (DB);
if(!$db) die("خطأ في الاتصال بقاعدة البيانات");

$engine = new Engine($db);

?>